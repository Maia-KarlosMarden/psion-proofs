# Checks for PH_Foundations v8.7

Standalone scripts (numpy, sympy) behind the v8.7 changes. Run each from this folder,
e.g. `python verify_dm_census.py`. All results are quoted in `docs/CHANGES_v87.md`.

| Script | What it checks | Paper |
|---|---|---|
| `verify_dm_census.py` | 39-state census; (0,0,1,1,2,2,3,4,5) splits; 17 states with integer-charge splits; 8 N=9 states can emit (1,4,4) | §14.1 |
| `dark_charge.py` | proto-colour charges D1, D2: zero on all SM triples, non-zero on all 39 census states | §14.1 (C-DC) |
| `cond2.py` | Table 1 charges do not commute with SU(2)meta ladder operators (Schur) | §1, P-Qcons |
| `amp.py` | two-psion locked-phase model: proto-colour changes at second order, ~2 mu lambda / G | §14.1 |
| `exact.py` | conserved quantities N, F_z; Z12 obstruction | §14.1 |
| `steps.py` | conserved charge Q = N/6 + sum F_z/4; colour steps needed by neutral N=9 states | §14.1 |
| `photon.py` | conserved one-body charges (dimension 2); Table 1 = Q + delta(colour); eps_psi charge form | §1, J.6.4 |

These are model calculations of the locked phase defined in App. J.6.1 with the unlocking
penalty 2G; they do not replace the open derivations listed in the paper.
