import numpy as np, sympy as sp
from fractions import Fraction as F
# --- (1) Can Table-1 charges commute with SU(2)meta ladder operators on the k labels? ---
j=2.5; m=np.arange(-j,j+1); d=len(m)
Jp=np.zeros((d,d))
for i in range(d-1): Jp[i+1,i]=np.sqrt(j*(j+1)-m[i]*(m[i]+1))
Jm=Jp.T; Jz=np.diag(m); I6=np.eye(d)
Q=np.diag(np.array([1,-5,-5,10,4,4])/9); Qlin=np.diag((np.arange(6)-2)/3)
H=np.kron(Jz,Jz)+0.5*(np.kron(Jp,Jm)+np.kron(Jm,Jp))           # J1.J2 on two psions
for name,q in (("Table 1",Q),("Q=(k-2)/3",Qlin)):
    Qt=np.kron(q,I6)+np.kron(I6,q)
    print(f"{name}: ||[Q,J+]||={np.linalg.norm(q@Jp-Jp@q):.3f}  ||[Q1+Q2, J1.J2]||={np.linalg.norm(Qt@H-H@Qt):.3f}")
# --- (2) linear charge reproduces every three-body identification? ---
tri={'e':(0,1,2),'n':(0,1,5),'nu_mu':(0,2,4),'nu_e':(1,2,3),'p':(0,4,5),'S+':(1,3,5),'S+b':(2,3,4),'Q2':(3,4,5)}
q9=(1,-5,-5,10,4,4)
print({k:(F(sum(q9[i] for i in v),9),F(sum(i-2 for i in v),3)) for k,v in tri.items()})
# --- (3) label-conservation regime: lattice spanned by light free states ---
vec=lambda t:[t.count(k) for k in range(6)]
rows=[vec(v) for v in tri.values()]
W=[[ (1 if k==a+3 else 0)-(1 if k==a else 0) for k in range(6)] for a in range(3)]  # proto-W bilinears psi_bar_a psi_{a+3}
for label,R in (("triples",rows),("triples+proto-W",rows+W)):
    M=sp.Matrix(R)
    from sympy.matrices.normalforms import smith_normal_form
    print(label,"rank",M.rank(),"SNF diag",[smith_normal_form(M,domain=sp.ZZ)[i,i] for i in range(min(M.shape))])
