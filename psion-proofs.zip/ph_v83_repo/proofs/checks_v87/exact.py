import sympy as sp
from sympy.matrices.normalforms import smith_normal_form
from itertools import combinations_with_replacement as cwr, product
from collections import Counter
F=[-3,-2,-1,1,2,3]          # locked F_z = m + sign(m)/2 for k = 0..5
tri=[(0,1,2),(0,1,5),(0,2,4),(1,2,3),(0,4,5),(1,3,5),(2,3,4),(3,4,5)]
vec=lambda t:[t.count(k) for k in range(6)]
L=[vec(t) for t in tri]+[[(1 if k==a+3 else 0)-(1 if k==a else 0) for k in range(6)] for a in range(3)]
# label-changing moves allowed by exact N and F_z conservation
K=sp.Matrix([[1,1,1,1,1,1],F]).nullspace()
Kint=[]
for v in K:
    den=sp.ilcm(*[sp.fraction(x)[1] for x in v]); Kint.append([int(x*den) for x in v])
# full integer kernel lattice: use all small integer vectors in kernel
ker=[list(v) for v in product(range(-2,3),repeat=6) if sum(v)==0 and sum(a*b for a,b in zip(F,v))==0 and any(v)]
M=sp.Matrix(L+ker)
snf=smith_normal_form(M,domain=sp.ZZ)
print("SM lattice + N,F_z-conserving moves: SNF diag",[snf[i,i] for i in range(6)])
# conserved functionals: vanish on L+ker  -> combinations of N and F_z; check what SM states carry
N=lambda t:len(t); SF=lambda t:sum(F[k] for k in t)
print("SM triples (N, sumF):",[(N(t),SF(t)) for t in tri])
Q9=(1,-5,-5,10,4,4)
def neutral_split(s):
    c=[s.count(k) for k in range(6)]
    for sub in product(*(range(x+1) for x in c)):
        n=sum(sub)
        if 0<n<len(s) and sum(k*m for k,m in enumerate(sub))%3==0 and sum(Q9[k]*m for k,m in enumerate(sub))==0: return True
    return False
res=Counter()
for Nn in range(9,28,3):
    for s in cwr(range(6),Nn):
        if sum(s)%3 or sum(Q9[k] for k in s) or neutral_split(s): continue
        res[(Nn,(SF(s)-2*Nn//3)%4)]+=1
print("39 census: (N, (sumF - 2N/3) mod 4) ->",dict(res))
