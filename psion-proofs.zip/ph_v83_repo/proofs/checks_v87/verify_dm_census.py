"""Check of the dark-matter statements of section 14.1. Standard library only.
Covers N <= 27, where all 39 states lie (a few minutes at most)."""
from itertools import combinations_with_replacement, product
Q9 = (1, -5, -5, 10, 4, 4)          # 9*Q_k

def channels(s):
    """(neutral split, integer-charged split) of s into two Z6 colour singlets.
    Stops at the first neutral split, so the second flag is only meaningful
    when the first is False."""
    counts = [s.count(k) for k in range(6)]
    total_i, integer = sum(s), False
    for sub in product(*(range(c + 1) for c in counts)):
        n = sum(sub)
        i = sub[1] + 2*sub[2] + 3*sub[3] + 4*sub[4] + 5*sub[5]
        if n == 0 or n == len(s) or i % 3 or (total_i - i) % 3:
            continue
        q = sub[0] - 5*sub[1] - 5*sub[2] + 10*sub[3] + 4*sub[4] + 4*sub[5]
        if q == 0:
            return True, integer
        integer |= q % 9 == 0
    return False, integer

total = charged = 0
for N in range(9, 28, 3):
    stable = []
    for s in combinations_with_replacement(range(6), N):
        if sum(s) % 3 == 0 and sum(Q9[k] for k in s) == 0:
            neutral, integer = channels(s)
            if not neutral:
                stable.append(integer)
    if stable:
        total += len(stable); charged += sum(stable)
        print(f"N={N}: {len(stable)} without neutral split; {sum(stable)} with an integer-charged split")
print("total:", total, "| with integer-charged split:", charged)
print("(0,0,1,1,2,2,3,4,5) has a neutral split:", channels((0,0,1,1,2,2,3,4,5))[0])

# Fractional channels of the 22 states at N = 9
nus = 0
for s in combinations_with_replacement(range(6), 9):
    if sum(s) % 3 or sum(Q9[k] for k in s) or channels(s)[0]:
        continue
    rest = list(s)
    try:
        for k in (1, 4, 4): rest.remove(k)
        nus += sum(rest) % 3 == 0
    except ValueError:
        pass
print("N=9 states that can emit (1,4,4) [Q=+1/3]:", nus)
