import sympy as sp
from itertools import combinations_with_replacement as cwr, product
from collections import Counter
tri=[(0,1,2),(0,1,5),(0,2,4),(1,2,3),(0,4,5),(1,3,5),(2,3,4),(3,4,5)]
vec=lambda t:[t.count(k) for k in range(6)]
M=sp.Matrix([vec(t) for t in tri])
ns=M.nullspace(); print("functionals vanishing on all SM triples:",[list(v.T) for v in ns])
# integer basis
B=[ [int(x) for x in (v*sp.ilcm(*[sp.fraction(e)[1] for e in v])).T] for v in ns]
print("integer basis:",B)
Q9=(1,-5,-5,10,4,4)
def dc(s): v=vec(s); return tuple(sum(a*b for a,b in zip(f,v)) for f in B)
# old census (no neutral sub-multiset split) and charges
def neutral_split(s):
    c=[s.count(k) for k in range(6)]
    for sub in product(*(range(x+1) for x in c)):
        n=sum(sub)
        if 0<n<len(s) and sum(k*m for k,m in enumerate(sub))%3==0 and sum(Q9[k]*m for k,m in enumerate(sub))==0: return True
    return False
cnt=Counter(); allneutral=Counter()
for N in range(9,28,3):
    for s in cwr(range(6),N):
        if sum(s)%3 or sum(Q9[k] for k in s): continue
        z=dc(s)==(0,0)
        allneutral[(N,z)]+=1
        if not neutral_split(s): cnt[(N,z)]+=1
print("39 census: (N, dark charge zero?) ->",dict(cnt))
print("all neutral singlets: (N, zero?) ->",dict(sorted(allneutral.items())))
print("example (0,0,1,1,2,2,3,4,5):",dc((0,0,1,1,2,2,3,4,5)),"(0,0,0,0,0,0,1,1,4):",dc((0,0,0,0,0,0,1,1,4)))
print("single psions:",[dc((k,)) for k in range(6)])
