from itertools import combinations_with_replacement as cwr
from collections import Counter, deque
from fractions import Fraction as Fr
F=[-3,-2,-1,1,2,3]
Qnew=lambda s: Fr(len(s),6)+Fr(sum(F[k] for k in s),4)      # only charge conserved by N and F_z that fits e, n, p
Q9=(1,-5,-5,10,4,4)
def D(s):
    c=Counter(k%3 for k in s); return (c[1]-c[0], c[2]-c[0])
steps=[(3,0),(-3,0),(2,4),(-2,-4)]
def nmin(d):
    seen={d:0}; q=deque([d])
    while q:
        x=q.popleft()
        if x==(0,0): return seen[x]
        if seen[x]>12: continue
        for s in steps:
            y=(x[0]+s[0],x[1]+s[1])
            if y not in seen: seen[y]=seen[x]+1; q.append(y)
    return None
# census states (Table-1 neutral) under the conserved charge
from itertools import product
def neutral_split(s):
    c=[s.count(k) for k in range(6)]
    for sub in product(*(range(x+1) for x in c)):
        n=sum(sub)
        if 0<n<len(s) and sum(k*m for k,m in enumerate(sub))%3==0 and sum(Q9[k]*m for k,m in enumerate(sub))==0: return True
    return False
cen=[s for N in range(9,28,3) for s in cwr(range(6),N) if sum(s)%3==0 and sum(Q9[k] for k in s)==0 and not neutral_split(s)]
print("39 census under conserved charge Q=N/6+sumF/4:",Counter(str(Qnew(s)) for s in cen))
# neutral (conserved charge) N=9 colour singlets: dark candidates of the consistent dynamics
neu=[s for s in cwr(range(6),9) if sum(s)%3==0 and Qnew(s)==0]
dist=Counter(nmin(D(s)) for s in neu)
print("N=9 singlets with conserved Q=0:",len(neu),"| minimal colour-changing steps to D=0:",dict(dist))
print("SM check:",[str(Qnew(t)) for t in [(0,1,2),(0,1,5),(0,2,4),(1,2,3),(0,4,5),(3,4,5)]])
