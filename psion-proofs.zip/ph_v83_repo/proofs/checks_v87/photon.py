import numpy as np, itertools as it
from fractions import Fraction as Fr
import os
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'amp.py')).read().split('for (mu,lam) in')[0])
# (1) every one-body charge f(k) on the six locked labels conserved by the effective two-psion dynamics
Heff=heff_exact(1e3,1,1); rows=[]
for a,b in it.product(range(len(P)),repeat=2):
    if a<b and abs(Heff[a,b])>1e-12:
        (k1,k2),(k3,k4)=lab(P[a]),lab(P[b]); r=np.zeros(6)
        for k in (k1,k2): r[k]+=1
        for k in (k3,k4): r[k]-=1
        rows.append(r)
A=np.array(rows); ns=np.linalg.svd(A)[2][np.linalg.matrix_rank(A):]
print("dimension of conserved one-body charges:",len(ns))
F=np.array([-3,-2,-1,1,2,3.]); basis=np.vstack([np.ones(6),F])
print("spanned by N and F_z:",np.linalg.matrix_rank(np.vstack([ns,basis]))==2)
# (2) Table 1 minus the conserved charge
T1=[Fr(x,9) for x in (1,-5,-5,10,4,4)]; QF=[Fr(1,6)+Fr(int(f),4) for f in F]
delta=[a-b for a,b in zip(T1,QF)]; print("Table1 - Q:",[str(x) for x in delta],"| depends only on k mod 3:",delta[:3]==delta[3:],"| sum over colours:",sum(delta[:3]))
# (3) eps_psi from the charge form of Lemma I.1' with each charge
for name,Q in (("Table 1",T1),("conserved Q",QF)):
    dQ=Q[3]-Q[2]; t=6*dQ/2/25; eps=(2*t/(1+t*t))**2
    xi=434.09*(float(eps)/(25/169))**(1/3)
    print(f"{name}: dQ(2->3)={dQ}, Nc*dQ/2={6*dQ/2}, tan theta={t}, eps={float(eps):.5f}, xi* refit={xi:.1f}, direct Omega ratio={4*np.pi/3*7.205e10/0.938272*np.exp(-2/35*xi):.3g}")
