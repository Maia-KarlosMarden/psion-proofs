"""Colour-changing amplitude in the locked phase.
Single psion: 12 states (m = -5/2..5/2) x (sigma = -1/2,+1/2). Locked: sigma = sign(m) <-> label k = m + 5/2.
H = 2G * (#unlocked) + mu * sum_i J_i.Sigma_i (one-body, eq.1 contracted) + lam * sum_{i!=j} J_i.Sigma_j (two-body).
Effective Hamiltonian on locked pairs by second-order Schrieffer-Wolff; checked against exact projection."""
import numpy as np, itertools as it
j=2.5; m=np.arange(-j,j+1); d=6
Jp=np.zeros((d,d))
for i in range(d-1): Jp[i+1,i]=np.sqrt(j*(j+1)-m[i]*(m[i]+1))
J=[ (Jp+Jp.T)/2, (Jp-Jp.T)/(2j), np.diag(m) ]
s=[np.array([[0,1],[1,0]])/2, np.array([[0,1j],[-1j,0]])/2, np.diag([-.5,.5])]  # basis sigma=-1/2,+1/2
I6,I2=np.eye(6),np.eye(2)
Ja=[np.kron(x,I2) for x in J]; Sa=[np.kron(I6,x) for x in s]; I12=np.eye(12)
locked=[2*i+(0 if i<=2 else 1) for i in range(6)]          # index of locked state for label k=i
unl=np.diag([0 if b in locked else 1 for b in range(12)]).astype(float)
h1=sum(Ja[a]@Sa[a] for a in range(3))
def H(G,mu,lam):
    one=lambda A: np.kron(A,I12)+np.kron(I12,A)
    two=sum(np.kron(Ja[a],Sa[a])+np.kron(Sa[a],Ja[a]) for a in range(3))
    return 2*G*one(unl)+mu*one(h1)+lam*two, one(unl)
L=[a*12+b for a in locked for b in locked]
lab=lambda idx:(locked.index(idx//12),locked.index(idx%12))
col=lambda k:k%3
def heff_exact(G,mu,lam):
    Hm,U=H(G,mu,lam); P=np.array([U[i,i]==0 for i in range(144)])
    A=Hm[np.ix_(P,P)]; B=Hm[np.ix_(P,~P)]; C=Hm[np.ix_(~P,~P)]
    return A - B@np.linalg.solve(C,B.conj().T)   # Schur complement at E~0 (exact low-energy projection to leading order)
Hm,U=H(1,1,1); P=[i for i in range(144) if U[i,i]==0]
def colour_changes(Heff,tol=1e-12):
    out=[]
    for a,b in it.product(range(len(P)),repeat=2):
        if a<b and abs(Heff[a,b])>tol:
            ka,kb=lab(P[a]),lab(P[b])
            ca=sorted(col(k) for k in ka); cb=sorted(col(k) for k in kb)
            if ca!=cb: out.append((ka,kb,abs(Heff[a,b])))
    return out
for (mu,lam) in ((1,0),(0,1),(1,1)):
    ch=colour_changes(heff_exact(1e3,mu,lam))
    print(f"mu={mu}, lam={lam}: {len(ch)} colour-changing locked-pair elements; examples {ch[:3]}")
print("scaling of max colour-changing element with G (mu=lam=1):")
for G in (1e2,1e3,1e4,1e5):
    ch=colour_changes(heff_exact(G,1,1)); print(f"  G={G:.0e}: max={max(c[2] for c in ch):.3e}  max*G={max(c[2] for c in ch)*G:.3f}")
# Delta D per elementary transition
def D(k1,k2):
    c=[0,0,0]; c[k1%3]+=1; c[k2%3]+=1; return (c[1]-c[0],c[2]-c[0])
dD=sorted({tuple(np.subtract(D(*kb),D(*ka))) for ka,kb,_ in colour_changes(heff_exact(1e3,1,1))})
print("Delta D per elementary step:",dD)
np.save('dD.npy',np.array(dD))
