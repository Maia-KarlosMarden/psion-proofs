"""
test_kinematic_stability.py — regression tests for P_kinematic_stability.py
"""

import math

import pytest

from proofs.P_kinematic_stability import (
    ANCHORS, B_E, BOUND, ERRATA_V84_K3, TABLE3, balanced, min_ratio,
    partitions, ratio,
)


def test_partition_counts():
    # p(10) = 42, p(20) = 627, p(50) = 204226
    assert sum(1 for _ in partitions(10)) == 42
    assert sum(1 for _ in partitions(20)) == 627
    assert sum(1 for _ in partitions(50)) == 204226


@pytest.mark.parametrize("level", range(2, 26))
def test_inequality_11_every_partition(level):
    for parts in partitions(level):
        if len(parts) >= 2:
            assert ratio(level, parts) >= BOUND * (1 - 1e-12)


def test_bound_is_attained_at_l2():
    assert math.isclose(ratio(2, (1, 1)), BOUND, rel_tol=1e-12)
    assert math.isclose(BOUND, 2 * math.exp(1152 / 325), rel_tol=1e-12)


@pytest.mark.parametrize("level,k", [(8, 2), (10, 3), (17, 4), (24, 5)])
def test_balanced_is_minimum(level, k):
    best = min(ratio(level, p) for p in partitions(level) if len(p) == k)
    assert math.isclose(best, min_ratio(level, k), rel_tol=1e-12)
    assert sorted(balanced(level, k)) == sorted(
        min((p for p in partitions(level) if len(p) == k),
            key=lambda p: ratio(level, p)))


def test_table3_corrected():
    for level, (r2, r3) in TABLE3.items():
        assert math.isclose(min_ratio(level, 2), r2, rel_tol=5e-3)
        if r3 is None:
            assert level < 3
        else:
            assert math.isclose(min_ratio(level, 3), r3, rel_tol=5e-3)


def test_v84_k3_errata_are_wrong():
    assert not any(len(p) == 3 for p in partitions(2))
    assert math.isclose(ERRATA_V84_K3[2], 3 * math.exp(2 / B_E), rel_tol=1e-3)
    for level in (8, 10):
        assert min_ratio(level, 3) < ERRATA_V84_K3[level] / 100


def test_level_is_not_a_function_of_body_number():
    # Scope guard for the KS premise gap (§8.2 status note).
    levels_n2 = {lvl for n, lvl in ANCHORS.values() if n == 2}
    assert len(levels_n2) == 2
    assert 7 + ANCHORS["h_AB"][0] != ANCHORS["h_AB"][1]
