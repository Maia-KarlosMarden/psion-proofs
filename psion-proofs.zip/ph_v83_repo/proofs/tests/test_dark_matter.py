"""
test_dark_matter.py — regression tests for Theorem DM.1 (P_dark_matter.py)
"""

from itertools import combinations_with_replacement

from proofs.P_dark_matter import (
    EXPECTED_BY_N, Q9, census, is_neutral_singlet, stable_brute, stable_dp,
)


def test_no_single_psion_is_neutral():
    # Why single-psion removal can never detect instability.
    assert all(q != 0 for q in Q9)


def test_neutrality_requires_N_multiple_of_3():
    for N in (1, 2, 4, 5, 7, 8):
        assert not any(is_neutral_singlet(t)
                       for t in combinations_with_replacement(range(6), N))


def test_dark_census_39_states():
    data = census(n_max=30)
    dark = {N: len(st) for N, (_, st) in data.items() if N >= 4 and st}
    assert dark == EXPECTED_BY_N
    assert sum(dark.values()) == 39


def test_N6_fully_unstable():
    ns, st = census(n_max=6)[6]
    assert len(ns) == 6 and st == []


def test_algorithms_agree_up_to_N18():
    for N, (ns, _) in census(n_max=18).items():
        for t in ns:
            assert stable_dp(t) == stable_brute(t), t


def test_known_fragmentations():
    assert not stable_dp((1, 1, 2, 2, 3, 3))   # -> 2 x (1,2,3)
    assert not stable_dp((0, 0, 2, 2, 4, 4))   # -> 2 x (0,2,4)
    assert stable_dp((0, 1, 5))                # three-body neutral state
