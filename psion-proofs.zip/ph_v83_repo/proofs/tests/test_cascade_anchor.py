"""
test_cascade_anchor.py — pytest suite for v83 SC input declaration
===================================================================

Tests that:
1. Λ_meta is derived from m_e via exact cascade inversion (no other inputs)
2. All downstream predictions remain within tolerance
3. The SC input count is exactly 1
"""

import math
import pytest

# ── Constants (mirrors cascade_anchor.py exactly) ────────────────────────────
M_E_MEV        = 0.51099895
N_E            = 10
B_E            = 325 / 1152
S              = 6 * N_E / B_E
G2             = 2 * math.pi**2 / 3
K_XI           = 1.16335
N_C            = 6

LAMBDA_META_GEV = M_E_MEV * 1e-3 * math.exp(N_E / B_E)

C_DE           = N_C / (27 * math.pi**4)
RHO_LAMBDA     = C_DE * LAMBDA_META_GEV**4 * math.exp(-S)
G_N_PRED       = K_XI * LAMBDA_META_GEV**(-2) * math.exp(-S / G2)
MASTER_INV     = RHO_LAMBDA * G_N_PRED**2

# ── Observed values ───────────────────────────────────────────────────────────
RHO_LAMBDA_OBS = 2.515e-47
G_N_OBS        = 6.674e-39
MASTER_OBS     = 1.1203e-123


# ── Test 1: SC input structure ────────────────────────────────────────────────
def test_sc_input_count():
    """The framework has exactly one SC input: m_e."""
    SC_INPUTS = {"m_e": M_E_MEV}
    assert len(SC_INPUTS) == 1, "PH v83 must have exactly 1 SC input"


def test_lambda_meta_derived_from_me_only():
    """Λ_meta must be fully determined by m_e, N_e, b_e — no other observables."""
    # Verify the inversion formula: m_e = Λ_meta · exp(−N_e/b_e)
    m_e_recovered = LAMBDA_META_GEV * 1e3 * math.exp(-N_E / B_E)
    assert abs(m_e_recovered - M_E_MEV) / M_E_MEV < 1e-10, \
        "Cascade inversion is not self-consistent"


def test_lambda_meta_value():
    """Λ_meta = 1.2662×10¹² GeV (T1 given m_e)."""
    assert abs(LAMBDA_META_GEV - 1.2662e12) / 1.2662e12 < 1e-3


# ── Test 2: Exact theorems unchanged ─────────────────────────────────────────
def test_N_e_exact():
    assert N_E == 10

def test_b_e_exact():
    assert B_E == pytest.approx(325/1152, rel=1e-12)

def test_S_exact():
    assert S == pytest.approx(6 * 10 / (325/1152), rel=1e-10)

def test_g2_exact():
    assert G2 == pytest.approx(2 * math.pi**2 / 3, rel=1e-12)


# ── Test 3: Downstream predictions ───────────────────────────────────────────
def test_rho_lambda_prediction():
    """ρ_Λ within 1.5% of Planck 2018."""
    err = abs(RHO_LAMBDA / RHO_LAMBDA_OBS - 1)
    assert err < 0.015, f"ρ_Λ error {err*100:.2f}% exceeds 1.5%"

def test_G_N_prediction():
    """G_N within 1.0% of CODATA."""
    err = abs(G_N_PRED / G_N_OBS - 1)
    assert err < 0.010, f"G_N error {err*100:.2f}% exceeds 1.0%"

def test_master_invariant():
    """ρ_Λ·G_N² within 0.5% (Λ_meta cancels algebraically)."""
    err = abs(MASTER_INV / MASTER_OBS - 1)
    assert err < 0.005, f"Master invariant error {err*100:.3f}% exceeds 0.5%"

def test_master_invariant_lambda_cancellation():
    """
    Confirm algebraic cancellation: master invariant is independent of Λ_meta
    by construction (ρ_Λ ∝ Λ⁴, G_N ∝ Λ⁻²  →  ρ_Λ·G_N² ∝ Λ⁰).
    Test by computing with 10× Λ_meta — result must be identical.
    """
    scale = 10.0
    lm_scaled = LAMBDA_META_GEV * scale
    rho_scaled = C_DE * lm_scaled**4 * math.exp(-S)
    gn_scaled  = K_XI * lm_scaled**(-2) * math.exp(-S / G2)
    master_scaled = rho_scaled * gn_scaled**2

    # Must equal the original to machine precision
    assert abs(master_scaled / MASTER_INV - 1) < 1e-10, \
        "Master invariant is NOT independent of Λ_meta — algebraic error"


# ── Test 4: v82 → v83 regression (SC input reclassification) ─────────────────
def test_me_is_input_not_output():
    """
    v82 listed m_e as 'SC output' (0.508 MeV, 0.7% error).
    v83 declares m_e as 'SC input' (0.511 MeV exact by definition).
    This test asserts the v83 convention is in force.
    """
    # In v83, m_e enters as exact CODATA value — no 0.7% residual at input stage
    assert M_E_MEV == pytest.approx(0.51099895, rel=1e-7), \
        "m_e must be the exact CODATA value, not the 0.508 MeV cascade output"


def test_p2_p12_status_is_open():
    """
    P2/P12 (derive Λ_meta from Φ(Λ)=Λ) must remain T2 — not claimed as T1.
    This test is a documentary assertion; it will need to be updated
    if and when P2/P12 closes at T1.
    """
    P2_P12_STATUS = "T2"   # Update to "T1" only after formal closure
    assert P2_P12_STATUS == "T2", \
        "P2/P12 claimed as T1 without formal closure — update this test deliberately"
