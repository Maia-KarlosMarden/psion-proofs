"""
test_p2p12a_structure.py
========================
Verifica a estrutura identificada de γ_{O_e} nesta sessão de cálculo.

Resultado: γ_{O_e} = Z_NP × N_c / b0 = 1152/325

DOIS GAPS RESTANTES:
  P2/P12-A-i: calcular Z_NP = 32/25 do integral sunset explicitamente
  P2/P12-B:   derivar discretização RG em N_e passos da simetria Z6

Enquanto esses gaps estão abertos, o status é T2+.
"""

import math
import pytest

# ── Parâmetros PH (T1) ────────────────────────────────────────────────────────
B_E  = 325 / 1152     # b_e = b0 / (Z_NP × N_c)
N_E  = 10             # N_e, Theorem G.1 (T1)
Z_NP = 32 / 25        # fator renorm. sunset 2PI (T3 — a derivar)
b0   = 13 / 6         # coef. beta 1-loop: |β0| = N_Dirac + 2/N_f (T1)
N_C  = 6              # N_c = número de estados internos do psion (T1)
ME   = 0.51099895e-3  # m_e [GeV], SC input


class TestGammaStructure:
    """Estrutura γ_{O_e} = Z_NP × N_c / b0 identificada nesta sessão."""

    def test_gamma_target_value(self):
        """Alvo de P2/P12-A independente de b_e: γ = 1152/325."""
        gamma_target = 1152 / 325
        assert abs(gamma_target - 3.5446153846153846) < 1e-14

    def test_gamma_structure_matches_target(self):
        """
        Estrutura identificada: γ = Z_NP × N_c / b0.
        Esta é a expressão física — não usa b_e como input.
        """
        gamma_struct = Z_NP * N_C / b0
        gamma_target = 1152 / 325
        assert abs(gamma_struct - gamma_target) < 1e-12

    def test_gamma_equals_inverse_be(self):
        """
        γ = Z_NP × N_c / b0 = 1/b_e.
        ATENÇÃO: esta é uma tautologia dado b_e ≡ b0/(Z_NP N_c).
        O conteúdo físico é γ = 1152/325, não γ = 1/b_e.
        """
        gamma_struct = Z_NP * N_C / b0
        assert abs(gamma_struct - 1 / B_E) < 1e-12

    def test_be_is_definition_not_new_physics(self):
        """
        b_e ≡ b0 / (Z_NP × N_c) por definição.
        Portanto 1/b_e ≡ Z_NP × N_c / b0 é uma identidade,
        não uma nova relação física.
        """
        be_from_definition = b0 / (Z_NP * N_C)
        assert abs(be_from_definition - B_E) < 1e-14

    def test_gamma_single_per_cascade_level(self):
        """
        γ_single = γ_total / N_e = 1/(b_e × N_e).
        Hipótese P2/P12-B: cada nível de cascata contribui
        com γ_single independentemente.
        """
        gamma_total  = 1 / B_E
        gamma_single = gamma_total / N_E
        expected     = 1 / (B_E * N_E)
        assert abs(gamma_single - expected) < 1e-14

    def test_gamma_total_from_sum(self):
        """
        γ_total = N_e × γ_single = 1/b_e.
        Dado P2/P12-B (hipótese), a soma sobre níveis reproduz o alvo.
        """
        gamma_single = 1 / (B_E * N_E)
        gamma_total  = N_E * gamma_single
        assert abs(gamma_total - 1 / B_E) < 1e-14


class TestUVFixedPoint:
    """
    Fator N_c/b0 do ponto fixo UV — status T1/T2.
    Origem: b0 = N_Dirac + 2/N_f, N_c = 6 (estrutura Z6, T1).
    """

    def test_b0_from_beta_function(self):
        """b0 = N_Dirac + 2/N_f = 4 + 2/6 = 13/3... espera."""
        # |β0| = N_Dirac + 2/N_f onde o PH usa:
        # N_Dirac = 4, N_f = 6 → |β0| = 4 + 1/3 = 13/3
        # Mas b0 = 13/6 (metade) — convenção do PH
        N_Dirac = 4
        N_f     = 6
        beta0_magnitude = N_Dirac + 2 / N_f   # = 13/3
        assert abs(beta0_magnitude - 13 / 3) < 1e-14
        assert abs(b0 - beta0_magnitude / 2) < 1e-14  # b0 = |β0|/2

    def test_g2_UV_fixed_point(self):
        """g² = 2π²/3 no ponto fixo UV (T1 via Z6)."""
        g2 = 2 * math.pi**2 / 3
        assert abs(g2 - 6.579736267392905) < 1e-10

    def test_Nc_over_b0(self):
        """N_c / b0 = 6 / (13/6) = 36/13 (fator UV, T1)."""
        ratio = N_C / b0
        assert abs(ratio - 36 / 13) < 1e-14


class TestSunsetGap:
    """
    P2/P12-A-i: integral sunset → Z_NP = 32/25.
    STATUS: T3 — ABERTO.
    Estes testes verificam a especificação do gap, não sua solução.
    """

    def test_znp_value_assumed(self):
        """Z_NP = 32/25 é assumido, não derivado. Gap P2/P12-A-i."""
        znp_assumed = True   # ainda não calculado explicitamente
        assert znp_assumed, "Z_NP = 32/25 é input do cálculo, não output."

    def test_sunset_gap_is_open(self):
        """P2/P12-A-i é aberto."""
        p2p12ai_proved = False
        assert not p2p12ai_proved, (
            "P2/P12-A-i está aberto. "
            "Requer: calcular I_sunset com regularização de tempo próprio "
            "e extrair Z_NP = 32/25 sem assumir esse valor."
        )

    def test_sunset_technique_specified(self):
        """
        Técnica especificada para P2/P12-A-i:
        Regularização de tempo próprio (Schwinger proper-time):
          I = ∫ ds1 ds2 ds3 exp(-Σ²(s1+s2+s3)) / (s1+s2+s3)²
        com limites de integração 0 a 1/Λ².
        """
        technique = "Schwinger proper-time regularisation"
        assert len(technique) > 0  # especificação registrada

    def test_znp_as_fraction(self):
        """Z_NP = 32/25 = 1.28 exato."""
        assert Z_NP == 32 / 25
        assert abs(Z_NP - 1.28) < 1e-15


class TestDiscretisationGap:
    """
    P2/P12-B: discretização RG em N_e passos.
    STATUS: T3 — ABERTO.
    """

    def test_p2p12b_is_open(self):
        """P2/P12-B está aberto."""
        p2p12b_proved = False
        assert not p2p12b_proved, (
            "P2/P12-B está aberto. "
            "Requer: provar que o RG flow de O_e é discretizado em "
            "N_e = 10 passos pela simetria Z6."
        )

    def test_p2p12b_hypothesis(self):
        """
        Hipótese de P2/P12-B:
        A Z6-invariância de O_e = ψ_(0)ψ_(1)ψ_(2) (singleto I=3)
        implica que cada nível de cascata contribui com peso 1/N_e
        ao expoente total — análogo à série de Molien do Theorem G.1.
        """
        Oe_I_value = (0 + 1 + 2) % 6   # = 3, singleto Z6
        assert Oe_I_value == 3           # O_e é Z6-singleto de cor

    def test_p2p12b_connection_to_theorem_g1(self):
        """
        P2/P12-B é o análogo do Theorem G.1 para operadores compostos.
        Theorem G.1: N_e = 10 níveis no espectro de estados.
        P2/P12-B:   N_e = 10 passos no RG flow do operador O_e.
        """
        # Theorem G.1 já estabeleceu N_e = 10 para estados
        N_e_states   = N_E   # T1
        # P2/P12-B propõe o mesmo N_e para o operador
        N_e_operator = N_E   # hipótese — a provar
        assert N_e_states == N_e_operator  # se P2/P12-B, igualdade não-trivial

    def test_discretisation_gives_correct_gamma(self):
        """
        Se P2/P12-B for provado, a soma sobre N_e passos dá:
          γ_total = N_e × γ_single = 1/b_e ✓
        Verificação algébrica (não é prova de P2/P12-B).
        """
        gamma_single = Z_NP * N_C / (b0 * N_E)
        gamma_total  = N_E * gamma_single
        assert abs(gamma_total - 1 / B_E) < 1e-12


class TestConsequences:
    """Se P2/P12-A-i e P2/P12-B fecharem."""

    def test_electron_mass_becomes_theorem(self):
        """
        Com P2/P12-A-i + P2/P12-B:
          m_e = Λ_meta × exp(-N_e/b_e) torna-se teorema incondicional.
        Verificação numérica (conditional).
        """
        LM   = ME * math.exp(N_E / B_E)
        m_pred = LM * math.exp(-N_E / B_E)
        assert abs(m_pred / ME - 1.0) < 1e-12

    def test_sc_inputs_would_reach_zero(self):
        """
        Com P2/P12 fechado: SC inputs 1 → 0.
        m_e deixa de ser input e torna-se previsão.
        """
        sc_inputs_now    = 1    # v83: m_e como anchor
        sc_inputs_future = 0    # pós-P2/P12: m_e como previsão
        assert sc_inputs_now > sc_inputs_future

    def test_p2p12a_status_is_T2plus(self):
        """Status atual: T2+ (estrutura identificada, dois sub-gaps)."""
        status = "T2+"   # elevado de T2 após identificação da estrutura
        assert status == "T2+"

    def test_p2p12a_not_yet_T1(self):
        """P2/P12-A ainda não é T1 — dois sub-gaps abertos."""
        is_T1 = False
        assert not is_T1, (
            "P2/P12-A não é T1. "
            "Sub-gaps abertos: P2/P12-A-i (sunset) e P2/P12-B (discretização)."
        )


class TestSunsetSessionResults:
    """
    Resultados da sessao de calculo do sunset — Junho 2026.
    Novos resultados T1 e eliminacao de mecanismos.
    """

    def test_g2_Nc_over_16pi2_exact(self):
        """
        g^2 * N_c / (16*pi^2) = 1/4 EXATO [T1 novo].
        Dado g^2 = 2*pi^2/3 (T1) e N_c = 6 (T1).
        O sistema NJL e precisamente 3/4 sub-critico a 1-loop.
        """
        import math
        g2 = 2 * math.pi**2 / 3
        ratio = g2 * N_C / (16 * math.pi**2)
        assert abs(ratio - 1/4) < 1e-14, (
            f"g^2*N_c/(16pi^2) = {ratio}, expected 1/4"
        )

    def test_sub_criticality_exact(self):
        """
        O deficit de criticidade a 1-loop e exatamente 3/4.
        O kernel 2PI deve fornecer os 3/4 restantes.
        """
        import math
        g2 = 2 * math.pi**2 / 3
        contribution_1loop = g2 * N_C / (16 * math.pi**2)
        deficit = 1 - contribution_1loop
        assert abs(deficit - 3/4) < 1e-14

    def test_sunset_libre_propagator_eliminated(self):
        """
        O sunset no propagador livre NAO produz Z_NP = 32/25 como
        constante independente de Lambda.
        A contribuicao vai a zero para Lambda -> infinito.
        Mecanismo eliminado.
        """
        mechanism_libre_works = False
        assert not mechanism_libre_works, (
            "Sunset no propagador livre eliminado: contribuicao ~ Lambda^(-6) -> 0."
        )

    def test_wavefunction_renorm_eliminated(self):
        """
        Wavefunction renormalization do psion livre NAO produz Z_NP = 32/25.
        delta_Z ~ Lambda^(-6) -> 0 no limite UV.
        Mecanismo eliminado.
        """
        mechanism_wf_works = False
        assert not mechanism_wf_works, (
            "Wavefunction renorm. eliminado: delta_Z ~ Lambda^(-6) -> 0."
        )

    def test_vortex_mechanism_identified(self):
        """
        Z_NP = 32/25 vem da renormalizacao do acoplamento G_UV
        no propagador do VORTICE Z6 (kink), nao no psion livre.
        Proximo passo: calcular auto-energia do kink sigma_k.
        """
        next_step = "auto-energia do kink sigma_k = f_pi * tanh(m_Z6 * x / 2)"
        assert len(next_step) > 0  # especificacao registrada

    def test_new_T1_result_registered(self):
        """
        Novo resultado T1 desta sessao:
          g^2 * N_c / (16*pi^2) = 1/4
        Necessario para a derivacao completa de Z_NP.
        """
        import math
        g2 = 2 * math.pi**2 / 3
        assert abs(g2 * N_C / (16 * math.pi**2) - 1/4) < 1e-14
        is_T1 = True   # resultado T1 confirmado
        assert is_T1


class TestKinkSessionResults:
    """
    Resultados da sessao de auto-energia do kink — Junho 2026.
    Quatro mecanismos eliminados. Z_NP origem nao identificada.
    """

    def test_u_value_order_one(self):
        """
        u = kappa/Sigma = m_Z6/(2*m_e) = 3*sqrt(3)/pi ≈ 1.654.
        NAO e muito maior que 1.
        Correcao de erro anterior que afirmava u >> 1.
        """
        import math
        ME   = 0.51099895e-3
        f_pi = math.sqrt(3)/math.pi * ME
        m_Z6 = 6 * f_pi
        kappa = m_Z6 / 2
        Sigma = ME
        u = kappa / Sigma

        assert abs(u - 3*math.sqrt(3)/math.pi) < 1e-10
        assert 1.0 < u < 3.0, f"u = {u:.4f} deveria ser de ordem 1"

    def test_kink_sunset_cancels_UV(self):
        """
        A razao F_delta/F_sunset -> 1 para eps->0.
        A correcao do kink ao sunset CANCELA no limite UV.
        Mecanismo 3 eliminado.
        """
        kink_mechanism_works = False
        assert not kink_mechanism_works, (
            "Sunset no kink eliminado: F_delta/F_sunset -> 1 no UV."
        )

    def test_gap_equation_ratio(self):
        """
        Pi_2/Pi_1 com ln(Lambda^2/Sigma^2) = 2*N_e:
          I_ratio = g^2*N_c/(16pi^2) * (2*N_e - 1) = (1/4)*19 = 19/4
        Nao coincide com Z_NP = 32/25.
        Mecanismo 4 nao fecha.
        """
        import math
        g2 = 2*math.pi**2/3
        ratio_1loop = g2 * N_C / (16*math.pi**2)
        assert abs(ratio_1loop - 1/4) < 1e-14  # T1
        
        I_ratio = ratio_1loop * (2*N_E - 1)
        assert abs(I_ratio - 19/4) < 1e-10
        assert abs(I_ratio - 32/25) > 0.1, (
            f"I_ratio = {I_ratio} nao coincide com Z_NP = {32/25}"
        )

    def test_four_mechanisms_eliminated(self):
        """
        Quatro mecanismos testados e eliminados para Z_NP = 32/25.
        """
        eliminated = [
            "Sunset no propagador livre -> 0 no UV",
            "Wavefunction renorm. do psion livre -> 0 no UV",
            "Sunset no propagador do kink -> cancela no UV",
            "Razao Pi2/Pi1 na eq. de gap -> 19/4, nao 32/25",
        ]
        assert len(eliminated) == 4

    def test_znp_origin_unknown(self):
        """
        Z_NP = 32/25 nao tem origem identificada apos esta sessao.
        Tres possibilidades restantes registradas:
          1. Determinante funcional PT-2 (Teorema P16, Apend. D v82)
          2. Casimir de SU(2)_meta (conexao com A=13/12, p=5/6)
          3. Funcional Phi_2 do kink em 4D Euclideano
        """
        z_np_origin_identified = False
        next_steps = [
            "Consultar Apendice D v82 (Teorema P16)",
            "Explorar origem em SU(2)_meta",
            "Calcular funcional Phi_2 do kink em 4D",
        ]
        assert not z_np_origin_identified
        assert len(next_steps) == 3


class TestSystemClosedInJ:
    """
    Sistema completo fechado em j = 5/2.
    Todas as constantes do PH sao funcoes exatas de j.
    Resultado da sessao de busca algebrica — Junho 2026.
    """

    def test_znp_formula_in_j(self):
        """
        Z_NP = 2^(2j) / (2j)^2 = 32/25  [T2+ — formula identificada]
        Numerador: 2^(2j) = degenerescencia de 2j bits
        Denominador: (2j)^2 = fator de fase do vortice
        """
        from fractions import Fraction
        j = Fraction(5, 2)
        two_j = 2 * j
        Z_NP_formula = Fraction(2**int(two_j), int(two_j)**2)
        Z_NP_target  = Fraction(32, 25)
        assert Z_NP_formula == Z_NP_target

    def test_det_formula_in_j(self):
        """
        det'/det = 1/[(2j+1)(2j+3)] = 1/48  [T1]
        (2j+1) = N_c = 6 (estados do psion)
        (2j+3) = N_c+2 = 8 (modos do operador PT-2)
        """
        from fractions import Fraction
        j = Fraction(5, 2)
        det_formula = Fraction(1, int((2*j+1)*(2*j+3)))
        det_target  = Fraction(1, 48)
        assert det_formula == det_target

    def test_be_formula_in_j(self):
        """
        b_e = (4j+3)(2j)^2 / [2^(2j)(2j+1)^2] = 325/1152  [T1]
        Derivado algebricamente de j, Z_NP, b0, N_c.
        """
        from fractions import Fraction
        j = Fraction(5, 2)
        two_j = 2*j
        b_e_formula = (4*j+3) * two_j**2 / (Fraction(2**int(two_j)) * (two_j+1)**2)
        b_e_target  = Fraction(325, 1152)
        assert b_e_formula == b_e_target

    def test_A_formula_in_j(self):
        """A = (4j+3)/(4j+2) = 13/12  [T2]"""
        from fractions import Fraction
        j = Fraction(5, 2)
        assert (4*j+3)/(4*j+2) == Fraction(13, 12)

    def test_p_formula_in_j(self):
        """p = 2j/(2j+1) = 5/6  [T2]"""
        from fractions import Fraction
        j = Fraction(5, 2)
        assert 2*j/(2*j+1) == Fraction(5, 6)

    def test_Nc_formula_in_j(self):
        """N_c = 2j+1 = 6  [T1]"""
        from fractions import Fraction
        j = Fraction(5, 2)
        assert 2*j+1 == 6

    def test_b0_formula_in_j(self):
        """b0 = (4j+3)/(2j+1) = 13/6  [T1]"""
        from fractions import Fraction
        j = Fraction(5, 2)
        assert (4*j+3)/(2*j+1) == Fraction(13, 6)

    def test_det_znp_independent(self):
        """
        det'/det e Z_NP sao INDEPENDENTES — nao ha relacao simples entre eles.
        Produto = 2/75 sem forma significativa.
        det: invariante espectral (x-space).
        Z_NP: fator de renorm. (p-space).
        """
        from fractions import Fraction
        det = Fraction(1, 48)
        Z   = Fraction(32, 25)
        product = det * Z
        assert product == Fraction(2, 75)
        # Nao ha forma simples: 2/75 nao e 1/j, 1/N_c, etc.
        for num in range(1, 10):
            for den in range(1, 100):
                if Fraction(num, den) == product and den < 50:
                    assert den == 75 or num != 2  # unica forma simples e 2/75

    def test_znp_not_related_to_det(self):
        """
        Z_NP != f(det'/det) para nenhuma funcao simples f.
        Eles compartilham j mas vivem em espacos diferentes.
        """
        from fractions import Fraction
        det = Fraction(1, 48)
        Z   = Fraction(32, 25)
        # Tentativas de relacao
        assert Z / det != Fraction(1, 1)  # Z != det
        assert Z * det != Fraction(1, 1)  # Z*det != 1
        # A unica relacao: ambos sao funcoes de j=5/2

    def test_all_constants_from_j(self):
        """
        Teste mestre: TODOS os parametros PH sao funcoes exatas de j=5/2.
        """
        from fractions import Fraction
        j = Fraction(5, 2)
        two_j = 2*j
        
        N_c  = two_j + 1
        A    = (4*j+3) / (4*j+2)
        p    = two_j / (two_j+1)
        b0   = (4*j+3) / (two_j+1)
        Z_NP = Fraction(2**int(two_j), int(two_j)**2)
        det  = Fraction(1, int((two_j+1)*(two_j+3)))
        b_e  = (4*j+3)*two_j**2 / (Fraction(2**int(two_j))*(two_j+1)**2)
        
        assert N_c  == Fraction(6)
        assert A    == Fraction(13, 12)
        assert p    == Fraction(5, 6)
        assert b0   == Fraction(13, 6)
        assert Z_NP == Fraction(32, 25)
        assert det  == Fraction(1, 48)
        assert b_e  == Fraction(325, 1152)


class TestKernelDerivation:
    """
    Derivacao de Z_NP = 2^(2j)/(2j)^2 via kernel 2PI.
    Status: T2 (argumento combinatorio; denominador requer derivacao DS formal)
    """

    def test_free_states_count(self):
        """2j estados livres (excluindo ancora k=0)."""
        from fractions import Fraction
        j = Fraction(5,2)
        n_free = int(2*j)   # 5 estados livres: k=1,...,5
        assert n_free == 5

    def test_numerator_2power2j(self):
        """N_config = 2^(2j) = configuracoes dos estados livres."""
        from fractions import Fraction
        j = Fraction(5,2)
        n_config = 2**int(2*j)
        assert n_config == 32
        # Inclui subconjunto vazio (nenhum estado participa)
        assert n_config == 2**5

    def test_denominator_2j_squared(self):
        """N_norm = (2j)^2 = produto tensorial dos ranks in/out."""
        from fractions import Fraction
        j = Fraction(5,2)
        n_norm = int(2*j)**2
        assert n_norm == 25

    def test_znp_ratio(self):
        """Z_NP = N_config / N_norm = 2^(2j)/(2j)^2."""
        from fractions import Fraction
        j = Fraction(5,2)
        Z = Fraction(2**int(2*j), int(2*j)**2)
        assert Z == Fraction(32,25)

    def test_denominator_needs_formal_derivation(self):
        """
        AUDITORIA: o denominador (2j)^2 nao tem derivacao formal
        da equacao de Dyson-Schwinger 2PI.
        Este teste documenta que o argumento e T2, nao T1.
        """
        denominator_formally_derived = False
        assert not denominator_formally_derived, (
            "N_norm = (2j)^2 requer derivacao formal da DS 2PI. "
            "O argumento combinatorio atual e T2."
        )

    def test_p2p12ai_status_T2(self):
        """P2/P12-A-i atingiu T2 (nao T1) via argumento combinatorio."""
        status = "T2"
        assert status == "T2"
        assert status != "T1"


class TestT1FinalGap:
    """
    O que falta para T1: diagrama figura-8 vs bolha dupla.
    """

    def test_C_abab_gives_2j(self):
        """
        Contração C_abab = delta_ab: soma sobre estados livres = 2j.
        Este é o diagrama bolha dupla — NÃO é o que dá (2j)².
        """
        from fractions import Fraction
        j = Fraction(5,2); two_j = int(2*j)
        free = range(1, two_j+1)
        K_bolha = sum(1 for a in free for b in free if a==b)  # delta_ab
        assert K_bolha == two_j
        assert K_bolha != two_j**2

    def test_C_aabb_gives_2j_squared(self):
        """
        Contração C_aabb = delta_aa*delta_bb = 1: soma = (2j)².
        Este é o diagrama figura-8 — dá o denominador correto.
        """
        from fractions import Fraction
        j = Fraction(5,2); two_j = int(2*j)
        free = range(1, two_j+1)
        K_fig8 = sum(1 for a in free for b in free)  # C_aabb = 1 sempre
        assert K_fig8 == two_j**2
        assert K_fig8 == 25

    def test_figura8_not_yet_connected_to_running(self):
        """
        O diagrama figura-8 produz (2j)² mas sua conexão formal
        ao running de G_UV no NJL 2PI ainda não está demonstrada.
        Este é o único passo que falta para T1.
        """
        figura8_formally_derived = False
        assert not figura8_formally_derived, (
            "Falta provar que d²Phi_2/d(ln G_UV)² no NJL 2PI "
            "é dominado pelo diagrama figura-8 com fator (2j)²."
        )

    def test_s00_zero_is_T1(self):
        """
        S_00 = 0 (gauge do modo zero para sólitons) é T1
        pela teoria padrão de sólitons em QFT.
        Este passo não é o gargalo.
        """
        s00_zero_is_standard = True  # T1 da literatura
        assert s00_zero_is_standard

    def test_final_target_for_T1(self):
        """
        Alvo preciso de T1:
          d²Phi_2/d(ln G_UV)² |_critico = (2j)² × [fator de loop]
        onde Phi_2 é o funcional 2PI do NJL com representação spin-j.
        """
        from fractions import Fraction
        j = Fraction(5,2); two_j = 2*j
        # O valor alvo
        target_factor = int(two_j)**2  # = 25
        # Verificação que (2j)² é o fator correto
        assert target_factor == 25
        assert target_factor == int(two_j)**2


class TestFigure8Attempt:
    """
    Tentativa de prova via figura-8 — resultado negativo registrado.
    """

    def test_figure8_gap_equation_result(self):
        """
        A equação de gap quadrática com figura-8:
          x^2 = x + 1/4  →  x = (1+sqrt(2))/2
          Z_NP_quadratico = x^2 = (3+2*sqrt(2))/4 ≈ 1.457
        NÃO coincide com Z_NP = 32/25 = 1.28.
        """
        import math
        x = (1 + math.sqrt(2))/2
        z_quadratic = x**2
        z_target    = 32/25
        assert abs(z_quadratic - (3 + 2*math.sqrt(2))/4) < 1e-12
        assert abs(z_quadratic - z_target) > 0.1, (
            f"Equação quadrática dá {z_quadratic:.4f}, não {z_target}"
        )

    def test_five_mechanisms_eliminated(self):
        """
        Cinco mecanismos testados e eliminados para Z_NP = 32/25.
        """
        eliminated = [
            "sunset propagador livre → 0 no UV",
            "wavefunction renorm. livre → 0 no UV",
            "sunset kink x-space → cancela no UV",
            "equacao gap 2PI simples → 19/4",
            "equacao quadratica figura-8 → (3+2sqrt2)/4",
        ]
        assert len(eliminated) == 5

    def test_p2p12ai_status_T3(self):
        """
        P2/P12-A-i regrediu de T2+ para T3 após tentativas de prova.
        Z_NP = 32/25 identificado algebricamente (T2),
        derivação do kernel 2PI: aberta (T3).
        """
        derivation_from_kernel = False  # não obtida
        algebraic_identification = True  # confirmada
        assert algebraic_identification
        assert not derivation_from_kernel
