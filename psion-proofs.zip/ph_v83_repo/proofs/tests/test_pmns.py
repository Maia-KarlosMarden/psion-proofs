"""
test_pmns.py — regression tests for the PMNS programme (Stage 0 and model log)
"""

import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), "scripts"))

import pmns_models as pm  # noqa: E402
from proofs.P_pmns_structure import (  # noqa: E402
    ELECTRON, generation_colour, mu_tau_check, neutral_triples, rotate,
)


def test_generation_is_colour_of_R_constituent():
    nus = neutral_triples()
    assert sorted(generation_colour(t) for t in nus) == [0, 1, 2]
    assert {generation_colour(t): t for t in nus} == {0: (1, 2, 3), 1: (0, 2, 4), 2: (0, 1, 5)}


def test_z3_cycles_generations_and_fixes_electron():
    assert rotate((1, 2, 3)) == (0, 2, 4)
    assert rotate((0, 2, 4)) == (0, 1, 5)
    assert rotate((0, 1, 5)) == (1, 2, 3)
    assert rotate(ELECTRON) == ELECTRON


def test_mu_tau_symmetry_theorem():
    w13, w23 = mu_tau_check(n_samples=300)
    assert w13 < 1e-12 and w23 < 1e-12


def test_flavour_machinery_matches_icecube_benchmarks():
    assert pm.run_validate()


def test_standard_f3_band():
    U = pm.pmns_standard(0.307, 0.02195, 0.561, 177)
    assert abs(pm.f3_asymmetry(U) - 0.0641) < 5e-4
    for s23 in (0.43, 0.5, 0.596):
        assert pm.f3_asymmetry(pm.pmns_standard(0.307, 0.02195, s23, 0)) < 0


def test_clebsch_amplitudes():
    assert np.allclose(pm.A_FLIP ** 2, [360, 576, 360])


def test_cdf_falsified():
    assert pm.run_cdf() > 1.5 * pm.R_TARGET


def test_h4p_falsified():
    res = pm.run_h4p()
    assert len(res) == 4
    assert not any(r[-1] for r in res)


def test_h6_falsified():
    res = pm.run_h6()
    assert len(res) == 4
    assert not any(r[-1] for r in res)
    assert max(r[1] for r in res) < 0.1          # solar angle fails at every root


def test_h7_self_energy_matrix():
    H = pm.js_self_energy()
    r10 = np.sqrt(10)
    assert np.allclose(H, [[-1, r10, 0], [r10, -4.5, r10], [0, r10, -10]])


def test_h7_falsified():
    res = pm.run_h7()
    assert len(res) == 2 and not any(r[-1] for r in res)
    b = res[1]
    assert abs(b[1] - 0.3143) < 1e-3 and abs(b[2] - 0.01808) < 1e-4 and abs(b[3] - 0.2077) < 1e-3


def test_h8_space_and_limit():
    states, _ = pm.h8_space()
    assert len(states) == 6
    H, _ = pm.h8_hamiltonian(1e9)
    assert np.allclose(H[:3, :3], pm.js_self_energy())
    H0, _ = pm.h8_hamiltonian(0.0)
    assert np.allclose(H0[1:3, 3:], 0.0)          # only nu_e couples to the unlocked sector
    assert abs(H0[0, 3] - 4.5) < 1e-12           # zero-mode bond amplitude


def test_h8_falsified_theta23_frozen():
    rows = pm.run_h8()
    assert not any(r[6] for r in rows)
    s23_B = [r[4] for r in rows if r[1] == "B"]
    assert max(s23_B) - min(s23_B) < 0.02 and max(s23_B) < 0.23


def test_h9_structure():
    states, HJ, HS = pm.h9_space_and_ops()
    assert len(states) == 9
    H0, st = pm.h9_hamiltonian(0.0, +1)
    idx = {s: i for i, s in enumerate(st)}
    S = np.zeros_like(H0)
    for (a, b), v in HS.items():
        S[idx[a], idx[b]] += v
    assert np.allclose(S[:3, 3:] @ S[3:, :3], 8 * np.eye(3))   # scalar is flavour-universal


def test_h9_falsified_both_signs():
    rows = pm.run_h9()
    assert not any(r[7] for r in rows)
    phys = [r for r in rows if (r[0] == 1 and r[2] == "B") or (r[0] == -1 and r[2] == "A")]
    assert max(r[5] for r in phys) < 0.30
