"""
test_pmns.py — regression tests for the PMNS programme (Stage 0 and model log)
"""

import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), "scripts"))

import pmns_models as pm  # noqa: E402
from proofs.P_pmns_structure import (  # noqa: E402
    ELECTRON, generation_colour, mu_tau_check, neutral_triples, rotate,
)


def test_generation_is_colour_of_R_constituent():
    nus = neutral_triples()
    assert sorted(generation_colour(t) for t in nus) == [0, 1, 2]
    assert {generation_colour(t): t for t in nus} == {0: (1, 2, 3), 1: (0, 2, 4), 2: (0, 1, 5)}


def test_z3_cycles_generations_and_fixes_electron():
    assert rotate((1, 2, 3)) == (0, 2, 4)
    assert rotate((0, 2, 4)) == (0, 1, 5)
    assert rotate((0, 1, 5)) == (1, 2, 3)
    assert rotate(ELECTRON) == ELECTRON


def test_mu_tau_symmetry_theorem():
    w13, w23 = mu_tau_check(n_samples=300)
    assert w13 < 1e-12 and w23 < 1e-12


def test_flavour_machinery_matches_icecube_benchmarks():
    assert pm.run_validate()


def test_standard_f3_band():
    U = pm.pmns_standard(0.307, 0.02195, 0.561, 177)
    assert abs(pm.f3_asymmetry(U) - 0.0641) < 5e-4
    for s23 in (0.43, 0.5, 0.596):
        assert pm.f3_asymmetry(pm.pmns_standard(0.307, 0.02195, s23, 0)) < 0


def test_clebsch_amplitudes():
    assert np.allclose(pm.A_FLIP ** 2, [360, 576, 360])


def test_cdf_falsified():
    assert pm.run_cdf() > 1.5 * pm.R_TARGET


def test_h4p_falsified():
    res = pm.run_h4p()
    assert len(res) == 4
    assert not any(r[-1] for r in res)
