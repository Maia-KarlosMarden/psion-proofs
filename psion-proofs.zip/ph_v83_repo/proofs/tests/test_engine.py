"""
test_engine.py -- regression tests for the exact PD engine.

Run with:  pytest -q
These lock the structural (T1) invariants so any future change that breaks them
fails loudly.
"""

from fractions import Fraction as F

from psion_diagram import (
    PSIONS, Composite, conjugate_index, casimir,
    enumerate_singlets, C_total, molien_coefficients,
)
from psion_diagram.core import total_charge_of_states


def test_charge_table_V1():
    expected = {0: F(1, 9), 1: F(-5, 9), 2: F(-5, 9),
                3: F(10, 9), 4: F(4, 9), 5: F(4, 9)}
    for p in PSIONS:
        assert p.Q == expected[p.k]


def test_sum_of_charges_is_one():
    assert total_charge_of_states() == F(1)


def test_unit_triality():
    for p in PSIONS:
        assert (9 * p.Q).denominator == 1
        assert int(9 * p.Q) % 3 == 1


def test_casimir():
    assert casimir() == F(35, 4)


def test_conjugation_is_z6_inversion():
    for k in range(6):
        assert conjugate_index(k) == (6 - k) % 6


def test_electron_charge():
    assert Composite((0, 1, 2)).Q == F(-1)


def test_three_neutrino_sectors():
    singlets = enumerate_singlets(3)
    neutral = [c for c in singlets if c.Q == F(0)]
    sectors = {(c.I, c.mRJ_abs) for c in neutral}
    assert len(sectors) == 3


def test_eight_gluons_count_via_charge_difference():
    # |Z3|^2 - 1 = 8
    assert 3 ** 2 - 1 == 8


def test_charge_interlock():
    Q2, Q3 = PSIONS[2].Q, PSIONS[3].Q
    dQ = Q3 - Q2
    assert dQ == F(5, 3)
    assert 6 * (dQ / 2) == F(5)


def test_molien_closed_form_matches_series():
    coeffs = molien_coefficients(12)
    for N in range(1, 13):
        assert coeffs[N] == C_total(N)


def test_eps_psi_chain():
    delta = F(1, 25)
    eps = 4 * delta / (1 + delta) ** 2
    assert eps == F(25, 169)


def test_singlet_classification_scheme_independent():
    # I in {0,3} does not depend on charge scheme
    for c in enumerate_singlets(4):
        assert c.I in (0, 3)
