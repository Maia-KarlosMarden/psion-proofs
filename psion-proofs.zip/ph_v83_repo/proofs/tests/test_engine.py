"""
test_engine.py -- regression tests for the Z6 definitions (proofs/_z6.py).

Self-contained: no external package. Locks the counting and charge statements of
PH_Foundations v8.7. N_g = 8 is deliberately not tested as a theorem (P-Ng).
"""

from fractions import Fraction as F

from proofs._z6 import (C_total, Q_conserved, Q_label, casimir, conjugate_index,
                        conserved_charge, distinct_triples, is_singlet,
                        label_charge, molien_coefficients, multisets, triality)


def test_charge_table_V1():
    expected = [F(1, 9), F(-5, 9), F(-5, 9), F(10, 9), F(4, 9), F(4, 9)]
    assert [label_charge(k) for k in range(6)] == expected


def test_sum_of_charges_is_one():
    assert sum((label_charge(k) for k in range(6)), F(0)) == 1
    assert sum((conserved_charge(k) for k in range(6)), F(0)) == 1


def test_unit_triality():
    for k in range(6):
        assert int(9 * label_charge(k)) % 3 == 1


def test_casimir():
    assert casimir() == F(35, 4)


def test_conjugation_is_z6_inversion():
    for k in range(6):
        assert conjugate_index(k) == (6 - k) % 6


def test_electron_charge():
    assert Q_label((0, 1, 2)) == -1 == Q_conserved((0, 1, 2))


def test_eight_singlets_three_neutral():
    s = [t for t in distinct_triples() if is_singlet(t)]
    assert len(s) == 8
    assert [t for t in s if Q_label(t) == 0] == [(0, 1, 5), (0, 2, 4), (1, 2, 3)]


def test_label_and_conserved_charge_agree_on_triples():
    for t in distinct_triples():
        if is_singlet(t):
            assert Q_label(t) == Q_conserved(t)


def test_interlock_labels_only():
    assert 6 * (label_charge(3) - label_charge(2)) / 2 == 5
    assert 6 * (conserved_charge(3) - conserved_charge(2)) / 2 == F(3, 2)


def test_molien_closed_form_matches_series():
    coeffs = molien_coefficients(12)
    for N in range(1, 13):
        assert coeffs[N] == C_total(N)
    assert sum(C_total(N) for N in range(1, 21)) == 76761


def test_eps_psi_chain():
    delta = F(1, 25)
    assert 4 * delta / (1 + delta) ** 2 == F(25, 169)


def test_singlet_classification():
    for t in multisets(4):
        assert is_singlet(t) == (triality(t) in (0, 3))
