#!/usr/bin/env python3
"""
pmns_models.py  --  PMNS programme, Stages 1-2: candidate textures and F3
=========================================================================

Every candidate is evaluated in the PH flavour basis fixed by
proofs/P_pmns_structure.py (generation = proto-colour of the R constituent;
order e, mu, tau <-> colour 0, 1, 2) with the same fixed data and the same
pass criteria, and every candidate yields F3 as an output.

Usage:
  python3 scripts/pmns_models.py validate   # flavour-at-Earth machinery vs IceCube benchmarks
  python3 scripts/pmns_models.py cdf        # Clebsch double-flip model (FALSIFIED under H3)
  python3 scripts/pmns_models.py h4p        # H4' rank-one exchange (pre-registered; FALSIFIED under H3)
  python3 scripts/pmns_models.py h6         # H6 rank-one along the charge vector (FALSIFIED under H3)
  python3 scripts/pmns_models.py h7         # H7 first-order J.Sigma self-energy (FALSIFIED)
  python3 scripts/pmns_models.py h8         # H8 J.Sigma + G P_unlocked (FALSIFIED)
  python3 scripts/pmns_models.py h9         # H9 full eq. (1) + gap, both signs (pre-registered)

Fixed data (NuFIT 6.0, normal ordering, IC19 variant, arXiv:2410.05380 Table 1):
  Dm21^2 = 7.49e-5 eV^2, Dm31^2 = 2.534e-3 eV^2.
Pass criteria (NuFIT 6.0 3-sigma, union of the IC19 and IC24 variants):
  sin^2 th12 in [0.275, 0.345], sin^2 th13 in [0.02023, 0.02388],
  sin^2 th23 in [0.430, 0.596], normal ordering.
F3 observable: A_te = (f_tau - f_e)/(f_tau + f_e) at Earth for a pion-decay
source (1:2:0). Real operators give delta in {0, pi}.
"""

from __future__ import annotations

import sys

import numpy as np
from scipy.optimize import brentq

B_E = 325 / 1152
A_LEP, P_LEP = 13 / 12, 5 / 6          # lepton law, level = l0 - A|m|^p
DM21, DM31 = 7.49e-5, 2.534e-3
R_TARGET = DM31 / DM21
S12_RANGE = (0.275, 0.345)
S13_RANGE = (0.02023, 0.02388)
S23_RANGE = (0.430, 0.596)
M_R = np.array([0.5, 1.5, 2.5])        # |m_R| of the neutral triples, colours 0,1,2
M_J_R_CHARGED = np.array([0.0, 1.5, 2.5])  # Table 5


# ── flavour at Earth ─────────────────────────────────────────────────────────
def pmns_standard(s12, s13, s23, dcp_deg):
    t12, t13, t23 = (np.arcsin(np.sqrt(v)) for v in (s12, s13, s23))
    d = np.deg2rad(dcp_deg)
    c12, sn12, c13, sn13 = np.cos(t12), np.sin(t12), np.cos(t13), np.sin(t13)
    c23, sn23 = np.cos(t23), np.sin(t23)
    R23 = np.array([[1, 0, 0], [0, c23, sn23], [0, -sn23, c23]], dtype=complex)
    R13 = np.array([[c13, 0, sn13 * np.exp(-1j * d)], [0, 1, 0],
                    [-sn13 * np.exp(1j * d), 0, c13]], dtype=complex)
    R12 = np.array([[c12, sn12, 0], [-sn12, c12, 0], [0, 0, 1]], dtype=complex)
    return R23 @ R13 @ R12


def earth_fractions(U, source=(1, 2, 0)):
    W = np.abs(U) ** 2
    src = np.asarray(source, float)
    return (W @ W.T) @ (src / src.sum())


def f3_asymmetry(U):
    f = earth_fractions(U)
    return (f[2] - f[0]) / (f[2] + f[0])


def angles(U):
    s13 = abs(U[0, 2]) ** 2
    return abs(U[0, 1]) ** 2 / (1 - s13), s13, abs(U[1, 2]) ** 2 / (1 - s13)


def passes(s12, s13, s23):
    return (S12_RANGE[0] <= s12 <= S12_RANGE[1] and S13_RANGE[0] <= s13 <= S13_RANGE[1]
            and S23_RANGE[0] <= s23 <= S23_RANGE[1])


# ── SU(2)_meta ingredients ───────────────────────────────────────────────────
def clebsch_up(j, m):
    """<m+1|J+|m>"""
    return np.sqrt(j * (j + 1) - m * (m + 1))


def three_step_amplitudes(j=2.5):
    """a_c = <m+3|J+^3|m> for the flip of colour c in e(0,1,2), m = c - 5/2."""
    return np.array([np.prod([clebsch_up(j, m0 + s) for s in range(3)])
                     for m0 in (-2.5, -1.5, -0.5)])


A_FLIP = three_step_amplitudes()        # (sqrt360, 24, sqrt360)
A_HAT = A_FLIP / np.linalg.norm(A_FLIP)


def diag_mass_ratios():
    """Hypothesis H3: neutrino diagonal masses from the charged-lepton law applied
    to |m_R|, normalised to colour 0. UNJUSTIFIED for neutrinos: contradicts
    Table 6 (m3/m2 ~ 17.4 here vs ~5.4 there). Every model using it is
    falsified only conditionally on H3 (docs/PMNS_PROGRAMME.md)."""
    lv = -A_LEP * M_R ** P_LEP
    return np.exp(-(lv - lv[0]) / B_E)


def ordered_spectrum(Mop):
    w, O = np.linalg.eigh(Mop)
    m = np.abs(w)
    order = np.argsort(m)
    return m[order], O[:, order]


def splitting_ratio(m):
    return (m[2] ** 2 - m[0] ** 2) / (m[1] ** 2 - m[0] ** 2)


# ── Model CDF: Clebsch double-flip in level space (FALSIFIED) ────────────────
def cdf_spectrum(g):
    K = np.outer(A_FLIP, A_FLIP) / A_FLIP.max() ** 2
    np.fill_diagonal(K, 0.0)
    L = np.diag(-A_LEP * M_R ** P_LEP) - g * K
    w, O = np.linalg.eigh(L)
    m = np.exp(-w / B_E)
    order = np.argsort(m)
    return m[order], O[:, order]


def run_cdf():
    print("Model CDF (level-space double flip, one coupling g; O_l = 1)")
    print(f"  target Dm31/Dm21 = {R_TARGET:.2f}")
    gs = np.linspace(0.0, 20.0, 401)
    ratios, rows = [], []
    for g in gs:
        m, U = cdf_spectrum(g)
        ratios.append(splitting_ratio(m))
        rows.append((g, ratios[-1], *angles(U)))
    for g, r, s12, s13, s23 in rows[::40]:
        print(f"  g={g:5.1f}  Dm31/Dm21={r:10.3g}  s12={s12:.3f} s13={s13:.3f} s23={s23:.3f}")
    rmin = min(ratios)
    print(f"  minimum Dm31/Dm21 over g in [0,20]: {rmin:.1f} (at g = {gs[int(np.argmin(ratios))]:.2f})")
    verdict = "FALSIFIED" if rmin > 1.5 * R_TARGET else "not excluded"
    print(f"  VERDICT: {verdict} (no coupling reaches the observed splitting ratio)")
    return rmin


# ── Rank-one exchange models: M_nu = s [diag(r_c) + x v v^T], O_l = 1 ──────────
Q_HAT = np.array([1.0, -5.0, -5.0]) / np.sqrt(51.0)   # 9 q_c, proto-colour charge (§J.6.4)


def rank_one_spectrum(x, v):
    return ordered_spectrum(np.diag(diag_mass_ratios()) + x * np.outer(v, v))


def h4p_spectrum(x):
    """H4': v = three-step Clebsch flip vector a_hat."""
    return rank_one_spectrum(x, A_HAT)


def run_rank_one(name, v):
    print(f"Model {name} (rank-one exchange, M = s[diag(r) + x v v^T], O_l = 1)")
    print(f"  diag ratios r = {np.round(diag_mass_ratios(), 3)}, v = {np.round(v, 4)}")
    print(f"  target Dm31/Dm21 = {R_TARGET:.3f}")
    spec = lambda x: rank_one_spectrum(x, v)
    xs = np.concatenate([-np.logspace(6, -4, 4000), [0.0], np.logspace(-4, 6, 4000)])
    f = np.array([splitting_ratio(spec(x)[0]) - R_TARGET for x in xs])
    roots = []
    for i in range(len(xs) - 1):
        if np.isfinite(f[i]) and np.isfinite(f[i + 1]) and f[i] * f[i + 1] < 0:
            x0 = brentq(lambda x: splitting_ratio(spec(x)[0]) - R_TARGET, xs[i], xs[i + 1])
            if abs(splitting_ratio(spec(x0)[0]) / R_TARGET - 1) < 1e-6:
                roots.append(x0)
    results = []
    if not roots:
        print("  no x reproduces the observed splitting ratio")
    for x0 in roots:
        m, U = spec(x0)
        scale = np.sqrt(DM21 / (m[1] ** 2 - m[0] ** 2))
        s12, s13, s23 = angles(U)
        a = f3_asymmetry(U)
        ok = passes(s12, s13, s23)
        results.append((x0, s12, s13, s23, a, ok))
        print(f"  root x = {x0:+.6g}:  masses = {np.round(m * scale * 1e3, 3)} meV")
        print(f"     sin2 th12 = {s12:.4f}  sin2 th13 = {s13:.5f}  sin2 th23 = {s23:.4f}"
              f"  -> {'PASS' if ok else 'FAIL'}")
        print(f"     F3: A_te = {a * 100:+.2f}%")
    any_pass = any(r[-1] for r in results)
    print(f"  VERDICT: {'SURVIVES' if any_pass else 'FALSIFIED'}")
    return results


def run_h4p():
    return run_rank_one("H4'", A_HAT)


def run_h6():
    return run_rank_one("H6", Q_HAT)


# ── Model H7: first-order J.Sigma self-energy of the neutral triples (Lagrangian eq. 1) ──
Q9_K = (1, -5, -5, 10, 4, 4)
NEUTRAL_BY_COLOUR = [(1, 2, 3), (0, 2, 4), (0, 1, 5)]       # colour 0, 1, 2 (Stage 0)


def _m(k):
    return k - 2.5


def _is_L(k):
    return k <= 2


def js_self_energy():
    """Matrix of V = J.Sigma = JzSz + (J+S- + J-S+)/2 between the neutral triples.

    J acts on L constituents (k <= 2), Sigma on R constituents (k >= 3), two-body,
    summed over (L, R) pairs. Only matrix elements whose final state is again one
    of the three neutral triples (locked, distinct labels, Q = 0) are kept. The
    overall sign and scale of V do not affect the eigenvectors.
    """
    j = 2.5
    idx = {t: c for c, t in enumerate(NEUTRAL_BY_COLOUR)}
    H = np.zeros((3, 3))
    for c, t in enumerate(NEUTRAL_BY_COLOUR):
        Ls = [k for k in t if _is_L(k)]
        Rs = [k for k in t if not _is_L(k)]
        for kl in Ls:
            for kr in Rs:
                H[c, c] += _m(kl) * _m(kr)                                  # Jz Sz
                for dl, dr in ((+1, -1), (-1, +1)):                          # J+S-, J-S+
                    kl2, kr2 = kl + dl, kr + dr
                    if not (0 <= kl2 <= 2 and 3 <= kr2 <= 5):
                        continue                                             # leaves locked subspace
                    t2 = tuple(sorted([k for k in t if k not in (kl, kr)] + [kl2, kr2]))
                    if t2 not in idx:
                        continue                                             # not a neutral triple
                    ml, mr = _m(kl), _m(kr)
                    amp_l = np.sqrt(j * (j + 1) - ml * (ml + dl))
                    amp_r = np.sqrt(j * (j + 1) - mr * (mr + dr))
                    H[idx[t2], c] += 0.5 * amp_l * amp_r
    return H


def run_h7():
    H = js_self_energy()
    print("Model H7 (first-order J.Sigma self-energy of the neutral triples; zero free parameters for U)")
    print("  V in the colour basis (e, mu, tau):")
    print("  " + str(np.round(H, 4)).replace("\n", "\n  "))
    print(f"  symmetric: {np.allclose(H, H.T)};  V_e,tau = {H[0, 2]:.3g};  V_e,mu = {H[0, 1]:.4f};  V_mu,tau = {H[1, 2]:.4f}")
    w, O = np.linalg.eigh(H)
    results = []
    for label, order in (("A: mass increases with eigenvalue", [0, 1, 2]),
                         ("B: mass decreases with eigenvalue", [2, 1, 0])):
        U = O[:, order]
        s12, s13, s23 = angles(U)
        ok = passes(s12, s13, s23)
        a = f3_asymmetry(U)
        results.append((label, s12, s13, s23, a, ok))
        print(f"  ordering {label}: eigenvalues for (nu1,nu2,nu3) = {np.round(w[order], 4)}")
        print(f"     sin2 th12 = {s12:.4f}  sin2 th13 = {s13:.5f}  sin2 th23 = {s23:.4f}  -> {'PASS' if ok else 'FAIL'}")
        print(f"     F3: A_te = {a * 100:+.2f}%")
        print("     |U|^2 =", np.round(np.abs(U) ** 2, 3).tolist())
    any_pass = any(r[-1] for r in results)
    print(f"  VERDICT: {'SURVIVES' if any_pass else 'FALSIFIED'} (2 orderings tested)")
    return results


# ── Model H8: J.Sigma + G P_unlocked, exact diagonalisation (one parameter G) ──
_QC9 = (1, -5, -5)                      # 9 q_c by proto-colour


def _charge9(chi, m):
    """Extended Z6 charge of a constituent (chi = 0 L, 1 R); colour c = (m + 5/2) mod 3.
    Reduces to Q9_k on the locked states (k = m + 5/2)."""
    return _QC9[int(round(m + 2.5)) % 3] + 9 * chi


def _locked(chi, m):
    return (chi == 0 and m < 0) or (chi == 1 and m > 0)


def h8_space():
    """Neutral (Q = 0) states (mL1 < mL2; mR) reachable from the three neutral triples
    by charge-conserving J.Sigma moves. Distinct L labels (antisymmetric internal part)."""
    ms = [x - 2.5 for x in range(6)]
    j = 2.5
    def q9(st):
        a, b, r = st
        return _charge9(0, a) + _charge9(0, b) + _charge9(1, r)
    start = [(-1.5, -0.5, 0.5), (-2.5, -0.5, 1.5), (-2.5, -1.5, 2.5)]   # nu_e, nu_mu, nu_tau
    states, frontier = list(start), list(start)
    edges = {}
    while frontier:
        new = []
        for st in frontier:
            a, b, r = st
            out = {}
            diag = (a + b) * r
            out[st] = out.get(st, 0.0) + diag
            for which in (0, 1):
                L = [a, b]
                ml = L[which]
                for dl, dr in ((+1, -1), (-1, +1)):
                    ml2, mr2 = ml + dl, r + dr
                    if ml2 not in ms or mr2 not in ms:
                        continue
                    L2 = L.copy(); L2[which] = ml2
                    if L2[0] == L2[1]:
                        continue                                  # repeated L label vanishes
                    sign = 1.0 if L2[0] < L2[1] else -1.0         # fermionic reordering
                    st2 = (min(L2), max(L2), mr2)
                    if q9(st2) != q9(st):
                        continue                                  # charge conservation
                    amp = 0.5 * np.sqrt(j*(j+1) - ml*(ml+dl)) * np.sqrt(j*(j+1) - r*(r+dr))
                    out[st2] = out.get(st2, 0.0) + sign * amp
                    if st2 not in states:
                        states.append(st2); new.append(st2)
            edges[st] = out
        frontier = new
    return states, edges


def h8_hamiltonian(G):
    states, edges = h8_space()
    idx = {st: n for n, st in enumerate(states)}
    H = np.zeros((len(states), len(states)))
    for st, out in edges.items():
        for st2, amp in out.items():
            H[idx[st2], idx[st]] += amp
    for st, n in idx.items():
        a, b, r = st
        H[n, n] += G * sum(not _locked(chi, m) for chi, m in ((0, a), (0, b), (1, r)))
    return H, states


def h8_mixing(G):
    """U = Loewdin-orthonormalised locked-sector projection of the three eigenstates
    with largest locked weight; returns U (rows e,mu,tau), their eigenvalues, min weight."""
    H, states = h8_hamiltonian(G)
    assert np.allclose(H, H.T)
    w, O = np.linalg.eigh(H)
    Pw = (O[:3, :] ** 2).sum(axis=0)                   # first three states = locked triples
    pick = np.sort(np.argsort(Pw)[-3:])
    M = O[:3, pick]
    u, _, vt = np.linalg.svd(M)
    return u @ vt, w[pick], Pw[pick].min()


def run_h8():
    states, _ = h8_space()
    nunl = sum(1 for (a, b, r) in states if not (_locked(0, a) and _locked(0, b) and _locked(1, r)))
    print("Model H8 (V = J.Sigma + G P_unlocked, exact diagonalisation; one parameter G)")
    print(f"  neutral reachable states: {len(states)} (3 locked triples + {nunl} with unlocked constituents)")
    Gs = np.logspace(np.log10(0.25), 4, 400)
    rows = []
    for G in Gs:
        U, w, pw = h8_mixing(G)
        for label, order in (("A", [0, 1, 2]), ("B", [2, 1, 0])):
            Uo = U[:, order]
            s12, s13, s23 = angles(Uo)
            rows.append((G, label, s12, s13, s23, f3_asymmetry(Uo), passes(s12, s13, s23), pw))
    for G in (0.5, 1, 2, 5, 10, 30, 100, 1000, 10000):
        r = min((x for x in rows if x[1] == "B"), key=lambda x: abs(np.log(x[0] / G)))
        print(f"  G={r[0]:8.2f} B: s12={r[2]:.3f} s13={r[3]:.4f} s23={r[4]:.3f} A_te={r[5]*100:+6.1f}%  locked weight>={r[7]:.3f}")
    ok = [x for x in rows if x[6]]
    if ok:
        Gmin, Gmax = min(x[0] for x in ok), max(x[0] for x in ok)
        print(f"  PASS window: G in [{Gmin:.3g}, {Gmax:.3g}] (orderings {sorted(set(x[1] for x in ok))})")
    else:
        best = min(rows, key=lambda x: max(0, 0.430 - x[4]) + max(0, x[4] - 0.596)
                   + 10 * (max(0, 0.02023 - x[3]) + max(0, x[3] - 0.02388))
                   + max(0, 0.275 - x[2]) + max(0, x[2] - 0.345))
        print(f"  closest point: G={best[0]:.3g} {best[1]}: s12={best[2]:.3f} s13={best[3]:.4f} s23={best[4]:.3f}")
    print(f"  VERDICT: {'SURVIVES' if ok else 'FALSIFIED'} (G scanned 0.25-1e4, 2 orderings)")
    return rows


# ── Model H9: full eq. (1) (scalar + J.Sigma, common G_UV) + G P_unlocked, Fock space ──
KAPPA_S = 2.0       # second-quantised counting: (psibar psi)^2 reaches an (L,R) pair in 2 ways


def _mode(chi, m):
    return 6 * chi + int(round(m + 2.5))


def _mode_cm(x):
    return x // 6, (x % 6) - 2.5


def _fock_apply(occ, ops):
    """Apply ops = [(kind, mode)] right-to-left convention already resolved: list is in
    application order. kind 'a' annihilate, 'c' create. Returns (sign, new occ) or None."""
    occ = list(occ); sign = 1
    for kind, x in ops:
        n_below = sum(1 for y in occ if y < x)
        if kind == 'a':
            if x not in occ: return None
            occ.remove(x)
        else:
            if x in occ: return None
            occ.append(x)
        sign *= (-1) ** n_below
    return sign, tuple(sorted(occ))


def _pair_moves(x, y):
    """Moves of an occupied (L, R) mode pair: list of (x', y', amp_JS, amp_S)."""
    (cx, mx), (cy, my) = _mode_cm(x), _mode_cm(y)
    assert cx == 0 and cy == 1
    j = 2.5
    out = [(x, y, mx * my, 0.0)]                                            # Jz Sz
    for dl, dr in ((+1, -1), (-1, +1)):                                     # J+S-, J-S+
        ml, mr = mx + dl, my + dr
        if -2.5 <= ml <= 2.5 and -2.5 <= mr <= 2.5:
            amp = 0.5 * np.sqrt(j*(j+1) - mx*(mx+dl)) * np.sqrt(j*(j+1) - my*(my+dr))
            out.append((_mode(0, ml), _mode(1, mr), amp, 0.0))
    out.append((_mode(1, mx), _mode(0, my), 0.0, KAPPA_S))                 # scalar: flip both
    return out


def _q9_mode(x):
    c, m = _mode_cm(x)
    return _charge9(c, m)


def h9_space_and_ops():
    start = [tuple(sorted((_mode(0, a), _mode(0, b), _mode(1, r))))
             for a, b, r in [(-1.5, -0.5, 0.5), (-2.5, -0.5, 1.5), (-2.5, -1.5, 2.5)]]
    states, frontier = list(start), list(start)
    HJ, HS = {}, {}
    while frontier:
        new = []
        for st in frontier:
            Ls = [x for x in st if x < 6]; Rs = [x for x in st if x >= 6]
            for x in Ls:
                for y in Rs:
                    for x2, y2, aJ, aS in _pair_moves(x, y):
                        if _q9_mode(x2) + _q9_mode(y2) != _q9_mode(x) + _q9_mode(y):
                            continue                                          # charge conservation
                        res = _fock_apply(st, [('a', x), ('a', y), ('c', y2), ('c', x2)])
                        if res is None:
                            continue                                          # Pauli
                        sign, st2 = res
                        if aJ: HJ[(st2, st)] = HJ.get((st2, st), 0.0) + sign * aJ
                        if aS: HS[(st2, st)] = HS.get((st2, st), 0.0) + sign * aS
                        if st2 not in states:
                            states.append(st2); new.append(st2)
        frontier = new
    return states, HJ, HS


def h9_hamiltonian(G, s_js, kappa_on=True):
    states, HJ, HS = h9_space_and_ops()
    idx = {st: n for n, st in enumerate(states)}
    n = len(states)
    H = np.zeros((n, n))
    for (a, b), v in HJ.items():
        H[idx[a], idx[b]] += s_js * v
    if kappa_on:
        for (a, b), v in HS.items():
            H[idx[a], idx[b]] += v
    for st, k in idx.items():
        H[k, k] += G * sum(not _locked(*_mode_cm(x)) for x in st)
    return H, states


def h9_mixing(G, s_js):
    H, _ = h9_hamiltonian(G, s_js)
    assert np.allclose(H, H.T)
    w, O = np.linalg.eigh(H)
    Pw = (O[:3, :] ** 2).sum(axis=0)
    pick = np.sort(np.argsort(Pw)[-3:])
    u, _, vt = np.linalg.svd(O[:3, pick])
    return u @ vt, w[pick], Pw[pick].min()


def run_h9():
    states, _, _ = h9_space_and_ops()
    print(f"Model H9 (H = s_JS V_JS + V_S + G P_unlocked; kappa_S = {KAPPA_S}); reachable states: {len(states)}")
    Gs = np.logspace(np.log10(0.25), 4, 400)
    allrows = []
    for s_js, name in ((+1, "S+ (printed eq. 1: same sign)"), (-1, "S- (relative coefficient -1)")):
        rows = []
        for G in Gs:
            U, w, pw = h9_mixing(G, s_js)
            for label, order in (("A", [0, 1, 2]), ("B", [2, 1, 0])):
                Uo = U[:, order]
                s12, s13, s23 = angles(Uo)
                rows.append((s_js, G, label, s12, s13, s23, f3_asymmetry(Uo), passes(s12, s13, s23), pw))
        print(f"  {name}")
        for G in (0.5, 2, 10, 30, 100, 1e4):
            for label in ("A", "B"):
                r = min((x for x in rows if x[2] == label), key=lambda x: abs(np.log(x[1] / G)))
                print(f"    G={r[1]:8.2f} {label}: s12={r[3]:.3f} s13={r[4]:.4f} s23={r[5]:.3f} A_te={r[6]*100:+6.1f}%  locked>={r[8]:.2f}")
        ok = [x for x in rows if x[7]]
        if ok:
            print(f"    PASS window: G in [{min(x[1] for x in ok):.3g}, {max(x[1] for x in ok):.3g}], orderings {sorted(set(x[2] for x in ok))}")
        else:
            best = min(rows, key=lambda x: max(0, 0.430 - x[5]) + max(0, x[5] - 0.596)
                       + 10 * (max(0, 0.02023 - x[4]) + max(0, x[4] - 0.02388))
                       + max(0, 0.275 - x[3]) + max(0, x[3] - 0.345))
            print(f"    closest: G={best[1]:.3g} {best[2]}: s12={best[3]:.3f} s13={best[4]:.4f} s23={best[5]:.3f}")
        print(f"    VERDICT {name.split()[0]}: {'SURVIVES' if ok else 'FALSIFIED'}")
        allrows += rows
    return allrows


def run_validate():
    print("Flavour-at-Earth machinery vs IceCube benchmark mapping (PRL 137, 081002)")
    U = pmns_standard(0.307, 0.02195, 0.561, 177)
    bench = {"pion (1:2:0)": ((1, 2, 0), (0.30, 0.36, 0.34), 0.01),
             "neutron (1:0:0)": ((1, 0, 0), (0.55, 0.17, 0.28), 0.01),
             "muon-damped (0:1:0)": ((0, 1, 0), (0.17, 0.47, 0.36), 0.03)}
    ok = True
    for name, (src, ref, tol) in bench.items():
        f = earth_fractions(U, src)
        good = np.max(np.abs(f - np.array(ref))) <= tol
        ok &= bool(good)
        print(f"  {name:20s} {np.round(f, 3)} vs {ref}  {'OK' if good else 'MISMATCH'}")
    print(f"  standard F3 at NuFIT 6.0 IC19 best fit: A_te = {f3_asymmetry(U) * 100:+.2f}%")
    return ok


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "validate"
    {"validate": run_validate, "cdf": run_cdf, "h4p": run_h4p, "h6": run_h6, "h7": run_h7, "h8": run_h8, "h9": run_h9}[cmd]()
