#!/usr/bin/env python3
"""
pmns_models.py  --  PMNS programme, Stages 1-2: candidate textures and F3
=========================================================================

Every candidate is evaluated in the PH flavour basis fixed by
proofs/P_pmns_structure.py (generation = proto-colour of the R constituent;
order e, mu, tau <-> colour 0, 1, 2) with the same fixed data and the same
pass criteria, and every candidate yields F3 as an output.

Usage:
  python3 scripts/pmns_models.py validate   # flavour-at-Earth machinery vs IceCube benchmarks
  python3 scripts/pmns_models.py cdf        # Clebsch double-flip model (FALSIFIED, record)
  python3 scripts/pmns_models.py h4p        # H4' rank-one exchange (pre-registered; FALSIFIED)
  python3 scripts/pmns_models.py h6         # H6 rank-one along the charge vector (registered)

Fixed data (NuFIT 6.0, normal ordering, IC19 variant, arXiv:2410.05380 Table 1):
  Dm21^2 = 7.49e-5 eV^2, Dm31^2 = 2.534e-3 eV^2.
Pass criteria (NuFIT 6.0 3-sigma, union of the IC19 and IC24 variants):
  sin^2 th12 in [0.275, 0.345], sin^2 th13 in [0.02023, 0.02388],
  sin^2 th23 in [0.430, 0.596], normal ordering.
F3 observable: A_te = (f_tau - f_e)/(f_tau + f_e) at Earth for a pion-decay
source (1:2:0). Real operators give delta in {0, pi}.
"""

from __future__ import annotations

import sys

import numpy as np
from scipy.optimize import brentq

B_E = 325 / 1152
A_LEP, P_LEP = 13 / 12, 5 / 6          # lepton law, level = l0 - A|m|^p
DM21, DM31 = 7.49e-5, 2.534e-3
R_TARGET = DM31 / DM21
S12_RANGE = (0.275, 0.345)
S13_RANGE = (0.02023, 0.02388)
S23_RANGE = (0.430, 0.596)
M_R = np.array([0.5, 1.5, 2.5])        # |m_R| of the neutral triples, colours 0,1,2
M_J_R_CHARGED = np.array([0.0, 1.5, 2.5])  # Table 5


# ── flavour at Earth ─────────────────────────────────────────────────────────
def pmns_standard(s12, s13, s23, dcp_deg):
    t12, t13, t23 = (np.arcsin(np.sqrt(v)) for v in (s12, s13, s23))
    d = np.deg2rad(dcp_deg)
    c12, sn12, c13, sn13 = np.cos(t12), np.sin(t12), np.cos(t13), np.sin(t13)
    c23, sn23 = np.cos(t23), np.sin(t23)
    R23 = np.array([[1, 0, 0], [0, c23, sn23], [0, -sn23, c23]], dtype=complex)
    R13 = np.array([[c13, 0, sn13 * np.exp(-1j * d)], [0, 1, 0],
                    [-sn13 * np.exp(1j * d), 0, c13]], dtype=complex)
    R12 = np.array([[c12, sn12, 0], [-sn12, c12, 0], [0, 0, 1]], dtype=complex)
    return R23 @ R13 @ R12


def earth_fractions(U, source=(1, 2, 0)):
    W = np.abs(U) ** 2
    src = np.asarray(source, float)
    return (W @ W.T) @ (src / src.sum())


def f3_asymmetry(U):
    f = earth_fractions(U)
    return (f[2] - f[0]) / (f[2] + f[0])


def angles(U):
    s13 = abs(U[0, 2]) ** 2
    return abs(U[0, 1]) ** 2 / (1 - s13), s13, abs(U[1, 2]) ** 2 / (1 - s13)


def passes(s12, s13, s23):
    return (S12_RANGE[0] <= s12 <= S12_RANGE[1] and S13_RANGE[0] <= s13 <= S13_RANGE[1]
            and S23_RANGE[0] <= s23 <= S23_RANGE[1])


# ── SU(2)_meta ingredients ───────────────────────────────────────────────────
def clebsch_up(j, m):
    """<m+1|J+|m>"""
    return np.sqrt(j * (j + 1) - m * (m + 1))


def three_step_amplitudes(j=2.5):
    """a_c = <m+3|J+^3|m> for the flip of colour c in e(0,1,2), m = c - 5/2."""
    return np.array([np.prod([clebsch_up(j, m0 + s) for s in range(3)])
                     for m0 in (-2.5, -1.5, -0.5)])


A_FLIP = three_step_amplitudes()        # (sqrt360, 24, sqrt360)
A_HAT = A_FLIP / np.linalg.norm(A_FLIP)


def diag_mass_ratios():
    """Neutrino diagonal masses from the lepton law applied to |m_R|, normalised to colour 0."""
    lv = -A_LEP * M_R ** P_LEP
    return np.exp(-(lv - lv[0]) / B_E)


def ordered_spectrum(Mop):
    w, O = np.linalg.eigh(Mop)
    m = np.abs(w)
    order = np.argsort(m)
    return m[order], O[:, order]


def splitting_ratio(m):
    return (m[2] ** 2 - m[0] ** 2) / (m[1] ** 2 - m[0] ** 2)


# ── Model CDF: Clebsch double-flip in level space (FALSIFIED) ────────────────
def cdf_spectrum(g):
    K = np.outer(A_FLIP, A_FLIP) / A_FLIP.max() ** 2
    np.fill_diagonal(K, 0.0)
    L = np.diag(-A_LEP * M_R ** P_LEP) - g * K
    w, O = np.linalg.eigh(L)
    m = np.exp(-w / B_E)
    order = np.argsort(m)
    return m[order], O[:, order]


def run_cdf():
    print("Model CDF (level-space double flip, one coupling g; O_l = 1)")
    print(f"  target Dm31/Dm21 = {R_TARGET:.2f}")
    gs = np.linspace(0.0, 20.0, 401)
    ratios, rows = [], []
    for g in gs:
        m, U = cdf_spectrum(g)
        ratios.append(splitting_ratio(m))
        rows.append((g, ratios[-1], *angles(U)))
    for g, r, s12, s13, s23 in rows[::40]:
        print(f"  g={g:5.1f}  Dm31/Dm21={r:10.3g}  s12={s12:.3f} s13={s13:.3f} s23={s23:.3f}")
    rmin = min(ratios)
    print(f"  minimum Dm31/Dm21 over g in [0,20]: {rmin:.1f} (at g = {gs[int(np.argmin(ratios))]:.2f})")
    verdict = "FALSIFIED" if rmin > 1.5 * R_TARGET else "not excluded"
    print(f"  VERDICT: {verdict} (no coupling reaches the observed splitting ratio)")
    return rmin


# ── Rank-one exchange models: M_nu = s [diag(r_c) + x v v^T], O_l = 1 ──────────
Q_HAT = np.array([1.0, -5.0, -5.0]) / np.sqrt(51.0)   # 9 q_c, proto-colour charge (§J.6.4)


def rank_one_spectrum(x, v):
    return ordered_spectrum(np.diag(diag_mass_ratios()) + x * np.outer(v, v))


def h4p_spectrum(x):
    """H4': v = three-step Clebsch flip vector a_hat."""
    return rank_one_spectrum(x, A_HAT)


def run_rank_one(name, v):
    print(f"Model {name} (rank-one exchange, M = s[diag(r) + x v v^T], O_l = 1)")
    print(f"  diag ratios r = {np.round(diag_mass_ratios(), 3)}, v = {np.round(v, 4)}")
    print(f"  target Dm31/Dm21 = {R_TARGET:.3f}")
    spec = lambda x: rank_one_spectrum(x, v)
    xs = np.concatenate([-np.logspace(6, -4, 4000), [0.0], np.logspace(-4, 6, 4000)])
    f = np.array([splitting_ratio(spec(x)[0]) - R_TARGET for x in xs])
    roots = []
    for i in range(len(xs) - 1):
        if np.isfinite(f[i]) and np.isfinite(f[i + 1]) and f[i] * f[i + 1] < 0:
            x0 = brentq(lambda x: splitting_ratio(spec(x)[0]) - R_TARGET, xs[i], xs[i + 1])
            if abs(splitting_ratio(spec(x0)[0]) / R_TARGET - 1) < 1e-6:
                roots.append(x0)
    results = []
    if not roots:
        print("  no x reproduces the observed splitting ratio")
    for x0 in roots:
        m, U = spec(x0)
        scale = np.sqrt(DM21 / (m[1] ** 2 - m[0] ** 2))
        s12, s13, s23 = angles(U)
        a = f3_asymmetry(U)
        ok = passes(s12, s13, s23)
        results.append((x0, s12, s13, s23, a, ok))
        print(f"  root x = {x0:+.6g}:  masses = {np.round(m * scale * 1e3, 3)} meV")
        print(f"     sin2 th12 = {s12:.4f}  sin2 th13 = {s13:.5f}  sin2 th23 = {s23:.4f}"
              f"  -> {'PASS' if ok else 'FAIL'}")
        print(f"     F3: A_te = {a * 100:+.2f}%")
    any_pass = any(r[-1] for r in results)
    print(f"  VERDICT: {'SURVIVES' if any_pass else 'FALSIFIED'}")
    return results


def run_h4p():
    return run_rank_one("H4'", A_HAT)


def run_h6():
    return run_rank_one("H6", Q_HAT)


def run_validate():
    print("Flavour-at-Earth machinery vs IceCube benchmark mapping (PRL 137, 081002)")
    U = pmns_standard(0.307, 0.02195, 0.561, 177)
    bench = {"pion (1:2:0)": ((1, 2, 0), (0.30, 0.36, 0.34), 0.01),
             "neutron (1:0:0)": ((1, 0, 0), (0.55, 0.17, 0.28), 0.01),
             "muon-damped (0:1:0)": ((0, 1, 0), (0.17, 0.47, 0.36), 0.03)}
    ok = True
    for name, (src, ref, tol) in bench.items():
        f = earth_fractions(U, src)
        good = np.max(np.abs(f - np.array(ref))) <= tol
        ok &= bool(good)
        print(f"  {name:20s} {np.round(f, 3)} vs {ref}  {'OK' if good else 'MISMATCH'}")
    print(f"  standard F3 at NuFIT 6.0 IC19 best fit: A_te = {f3_asymmetry(U) * 100:+.2f}%")
    return ok


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "validate"
    {"validate": run_validate, "cdf": run_cdf, "h4p": run_h4p, "h6": run_h6}[cmd]()
