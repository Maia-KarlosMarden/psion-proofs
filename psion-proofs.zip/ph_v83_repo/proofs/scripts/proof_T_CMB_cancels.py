#!/usr/bin/env python3
"""
proof_T_CMB_cancels.py
======================
Proves that T_CMB cancels identically in Omega_DM/Omega_b.

THEOREM: The PH identity Omega_DM/Omega_b = (4pi/3)*(m_DM/m_p)*exp(-xi*_DM)
is independent of T_CMB. T_CMB was implicitly cancelled from the start.

PROOF (3 steps):
  Step 1: n_DM/n_b = Y_DM/Y_b  (comoving ratio; s(T) cancels)
  Step 2: Y_DM/Y_b = (g_dark/g_bar)*exp(-xi*_DM) at nucleation
          T_nuc cancels in the ratio of densities at nucleation.
  Step 3: Omega_DM/Omega_b = (m_DM/m_p)*(4pi/3)*exp(-xi*_DM)  QED
"""
import math
from math import pi

LAM=1.2662e12; eps_psi=25/169; eps_conf=4/9; n_ng=0.749; eta_B=6.02e-10
xi_star=(eps_psi*eps_conf*n_ng/eta_B)**(1/3)
m_DM=2*LAM/35; m_p=0.938; xi_DM=(m_DM/LAM)*xi_star
g_star_S=106.75; N_bar=3

def s(T): return (2*pi**2/45)*g_star_S*T**3

Y_DM_over_Yb = (4*pi/N_bar)*math.exp(-xi_DM)

print("THEOREM: Omega_DM/Omega_b = (4pi/3)*(m_DM/m_p)*exp(-xi*_DM) is T_CMB-independent")
print()
print("Step 1: s(T) cancels in n_DM/n_b = Y_DM*s(T) / Y_b*s(T) = Y_DM/Y_b")
print(f"  Y_DM/Y_b = {Y_DM_over_Yb:.6e}  (constant for all T)")
print()
print("Step 2: T_nuc cancels at nucleation")
print(f"  n_i(T_nuc) = g_i * T_nuc^3/(2pi^2). Ratio = g_dark/g_bar. T_nuc cancels.")
print(f"  Y_DM/Y_b = (g_dark/g_bar)*exp(-xi*_DM) = (4pi/3)*exp(-xi*_DM)")
print()
print("Step 3: Omega_DM/Omega_b = (m_DM/m_p)*(Y_DM/Y_b)")
Omega = (m_DM/m_p)*Y_DM_over_Yb
print(f"  = {m_DM/m_p:.4e} * {Y_DM_over_Yb:.4e} = {Omega:.4f}")
print()
print("Verification: same result at T_nuc, 1 MeV, 1 eV, T_CMB today:")
T_nuc=LAM/xi_star
T_CMB=2.7255*8.617333e-14
for T,label in [(T_nuc,"T_nuc"),(1e-3,"1 MeV"),(1e-9,"1 eV"),(T_CMB,"T_CMB")]:
    nratio=Y_DM_over_Yb*s(T)/s(T)  # s cancels
    print(f"  T={T:.3e} GeV [{label:6s}]: Omega_DM/Omega_b = {(m_DM/m_p)*nratio:.4f}")
print()
print(f"T_CMB = {T_CMB:.4e} GeV. Nowhere in the formula. QED.")
