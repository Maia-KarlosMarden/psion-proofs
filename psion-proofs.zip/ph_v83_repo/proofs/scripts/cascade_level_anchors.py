#!/usr/bin/env python3
"""
cascade_level_anchors.py -- level and body-number are INDEPENDENT (3 anchors)
=============================================================================

The dark-matter mass was stuck because the cascade-LEVEL <-> BODY-NUMBER map was
unknown. Two laws (level=7+N and level=13-N) both fit the electron + X17 under
different body-number assumptions for X17. The 8 gluons / h_AB (N=2) and the
3 neutrinos (N=3), together with the electron, provide the THIRD anchor that
breaks the degeneracy.

THE THREE BOSONIC CASCADE ANCHORS (document line 108, tower law
m = Lambda_meta*exp(-level/b_eff), inter-level ratio exp(1/b)=34.63):
   h_AB:     body N=2, cascade level 8,  m ~ 0.613 GeV
   X17:      body N=2 (bilinear),        cascade level 9,  m ~ 17.7 MeV
   electron: body N=3, cascade level 10, m ~ 0.511 MeV

VERDICT: cascade level is NOT a function of body number.
   - h_AB (N=2) -> level 8, but X17 (N=2) -> level 9: same body number, different
     level. So level != f(N).
   - electron (N=3) -> level 10 (lighter than the N=2 states), the opposite of
     what 'heavier-N = heavier' would give.
Both candidate laws (level=7+N from this repo's session, and level=13-N implied
by reading X17 as N=4) are REFUTED. The cascade level is its own quantum number
(the ladder rung), independent of body number.

CONSEQUENCE (the coherent, decoupled picture):
   - BODY NUMBER (which states are stable): N=9,12,15,18,21,27 by enumeration.
     N=4 has zero stable singlets -> the document's N=4 DM identity is falsified.
   - CASCADE LEVEL (the mass): independent of N. The DM mass from the Landau-pole
     + xi* prova real (scripts/dm_prova_real.py) is ~7.2e10 GeV, i.e. cascade
     level ~0.8 (the top rung; m_DM = 2*Lambda/35 ~ 2x the level-1 mass).
   - So stable dark states (N>=9 body) sit at the TOP cascade rung, mass
     ~7e10 GeV. Body number (enumeration) and mass (prova real) are decoupled
     and each independently fixed.

The repo's earlier 14 GeV result is RETRACTED: it assumed level=7+N, refuted by
the three bosonic anchors.
"""

import math

LAM = 1.2662e12
B = 325/1152


def mass_at_level(level):
    return LAM * math.exp(-level / B)


def main():
    print("=" * 68)
    print("Cascade-level anchors: level is INDEPENDENT of body number")
    print("=" * 68)
    anchors = [
        ("h_AB",     2, 8,  0.613,    "GeV"),
        ("X17",      2, 9,  17.7e-3,  "GeV"),
        ("electron", 3, 10, 0.511e-3, "GeV"),
    ]
    print(f"{'state':10}{'N_body':>7}{'level':>7}{'m_pred':>13}{'m_obs':>12}")
    for name, N, lvl, mobs, _ in anchors:
        mp = mass_at_level(lvl)
        print(f"{name:10}{N:>7}{lvl:>7}{mp:>13.3e}{mobs:>12.3e}")
    print()
    print("h_AB(N=2)->lvl8 and X17(N=2)->lvl9: same body number, DIFFERENT level")
    print("=> cascade level is NOT a function of body number. Both 'level=7+N'")
    print("   and 'level=13-N' are REFUTED.")
    print()
    # DM cascade level from the prova-real mass
    m_DM = 2 * LAM / 35
    lvl_DM = -B * math.log(m_DM / LAM)
    print(f"DM mass (Landau + xi* prova real) = {m_DM:.3e} GeV")
    print(f"  => cascade level {lvl_DM:.2f} (top rung; = 2 x level-1 mass)")
    print(f"  level-1 mass = {mass_at_level(1):.3e} GeV; "
          f"m_DM/m(lvl1) = {m_DM/mass_at_level(1):.2f}")
    print()
    print("COHERENT PICTURE: body number (N>=9, enumeration) and mass (top")
    print("cascade rung, ~7e10 GeV, prova real) are DECOUPLED and each fixed.")
    print("DM mass: 7.235e10 GeV (N_Landau=35, prova real §13.2)")


if __name__ == "__main__":
    main()
