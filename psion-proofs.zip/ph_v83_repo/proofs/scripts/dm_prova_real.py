#!/usr/bin/env python3
"""
dm_prova_real.py -- the 'prova real' (consistency test) for the DM mass scale
=============================================================================

Methodology (Karlos): hitting a target number (Omega_DM/Omega_b = 5.4) is
NECESSARY but NOT SUFFICIENT. A hypothesis must pass a PROVA REAL -- an
independent consistency test, ideally an OVERDETERMINATION where the same
quantity is fixed by two disjoint routes that must agree (cf. the Triangle).

THE TEST (non-circular form): two DISJOINT inputs pin the DM mass scale.
  Route 1 (Landau pole): m_DM = 2*Lambda/N_Landau, N_Landau=35 (cascade-mode
    counting to the Landau pole). Uses NO cosmology. -> 7.235e10 GeV.
  Route 2 (thermal relic window): the freeze-out product
    P(m) = (m/m_p)*exp(-(m/Lambda)*xi*), with xi*=434 fixed by eta_B (baryon
    sector, NO DM input). P(m) is non-monotonic, peaking ~1e9 at m=Lambda/xi*.
    The question: does the Route-1 mass land where P(m) ~ O(1) (giving Omega
    ~ O(1)), rather than at the 1e9 peak or exponentially suppressed to zero?

RESULT (non-circular): at the Landau mass, P = 1.30, so (4N4/3)*P = 5.2 with
N4=3. The O(1) window (P in [0.5,5]) is only a factor ~1.1 wide in mass, on the
steep exponential slope -- and the independently-fixed Landau mass lands inside
it. Two disjoint inputs (N_Landau=35, eta_B-derived xi*=434) conspire to give
Omega ~ 5.2. This is a genuine overdetermination (weaker than a 0.1% Triangle,
but real and non-circular).

VERDICT: the ultra-heavy thermal picture PASSES this prova real -- the mass
scale is pinned by N_Landau AND independently lands in the eta_B-set thermal
window. The light (~14 GeV) asymmetric picture explored in this repo has NO such
overdetermination (it hit 3.65 by a single route).

IMPORTANT CAVEAT (kept honest): this favors the ultra-heavy MASS SCALE, but does
NOT rescue the document's N=4 body-number assignment -- the enumeration
falsifies stable N=4 singlets (zero exist; the lightest are N=9). So the open
problem is decoupled: the mass SCALE (~7.2e10 GeV) is overdetermined, but WHICH
stable state (N>=9) carries it -- and how the cascade level maps to body number
-- remains open. A third independent anchor is needed to fix that map.
"""

import math

LAM = 1.2662e12       # Lambda_meta (GeV)
M_P = 0.938           # proton mass (GeV)
EPS_PSI = 25/169
EPS_CONF = 4/9
N_NG = 0.749
ETA_B = 6.02e-10
N_LANDAU = 35


def xi_star_from_etaB():
    return (EPS_PSI * EPS_CONF * N_NG / ETA_B) ** (1/3)


def relic_product(m, xi):
    """P(m) = (m/m_p) * exp(-(m/Lambda)*xi); Omega = (4 N4/3) * P."""
    return (m / M_P) * math.exp(-(m / LAM) * xi)


def main():
    print("=" * 68)
    print("PROVA REAL: dark-matter mass-scale overdetermination")
    print("=" * 68)
    xi = xi_star_from_etaB()
    m_landau = 2 * LAM / N_LANDAU
    P = relic_product(m_landau, xi)
    print(f"xi* from eta_B (baryon sector, no DM input) = {xi:.1f}")
    print(f"Route 1 (Landau pole, 2*Lambda/35, no cosmology) = {m_landau:.3e} GeV")
    print(f"Relic product P at the Landau mass = {P:.3f}  (O(1))")
    print(f"Omega_DM/Omega_b = (4*N4/3)*P = 4*{P:.2f} = {4*P:.2f}  (obs 5.4)")
    print()
    # the O(1) window width
    peak_m = LAM / xi
    # right-branch masses where P = 0.5 and 5
    def solve_right(target):
        lo, hi = peak_m, 1e12
        for _ in range(200):
            mid = (lo + hi) / 2
            if relic_product(mid, xi) > target:
                lo = mid
            else:
                hi = mid
        return (lo + hi) / 2
    m_p5, m_5 = solve_right(0.5), solve_right(5.0)
    print(f"Thermal O(1) window (P in [0.5,5]): "
          f"[{m_5:.2e}, {m_p5:.2e}] GeV, width factor {m_p5/m_5:.2f}")
    print(f"Landau mass {m_landau:.2e} GeV lands INSIDE this window.")
    print()
    print("Two DISJOINT inputs (N_Landau=35; xi*=434 from eta_B) give Omega~5.2.")
    print("Non-circular overdetermination -> prova real PASSED for the ultra-")
    print("heavy thermal mass scale. (Light ~14 GeV asymmetric DM has no such")
    print("check.) CAVEAT: this fixes the MASS SCALE, not the body number; the")
    print("document's N=4 remains falsified (enumeration: zero stable N=4). The")
    print("cascade-level -> body-number map needs a third anchor.")


if __name__ == "__main__":
    main()
