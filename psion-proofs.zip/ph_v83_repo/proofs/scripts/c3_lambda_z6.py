"""
C3 — Derivação de Lambda_Z6 via running do glúon meta com N_f=0

Equação de running:
  mu * d(alpha_s)/dmu = -b0_PH/(2*pi) * alpha_s^2

com b0_PH = 13/6 (coeficiente beta do PH, T1).

Solução analítica:
  Lambda_Z6 = mu_0 * exp(-2*pi / (b0_PH * alpha_s(mu_0)))

Objetivo: encontrar alpha_s(mu_0) tal que Lambda_Z6 = m_e sem
usar m_e como input (a consistência é verificada a posteriori).

USO: python scripts/c3_lambda_z6.py
"""
import math
from fractions import Fraction

# ── Parâmetros PH (T1) ────────────────────────────────────────────────────────
b0_PH  = Fraction(13, 6)       # coeficiente beta do PH (T1)
N_E    = 10                    # N_e (T1)
B_E    = Fraction(325, 1152)   # b_e (T1)
ME     = 0.51099895e-3         # GeV — NÃO é input do cálculo C3;
                               # usado apenas para verificação final

# ── Escalas de referência ─────────────────────────────────────────────────────
M_Planck = 1.22e19   # GeV
M_GUT    = 1e16      # GeV
M_Pl_red = 2.44e18   # GeV (Planck reduzida)

print("="*65)
print("C3 — LAMBDA_Z6 VIA RUNNING DO GLÚON META (N_f=0)")
print("="*65)

print(f"""
Equação de running (b0 do PH, não SU(6)):
  mu * d(alpha)/dmu = -b0_PH/(2*pi) * alpha^2
  b0_PH = {b0_PH} = {float(b0_PH):.6f}

Solução analítica:
  alpha_s(mu) = alpha_s(mu_0) / [1 + b0_PH/(2*pi) * alpha_s(mu_0) * ln(mu/mu_0)]
  
  Lambda_Z6 = mu_0 * exp(-2*pi / (b0_PH * alpha_s(mu_0)))
""")

# ── Cálculo 1: dado Lambda_Z6 = m_e, qual alpha_s(mu_0)? ─────────────────────
print("─"*65)
print("CÁLCULO 1: alpha_s necessário para Lambda_Z6 = m_e")
print("─"*65)

for mu0_label, mu0 in [("M_Planck", M_Planck),
                        ("M_Planck_red", M_Pl_red),
                        ("M_GUT", M_GUT)]:
    log_ratio = math.log(ME / mu0)
    # Lambda = mu0 * exp(-2*pi/(b0*alpha))
    # log(Lambda/mu0) = -2*pi/(b0*alpha)
    # alpha = -2*pi/(b0 * log(Lambda/mu0))
    alpha_needed = -2*math.pi / (float(b0_PH) * log_ratio)
    alpha_inv = 1/alpha_needed
    print(f"\n  mu_0 = {mu0_label} = {mu0:.3e} GeV:")
    print(f"    alpha_s(mu_0) = {alpha_needed:.6f} = 1/{alpha_inv:.1f}")
    print(f"    (comparar: alpha_s(M_GUT) ~ 0.04 em GUTs padrão)")

# ── Cálculo 2: running explícito de M_Planck até Lambda_Z6 ──────────────────
print()
print("─"*65)
print("CÁLCULO 2: RUNNING EXPLÍCITO  M_Planck → Lambda_Z6")
print("─"*65)

# Dado alpha_s(M_Planck) ~ 0.0563 (de Cálculo 1),
# integra a ODE de M_Planck até encontrar Lambda_Z6

mu0    = M_Planck
alpha0 = -2*math.pi / (float(b0_PH) * math.log(ME / mu0))

print(f"\n  Condição inicial: alpha_s({mu0:.2e} GeV) = {alpha0:.8f}")
print(f"\n  Running alpha_s(mu) = alpha0 / [1 + b0/(2pi)*alpha0*ln(mu/mu0)]")
print()

# Tabela de running
scales = [M_Planck, 1e18, 1e16, 1e14, 1e12, 1e10, 1e8, 1e6, 1e3, 1e0,
          1e-3, ME]
labels = ["M_Pl", "10^18", "10^16(GUT)", "10^14", "10^12",
          "10^10", "10^8", "10^6", "1 TeV", "1 GeV", "1 MeV", "m_e"]

print(f"  {'Escala (GeV)':>18} {'Label':>12}  {'alpha_s':>10}  {'1/alpha_s':>10}")
print("  " + "─"*58)

for mu, label in zip(scales, labels):
    ln_ratio = math.log(mu/mu0)
    denom    = 1 + float(b0_PH)/(2*math.pi) * alpha0 * ln_ratio
    if denom <= 0:
        print(f"  {mu:>18.3e} {label:>12}  [Landau pole]")
        break
    alpha_mu = alpha0 / denom
    mark = " ← m_e" if abs(mu - ME) < ME*0.1 else ""
    print(f"  {mu:>18.3e} {label:>12}  {alpha_mu:>10.6f}  {1/alpha_mu:>10.2f}{mark}")

# ── Cálculo 3: Lambda_Z6 explícita ───────────────────────────────────────────
print()
print("─"*65)
print("CÁLCULO 3: LAMBDA_Z6 ANALÍTICA")
print("─"*65)

Lambda_Z6 = mu0 * math.exp(-2*math.pi / (float(b0_PH) * alpha0))
print(f"\n  Lambda_Z6 = mu0 * exp(-2*pi/(b0*alpha0))")
print(f"            = {mu0:.3e} * exp({-2*math.pi/(float(b0_PH)*alpha0):.4f})")
print(f"            = {Lambda_Z6:.6e} GeV")
print(f"            = {Lambda_Z6*1e3:.6f} MeV")
print()
print(f"  Valor observado m_e = {ME*1e3:.6f} MeV")
print(f"  Razão Lambda_Z6/m_e = {Lambda_Z6/ME:.8f}")

if abs(Lambda_Z6/ME - 1.0) < 1e-6:
    print(f"\n  ✓ CONSISTENTE: Lambda_Z6 = m_e por construção do alpha_s escolhido")
else:
    print(f"\n  Desvio: {100*(Lambda_Z6/ME-1):.4f}%")

# ── Cálculo 4: o ponto crucial — sem usar m_e ─────────────────────────────────
print()
print("─"*65)
print("CÁLCULO 4: CONDIÇÃO DE FECHAMENTO SEM m_e")
print("─"*65)
print(f"""
O cálculo acima usou m_e para DETERMINAR alpha_s(M_Planck).
Isso não elimina a circularidade.

Para C3 ser genuíno (sem m_e):
  alpha_s(M_Planck) deve vir de uma condição INDEPENDENTE,
  como a equação de Schwinger-Dyson do glúon meta em forma fechada.

A equação de SD do glúon meta (N_f=0, 1-loop rainbow-ladder):
  D^{{-1}}_mu_nu(p) = D_0^{{-1}}_mu_nu(p) + Pi_mu_nu(p)

  Pi_mu_nu(p) ~ g^2 * b0_PH / (4*pi) * p^2 * [ln(p^2/mu^2) + constante]

A condição de confinamento (polo de massa dinâmica m_g → 0):
  D^{{-1}}(0) = 0  →  Pi(0) = D_0^{{-1}}(0)

Para o glúon meta MASSLESS em D_0:
  Pi(0) = 0 → condição trivial. Não dá Lambda_Z6.

Para o glúon meta MASSIVO (m_Z6 ≠ 0):
  A escala m_Z6 reintroduz m_e via m_Z6 = 6*f_pi ~ m_e.
  Circularidade retorna.

SAÍDA: condição de Landau pole do setor Z6 puro.
  Alpha_s diverge em Lambda_Z6 (polo de Landau).
  alpha_s(mu) → ∞ quando mu → Lambda_Z6.
  
  Isso define Lambda_Z6 SEM m_e:
    Lambda_Z6 = mu_0 * exp(-2*pi/(b0_PH*alpha_s(mu_0)))
  
  com alpha_s(mu_0) determinado pela condição de unificação
  em mu_0 = M_Planck (onde alpha_meta ~ alpha_gravitacional).

  A QUESTÃO ABERTA: qual é alpha_s(M_Planck) do setor meta?
  Se a resposta for alpha_s ~ 0.056 (de algum princípio de unificação),
  C3 está provado. Se não, C3 requer um cálculo adicional.
""")

# ── Sumário ───────────────────────────────────────────────────────────────────
print("="*65)
print("SUMÁRIO DE C3")
print("="*65)
print(f"""
STATUS:
  ✓ Equação de running com b0_PH = 13/6 (correto para Z6, não SU(6))
  ✓ Fórmula analítica: Lambda_Z6 = mu0*exp(-2*pi/(b0_PH*alpha0))
  ✓ Verificação: alpha_s(M_Planck) ~ 0.056 fisicamente razoável
  
  ✗ AINDA ABERTO: alpha_s(M_Planck) não foi derivado da SD do glúon
    meta de forma independente de m_e.
  
RESULTADO NUMÉRICO:
  alpha_s(M_Planck) = {alpha0:.6f} ← necessário para Lambda_Z6 = m_e
  b0_PH = {float(b0_PH):.6f}
  Lambda_Z6 = {Lambda_Z6:.6e} GeV = {Lambda_Z6*1e3:.4f} MeV

PRÓXIMO PASSO PARA T1:
  Derivar alpha_s(M_Planck) ~ {alpha0:.4f} da condição de unificação
  do setor meta em M_Planck, sem input de m_e.
  
  Candidato: alpha_meta(M_Planck) = alpha_gravitacional(M_Planck)
  onde alpha_gravitacional = G_N * M_Planck^2 / (4*pi) = ?
""")

G_N = 6.674e-39  # GeV^-2
alpha_grav = G_N * M_Planck**2 / (4*math.pi)
print(f"  alpha_gravitacional(M_Planck) = G_N*M_Pl^2/(4*pi) = {alpha_grav:.4f}")
print(f"  vs alpha_s necessário = {alpha0:.4f}")
print(f"  Razão: {alpha_grav/alpha0:.4f}")
print()
if abs(alpha_grav - alpha0)/alpha0 < 0.5:
    print("  ✓ Mesma ordem de grandeza! A condição de unificação")
    print("    alpha_meta(M_Planck) = alpha_grav(M_Planck) pode fechar C3.")
else:
    print(f"  Diferença de fator {alpha_grav/alpha0:.2f}.")
    print("  A condição de unificação precisa de ajuste.")

