#!/usr/bin/env bash
# Run every proof in proofs/ and the table generator. Exits non-zero if any
# proof fails -- suitable for CI.
set -euo pipefail
cd "$(dirname "$0")/.."

echo "########################################################################"
echo "# Psion Hypothesis -- Calculation Memory : full verification run"
echo "########################################################################"

fail=0
for p in proofs/P_*.py; do
  echo
  echo ">>> $p"
  if ! python3 "$p"; then
    fail=1
  fi
done

echo
echo ">>> regenerating didactic tables"
python3 scripts/generate_tables.py

echo
if [ "$fail" -ne 0 ]; then
  echo "RESULT: one or more proofs FAILED."
  exit 1
fi
echo "RESULT: all proofs verified, all tables regenerated."
