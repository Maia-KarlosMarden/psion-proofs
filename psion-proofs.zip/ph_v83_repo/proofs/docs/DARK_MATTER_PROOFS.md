# Dark Matter Sector — Complete Proof Inventory

This document details every claim in §13 of PH_Foundations_v79, with
the proof location, method, and epistemic status for each.

---

## §13.1 — Stable Z₆ Singlets (T1)

### Theorem DM.1: 39 stable neutral singlets at N ∈ {9,12,15,18,21,27}

**What is proved:** A composite of N psions is a stable dark singlet iff:
1. Q = 0 (zero proto-colour charge: Σ Q9(kᵢ) = 0)
2. I ∈ {0, 3} (triality: Σkᵢ mod 6 ∈ {0,3})
3. Stable: no proper, non-empty sub-multiset of the constituents is itself
   a neutral singlet (no fragmentation channel N -> N1 + N2 into neutral
   singlets). Single-psion removal is not a valid test: no psion is neutral
   (9Q_k in {1,-5,-5,10,4,4}), so it never detects an instability.

**Proof method:** Reachability DP over (9Q, I) with a size bitmask,
cross-checked by explicit enumeration of every proper sub-multiset
(occupation-number vectors) for all N ≤ 27. Also verified: N = 6 has six
neutral singlets, all of which fragment into N = 3 neutral states; and
Q = 0 requires N ≡ 0 (mod 3), since 9Q_k ≡ 1 (mod 3).

**Code:** `proofs/P_dark_matter.py` — Steps A (enumeration), B (stability),
C (termination).

**Termination proof:** The antipodal subfamily {k:m, (6-k):n} requires
N = 9j. At j=4 (N=36), triality I = 2 ∉ {0,3} → not a singlet. The
family closes at j=3 (N=27). Brute-force scan to N=48 confirms zero
stable singlets for N > 27.

**Status: T1** (exact, two independent algorithms agree, falsifiable by
any observation of a stable dark composite at N=4 or N>27).

### Corollary DM.2: No stable N=4 state exists

Direct output of the enumeration. The three tuples previously cited
(0,1,2,3), (0,1,3,5), (1,2,4,5) are NOT stable: each has an accessible
neutral-singlet intermediate state. The enumeration finds zero stable
N=4 neutral singlets.

**Code:** `proofs/P_dark_matter.py` Step A (verified independently).

---

## §13.2 — Dark Matter Mass (T2, overdetermined)

### Claim: m_DM = 2Λ_meta/N_Landau = 7.235×10¹⁰ GeV

**Route 1 (Landau pole):** N_Landau = 35 counts the cascade modes from
the condensate to the Landau pole. m_DM = 2Λ/35. No cosmology used.

**Route 2 (thermal balance, prova real):** The product
  P(m) = (m/m_p) × exp(−(m/Λ)×ξ*)
is O(1) only in a narrow mass window (factor ~1.1 wide) on the steep
exponential slope. The Landau mass lands inside this window, giving
P = 1.30. ξ* = 434 comes from η_B (baryon sector, no DM input).

**Non-circularity:** Route 1 uses Λ and N_Landau=35. Route 2 uses
Λ, ξ*=434 (from η_B), and the thermal-balance condition. These share
Λ but use disjoint secondary inputs (35 vs 434). Agreement to 1%.

**Code:** `scripts/dm_prova_real.py`

**Cascade level independence:** The three bosonic anchors prove that
cascade level is independent of body number:
  h_AB: N=2, level 8, mass 0.613 GeV
  X17:  N=2, level 9, mass 17.7 MeV
  electron: N=3, level 10, mass 0.511 MeV
h_AB and X17 share N=2 but sit at different levels → level ≠ f(N).
**Code:** `scripts/cascade_level_anchors.py`

**Status: T2** (overdetermined by two independent routes, prova real passed).

---

## §13.3 — Relic Density (T2 inference / T2+ direct)

### Inference route: Ω_DM = 1 − Ω_Λ(PH) − Ω_b(PH)

**Derivation:**
  Ω_Λ(PH): from Theorem P16 (T1), ρ_Λ = (Nc/27π⁴)Λ⁴exp(−S),
            S = 6N_e/b_eff = 212.68. Gives ρ_Λ = 2.534×10⁻⁴⁷ GeV⁴.
  Ω_b(PH): from η_B = ε_ψ ε_conf (n/n_γ)/ξ*³ (T2), ρ_b = m_p η_B n_γ.
  Ω_total = 1: Planck 2018 (k = 0.0007 ± 0.0019); motivated by PH
               (homogeneous condensate → k=0).

**Observational inputs declared:**
  H₀ = 67.36 km/s/Mpc (Planck 2018) — for ρ_crit = 3H₀²/8πG_N
  T_CMB = 2.7255 K (FIRAS) — for n_γ = (2ζ(3)/π²)T_CMB³
  Ω_total = 1 (Planck 2018)

**Result:** Ω_DM/Ω_b = 5.40 (0.8% error vs Planck 5.357).
**Code:** `scripts/dm_prova_real.py` (mass scale); P16 proof in document §3.2.
**Status: T2** (correct by conservation; condicional on H₀, T_CMB, Ω_total=1).

---

### Direct route: Ω_DM/Ω_b = (4π/3)·(m_DM/m_p)·exp(−ξ*_DM)

**Structure:**
  Ω_DM/Ω_b = (m_DM/m_p) × (Y_DM/Y_b)
  Y_DM/Y_b = (g_dark/g_bar) × exp(−ξ*_DM)
  g_dark/g_bar = 4π/3  [prefactor, under derivation]
  ξ*_DM = (m_DM/Λ) × ξ* = (2/35) × 434 = 24.806

**T_CMB-independence proof (T1):**
  Step 1: n_i(T) = Y_i × s(T). In the ratio n_DM/n_b, s(T) cancels
          identically for any T — including T_CMB today. Result is the
          comoving yield ratio Y_DM/Y_b, independent of when evaluated.
  Step 2: At nucleation, n_i ∝ g_i × T_nuc³/(2π²). In the ratio,
          T_nuc³ and (2π²) cancel. Y_DM/Y_b = g_dark/g_bar × exp(−ξ*_DM).
  Step 3: Only m_DM, m_p, g_dark/g_bar, ξ* remain — all PH-derived.
          T_CMB appears nowhere. QED.
  Numerical verification: Ω_DM/Ω_b = 5.451 at T_nuc, 1 MeV, 1 eV,
  T_CMB — identical at all temperatures.
  **Code:** `scripts/proof_T_CMB_cancels.py`

**The exponential factor exp(−ξ*_DM):**
  ξ* = (ε_ψ ε_conf n/n_γ / η_B)^(1/3) = 434 [from baryon sector, T2]
  ξ*_DM = (2/35) × 434 = 24.806
  exp(−ξ*_DM) = 1.687×10⁻¹¹ [structural, shared with baryogenesis]
  This factor is derived and overdetermined (same ξ* as η_B).

**The mass factor m_DM/m_p:**
  m_DM = 2Λ/35 (prova real, T2), m_p = 0.938 GeV (PDG).
  m_DM/m_p = 7.714×10¹⁰.

**The prefactor 4π/3:**
  g_dark/g_bar = 4π/3 has geometric motivation: the Z₃ colour factor
  of the Z₆ condensate acts on S² ⊂ R³ with Vol(S²) = 4π; the baryon
  (N_bar=3 body) sets the normalisation N_bar. Physical interpretation:
  isotropic SO(3) production at the Z₆ first-order phase transition.
  Status: T2+ (geometrically motivated, numerically consistent, formal
  proof of SO(3) isotropy pending).
  Error with this prefactor: 1.75% vs Planck 5.357.

**Result:** Ω_DM/Ω_b = (4π/3) × 7.714×10¹⁰ × 1.687×10⁻¹¹ = 5.451
**Status: T2+** (exponential and mass factors derived; prefactor T2+).

---

## Summary table

| Claim | Value | Error | Status | Code |
|---|---|---|---|---|
| Stable dark states | 39 at N∈{9,…,27} | exact | T1 | P_dark_matter.py |
| Termination (N>27 has zero) | proved | exact | T1 | P_dark_matter.py |
| N=4 has zero stable states | proved | exact | T1 | P_dark_matter.py |
| Cascade level ⊥ body number | three anchors | exact | T1 | cascade_level_anchors.py |
| m_DM = 2Λ/35 | 7.235×10¹⁰ GeV | 1% (prova real) | T2 | dm_prova_real.py |
| T_CMB-independence of Ω_DM/Ω_b | proved | exact | T1 | proof_T_CMB_cancels.py |
| ξ*_DM = 24.806 | from η_B | — | T2 | P_eps_psi.py |
| exp(−ξ*_DM) = 1.687×10⁻¹¹ | structural | — | T2 | P_eps_psi.py |
| Ω_DM/Ω_b (inference) | 5.40 | 0.8% | T2 | dm_prova_real.py |
| Ω_DM/Ω_b (direct) | 5.451 | 1.75% | T2+ | proof_T_CMB_cancels.py |

---

## Open problems in the dark matter sector

**P-prefactor (open):** Prove that g_dark/g_bar = 4π/N_bar from the
Z₆ moduli space geometry. Specifically: show that composite production
at the Z₆ nucleation is isotropic under SO(3), with the Z₃ colour factor
contributing Vol(S²)/N_bar = 4π/N_bar to the effective degeneracy ratio.
Tools: theory of representations of Z₃ on S²; geometry of the Z₆ condensate
moduli space at T_nuc.

**P-T_CMB (open):** Derive T_CMB (or equivalently the cooling factor
T_CMB/T_nuc = 8×10⁻²³) from the Z₆ condensate thermodynamics. Would
eliminate the last observational input from Ω_DM/Ω_b (direct route)
and close the inference route to a pure PH prediction. Tools: NJL gap
equation at finite T (P26 programme).
