# QFT Pipeline: Derivação do Prefator de Abundância da DM no PH

**Documento para IA executora**  
**Problema:** Derivar o prefator P na expressão
   Ω_DM/Ω_b = P × (m_DM/m_p) × exp(−ξ*_DM)
de primeiros princípios, usando QFT a temperatura finita (formalismo de Matsubara).

**Target:** P ≈ 4.15 (para reproduzir Ω_DM/Ω_b = 5.4 observado).  
**Critério de sucesso:** P calculado independentemente concorda com 4.15 a menos de 50% (ordem de grandeza), ou discorda e fornece a predição real do PH.

---

## ENTRADAS FIXAS (não ajustar)

```python
LAM    = 1.2662e12   # GeV  — Lambda_meta, escala do condensado Z6
g2     = 2*pi**2/3   # adim — acoplamento NJL no ponto fixo UV (beta=0)
xi_s   = 434.1       # adim — parâmetro de supercooling (de eta_B)
T_nuc  = LAM/xi_s    # GeV  — temperatura de nucleação
m_DM   = 2*LAM/35    # GeV  — massa DM (escala de Landau, prova real)
m_p    = 0.938       # GeV  — massa do próton
N_dark = 39          # int  — estados escuros estáveis (N>=9, enumerados)
N_bar  = 2           # int  — estados bariônicos (próton + nêutron)
```

---

## ESTRUTURA DO PROBLEMA

O prefator P é a razão de yields de número:

```
P = Y_DM / (Y_b × exp(−xi*_DM))
```

onde Y_i = n_i/s é o yield comoving de cada espécie (densidade de número /
entropia). No ensemble grand-canônico da transição Z6 de primeira ordem:

```
n_i = g_i × T³/(2π²) × ∫₀^∞ dp p² / (exp((E_i − N_i×μ)/T) ± 1)
```

Para partículas não-relativísticas (m >> T_nuc):

```
n_i ≈ g_i × (m_i T / 2π)^(3/2) × exp(−(m_i − N_i×μ)/T)
```

O potencial químico μ = μ_psion é determinado pela equação do gap NJL.

---

## PASSO 1 — Equação do Gap NJL a T finita e μ finito

### Objetivo
Determinar μ(T_nuc) da equação de número do condensado.

### A equação do gap NJL em 3+1D (modelo de Nambu–Jona-Lasinio):

```
1/G = 4Nc × ∫ d⁴p/(2π)⁴ × 1/(p² + σ²)   [T=0, regularizado]
```

A temperatura finita (formalismo de Matsubara), a equação de gap para
o condensado σ (VEV do psion) é:

```
σ/G = 2Nc × T × Σ_n ∫ d³p/(2π)³ × σ / (ω_n² + p² + σ²)
```

onde ω_n = (2n+1)π T são as frequências de Matsubara fermiônicas.

**Parâmetros específicos do PH:**
- Nc = 6 (número de estados internos Z6)
- G = g²/(2Λ²) = (2π²/3)/(2Λ²)  [acoplamento de contato NJL]
- Regularização UV: corte em Λ_meta (o condensado forma-se exatamente em Λ)
- σ₀ = m_e = 0.511 MeV (VEV do condensado a T=0, fixa G)

### Equação de número (conservação do número de psions):

```
n_psion = 2Nc × ∫ d³p/(2π)³ × [f_F(E−μ) − f_F(E+μ)]
```

onde E = √(p² + σ²) e f_F é a distribuição de Fermi-Dirac.

### Procedimento de cálculo:

```python
# Passo 1a: calibrar G a T=0
# Condição: σ(T=0, μ=0) = sigma_0 = m_Z6 (massa do modo de condensado)
# Do documento: m_Z6 = 2.9961 MeV (resultado XL-1)
sigma_0 = 2.9961e-3  # GeV

# Resolver a equação do gap a T=0 para G:
# 1/G = 4*Nc * integral_0^Lambda dp p^2/(2pi^2) * 1/sqrt(p^2+sigma_0^2)
import numpy as np
from scipy import integrate, optimize

Nc = 6
def gap_T0(sigma, G, Lambda):
    """Gap equation at T=0: returns 1/G - integral"""
    def integrand(p):
        E = np.sqrt(p**2 + sigma**2)
        return p**2 / E
    I, _ = integrate.quad(integrand, 0, Lambda)
    return 1/G - 4*Nc/(2*np.pi**2) * I

# Solve for G given sigma_0
# G_NJL from the UV fixed point: G = g^2/(2*Lambda^2)
G_UV = (2*np.pi**2/3) / (2*LAM**2)
# Verify gap equation is satisfied at sigma_0; if not, use sigma_0 to fix G.

# Passo 1b: Resolver gap + número a T=T_nuc
# Variáveis: (sigma, mu). Duas equações:
#   (i)  gap equation at T_nuc, mu
#   (ii) number equation: n_psion(T_nuc, mu) = n_psion_0
# 
# n_psion_0 é o número total de psions no condensado — ESTA É A INCÓGNITA
# ADICIONAL. Para fechá-la, usar a condição de transição de fase:
#   A T=T_nuc, o condensado nucleia: sigma cai de sigma_0 para 0 (transição
#   de primeira ordem). No ponto de nucleação, as duas fases coexistem.
#   Condição: pressão da fase condensada = pressão da fase livre.
#   P_cond(T_nuc, mu) = P_free(T_nuc, mu)

def pressure_condensed(T, mu, sigma, G, Lambda, Nc):
    """Grand potential / volume da fase condensada"""
    # Omega = sigma^2/(2G) - Nc * T * Σ_n ∫ dp/(2pi)^3 log(ωn^2 + p^2 + σ^2)
    # Equivalente (após soma de Matsubara):
    def integrand(p):
        E = np.sqrt(p**2 + sigma**2)
        fp = 1/(np.exp((E-mu)/T)+1)
        fm = 1/(np.exp((E+mu)/T)+1)
        return p**2 * (E + T*np.log((1+np.exp(-(E-mu)/T))) 
                          + T*np.log((1+np.exp(-(E+mu)/T))))
    I, _ = integrate.quad(integrand, 0, Lambda)
    return -sigma**2/(2*G) + 2*Nc/(2*np.pi**2) * I

def pressure_free(T, mu, Lambda, Nc):
    """Pressão da fase livre (sigma=0)"""
    return pressure_condensed(T, mu, 0.0, 1e99, Lambda, Nc)

# Encontrar T_nuc e mu_nuc da condição P_cond = P_free + pressão do latente
# (condição de Maxwell para transição de primeira ordem)
```

---

## PASSO 2 — Abundâncias dos Composites no Ensemble Grand-Canônico

Com μ(T_nuc) determinado no Passo 1, calcular n_i para cada espécie.

### Para cada estado escuro i (dos 39 estáveis):

```python
def n_composite(m_i, N_i, g_i, T, mu):
    """
    Densidade numérica de um composite N_i-body no limite não-relativístico.
    m_i:  massa do estado (GeV)
    N_i:  número de corpos (Z6 body number)
    g_i:  degenerescência interna (multiplicidade Z6 × spin)
    T:    temperatura de nucleação
    mu:   potencial químico do psion
    """
    mu_eff = N_i * mu  # potencial químico do composite
    # Limite não-relativístico: m_i >> T
    if m_i > 10*T:
        return g_i * (m_i*T/(2*np.pi))**1.5 * np.exp(-(m_i - mu_eff)/T)
    else:
        # Usar distribuição completa de Fermi-Dirac ou Bose-Einstein
        # DM é bosônica (N_i par) ou fermiônica (N_i ímpar)?
        # N=9,15,21,27 são ímpares -> fermiônica. N=12,18 são pares -> bosônica.
        stat = -1 if N_i % 2 == 0 else +1  # -1 Bose, +1 Fermi
        def integrand(p):
            E = np.sqrt(p**2 + m_i**2)
            return p**2 / (np.exp((E - mu_eff)/T) + stat)
        I, _ = integrate.quad(integrand, 0, 10*m_i)
        return g_i / (2*np.pi**2) * I
```

### Para os bárions (próton e nêutron):

```python
# Próton: N=3, g_p = mult(0,4,5)*2 = 6*2 = 12 (mult × spin-1/2)
# Nêutron: N=3, g_n = mult(0,1,5)*2 = 6*2 = 12
# (Corrected to match PH_Foundations Appendix H / CHARGE_CONVENTIONS.md §3a:
#  proton=(0,4,5) Q=+1, neutron=(0,1,5) Q=0; (3,4,5) is the separate Q=+2
#  exotic state and was never the proton. g_p=g_n=12 is unchanged by this
#  correction since both corrected tuples also have all-distinct indices
#  (mult=6), so no downstream n_baryon numbers in this pipeline change.)
# mu_baryon_eff = 3 * mu_psion

n_proton  = n_composite(m_p,  3, 12, T_nuc, mu)
n_neutron = n_composite(m_n,  3, 12, T_nuc, mu)
n_baryon  = n_proton + n_neutron
```

### Degenerescências dos estados escuros:

```python
# Usar a enumeração do repositório psion-proofs:
# from proofs.P_dark_matter import enumerate_dark_states
# dark_states = [(tuple_t, mult_t, N_t) for each of the 39 states]
#
# Spin do composite: J=0 para singletos escalares (g_spin=1)
# per documento F5: DM tem J=0.
# g_i = mult(t) * 1  (spin-0)

n_DM_total = sum(
    n_composite(m_DM, len(t), mult(t)*1, T_nuc, mu)
    for t in dark_states
)
```

---

## PASSO 3 — Cálculo do Prefator P

```python
# Yield Y_i = n_i / s, onde s = entropia por volume
# s = (2π²/45) * g_*S * T³
# Na razão Y_DM/Y_b, a entropia s cancela:

ratio_number = n_DM_total / n_baryon

# O prefator P (separando o fator de Boltzmann exp(-xi*_DM)):
import math
xi_DM = (m_DM/LAM) * xi_s
P = ratio_number / math.exp(-xi_DM)

# Omega_DM/Omega_b (verificação):
Omega_ratio = (m_DM/m_p) * ratio_number
print(f"P = {P:.4f}")
print(f"Omega_DM/Omega_b = {Omega_ratio:.4f}  (target: 5.4)")
```

---

## PASSO 4 — Verificação e Prova Real Interna

### Verificação 1: conservação de número de psions

```python
# n_psion_total (do condensado) deve igualar a soma:
# sum_i N_i * n_i, over ALL composites (dark + baryonic + leptonic)
n_psion_from_composites = (
    sum(len(t)*n_composite(m_DM,len(t),mult(t),T_nuc,mu) for t in dark_states)
    + 3*n_baryon
    # + leptons + neutrinos (adicionar da mesma forma)
)
n_psion_condensate = n_condensate(sigma, T_nuc, mu)  # do Passo 1
residual = abs(n_psion_from_composites - n_psion_condensate)/n_psion_condensate
assert residual < 0.01, f"Number conservation violated: {residual:.2%}"
```

### Verificação 2: reproduzir η_B (prova real independente)

```python
# A mesma mu(T_nuc) deve reproduzir eta_B via:
# eta_B = eps_psi * eps_conf * (n/n_gamma) * xi*^(-3)
# Se mu é consistente com a bariogênese Z6, este número sai automaticamente.
eta_B_check = (n_baryon - n_antibaryon) / n_gamma
assert abs(eta_B_check - 6.02e-10)/6.02e-10 < 0.01, "eta_B not reproduced"
```

### Verificação 3: prova real do prefator (rota independente)

```python
# Calcular P também como:
# P = (4*N4/3) onde N4 é o número efetivo de "gerações" de DM
# derivado da contagem de estados ponderados pela abundância:
N4_eff = n_DM_total / n_DM_single_species  # espécie dominante
P_check = (4*N4_eff/3)
assert abs(P_check - P)/P < 0.1, "Prefator inconsistente entre rotas"
```

---

## PASSO 5 — Sensibilidade e Incertezas

```python
# Variar T_nuc em ±10% (incerteza em xi*):
for delta_xi in [-0.1, 0, +0.1]:
    xi_var = xi_s * (1 + delta_xi)
    T_var = LAM/xi_var
    # Re-resolver Passo 1 e 2 com T_var
    # Reportar variação em P e Omega

# Variar m_DM em ±5% (incerteza em N_Landau):
for delta_m in [-0.05, 0, +0.05]:
    m_var = m_DM * (1 + delta_m)
    # Re-calcular xi_DM e Omega
    
# Resultado: P ± delta_P, Omega ± delta_Omega
```

---

## RESULTADO ESPERADO E CRITÉRIOS DE FALSIFICAÇÃO

| Resultado | Interpretação |
|---|---|
| P ∈ [3, 6] e Omega ∈ [4, 8] | Framework consistente. T2→T2+ upgrade. |
| P ∈ [1, 10] mas Omega ≠ 5.4 ± 30% | Estrutura OK, N_Landau ou m_DM precisam revisão. |
| P << 1 ou P >> 10 | Mecanismo de produção diferente do esperado. Investigar. |
| Equação do gap não converge em T_nuc | T_nuc está fora da fase de transição. Revisar xi*. |
| n_DM < n_baryon × 10^{-12} | Overclosure impossível → DM é subdominante → framework em tensão com observação. FALSIFICADOR. |

---

## DEPENDÊNCIAS E FERRAMENTAS

```python
# Pacotes necessários:
import numpy as np
from scipy import integrate, optimize
from itertools import combinations_with_replacement
from collections import Counter
from math import factorial

# Do repositório psion-proofs:
# proofs/P_dark_matter.py  — enumeração dos 39 estados estáveis
# proofs/P_eps_psi.py      — eps_psi, eta_B, xi*
# scripts/dm_prova_real.py — m_DM e a prova real da escala

# Referências de QFT a T finita:
# - Kapusta & Gale, "Finite Temperature Field Theory" (Cambridge, 2006)
# - Buballa, Phys. Rept. 407 (2005) — NJL model reviews
# - equação do gap NJL a T,mu finitos: eqs. (2.18)-(2.20) de Buballa
```

---

## ORDEM DE EXECUÇÃO

```
1. Calibrar G do gap a T=0 com sigma_0 = m_Z6 = 2.9961 MeV
2. Resolver gap+número a T=T_nuc para (sigma, mu) — sistema 2×2
3. Com mu fixo, calcular n_i para cada um dos 39 estados escuros
4. Calcular n_baryon (proton + neutron) com mesmo mu
5. Formar ratio_number = n_DM_total / n_baryon
6. Calcular P = ratio_number / exp(-xi*_DM)
7. Calcular Omega = (m_DM/m_p) * ratio_number
8. Executar verificações 1-3
9. Executar análise de sensibilidade (Passo 5)
10. Reportar P, Omega, incertezas, e classificação epistêmica resultante
```

---

## NOTAS PARA A IA EXECUTORA

1. **Não ajustar nenhuma entrada.** Todas as constantes em "ENTRADAS FIXAS"
   são derivadas de primeiros princípios no PH e não são parâmetros livres.

2. **A equação do gap pode ter múltiplas soluções.** Escolher a solução com
   σ > 0 (fase condensada) que satisfaz P_cond > P_free (termodinâmicamente
   preferida). Se duas soluções existirem com pressões iguais, estamos
   exatamente em T_nuc — isso é o ponto de operação correto.

3. **Se o cálculo der P fora de [1,10]:** não "corrigir" — reportar o valor
   honestamente e diagnosticar qual hipótese física está falhando.

4. **Classificação epistêmica:** Se Omega ∈ [4,8] sem ajuste → upgrade para
   T2+. Se Omega ∈ [4.8, 5.9] (±10% do 5.4) → candidato a T1 após revisão.

5. **Adicionar ao repositório:** salvar o script completo em
   `scripts/qft_prefactor.py` e o resultado em `docs/QFT_RESULT.md`.
