# Note on Section 12 (Baryogenesis) under aggregate-only charge conjugation

**Status:** companion to `CHARGE_CONVENTIONS.md` §3b-3c. Read those sections first —
this note only states the consequence for Section 12 of `PH_Foundations_v83`.

## What changed

`CHARGE_CONVENTIONS.md` §3b proved that state-wise charge conjugation
(`Q_k = -Q_{(6-k) mod 6}` for every individual psion state `k`) is
incompatible with Theorem V.1's own charge values (Q_0=1/9, Q_3=10/9,
neither zero as required), independent of which triple is labelled proton
or neutron -- an earlier draft had mislabelled that pair, corrected in
§3a there, without affecting this conclusion. §3c closed the conjugation-
map-extension option by exhaustive search and left the Q_k-retuning option
open but unadopted (it would change the published (3,4,5)=+2 exotic-state
charge to +1). Adopted: conjugation is retained only as an **aggregate**
identity over the composite spectrum, not as an exact per-state operator.

## What this means for the first line of Section 12

Section 12.1 lists the three Sakharov conditions as satisfied "without BSM
ingredients," with condition (2) stated as "C and CP violation via the Z6
chiral structure." As written, this presumes C is a well-defined operator
that the Z6 chiral structure then violates — i.e., a symmetry that could in
principle hold exactly, broken by a specific dynamical effect.

Under the resolution in §3c, C is not well-defined **state-wise** in the
first place: there is no consistent per-state charge assignment for which
`Q_k = -Q_{conj(k)}` holds for every psion state simultaneously with the
particle content already fixed (three -1 leptons, integer-charge baryons).
"C violation" in Section 12 must therefore be read as a statement about
**production-rate asymmetry between composite species and their conjugate
partners in the thermal ensemble** (the quantity that actually enters the
Boltzmann/rate-equation calculation of eta_B), not as the breaking of an
exact discrete symmetry operator acting on individual psion states.

## What is and is not affected numerically

- **Unaffected:** the value eta_B = 6.02e-10 (0.4%, T2 candidate) and its
  derivation pipeline. The rate-equation calculation never required a
  state-wise C operator — it uses production/decay rate differences between
  composite channels, which is exactly the aggregate quantity that survives
  under §3c.
- **Affected (interpretation only):** the physical reading of what
  "violated" means in "C and CP violation via the Z6 chiral structure." It
  is no longer a statement about an exact symmetry of the underlying
  Lagrangian being broken by a specific term; it is a statement about
  asymmetric composite-formation statistics. Sakharov's condition (2) only
  requires *some* form of C/CP asymmetry in the relevant rates — an ensemble
  asymmetry satisfies the condition as stated by Sakharov (1967) without
  requiring an exact per-state C operator to exist. The condition itself is
  therefore still met; only the PH-internal story of *why* has changed.

## Suggested one-line insertion for Section 12.1

> "C here denotes an aggregate asymmetry in composite production rates
> across the Z6 spectrum (Appendix, `CHARGE_CONVENTIONS.md` §3c), not an
> exact per-state operator on individual psion states; see that document for
> the impossibility proof (§3b) motivating this reading."

## T-level bookkeeping

- eta_B numerical result and error: **unchanged**, T2 candidate as before.
- "C is an exact state-wise symmetry of the psion Lagrangian": **T1,
  falsified** (CHARGE_CONVENTIONS.md §3b, independent of particle labelling; §3a documents an unrelated tuple-labelling correction).
- "C/CP asymmetry (aggregate sense) satisfies Sakharov condition 2": **T1**,
  since this is definitionally what the rate-equation calculation already
  computes — no new derivation required, only the relabeling above.
