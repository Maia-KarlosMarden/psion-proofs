# Charge Conventions and Open Reconciliation Items

This document is part of the **calculation memory**. Its purpose is to record,
honestly and explicitly, where the PH source material carries more than one
charge convention and where those conventions do **not** fully reconcile. None
of this is hidden inside the tables: every affected row in `tables/` carries a
`Note` column pointing here.

This is a feature, not a defect. A calculation memory exists precisely to make
such tensions visible and falsifiable, in the Popperian spirit of the
framework: a result that cannot be reproduced from the stated rules is flagged,
not quietly patched.

---

## 1. The two charge schemes in PH Foundations

### Scheme A — fundamental (Section 1 / Theorem V.1)

```
Q_k = q_(k mod 3) + floor(k/3),   q = (1/9, -5/9, -5/9)
```

| k | 0 | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|---|
| Q_k | +1/9 | -5/9 | -5/9 | +10/9 | +4/9 | +4/9 |

This is the canonical scheme of the engine (`Psion.Q`, `Composite.Q`). It gives
the **exact** structural result

```
Sum_k Q_k = 1        (the resolved v77 erratum; the Z2 shift contributes +3)
```

verified in `proofs/P_charge_algebra.py`.

### Scheme B — observable proto-quark (Appendix H)

The per-constituent "observable" charges that reproduce the integer hadron
charges at low Q^2:

| k | 0 | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|---|
| Q_k^obs | +1/9 | -5/9 | -5/9 | +1/9 | +4/9 | +4/9 |

This is exposed as `Psion.Q_obs` / `Composite.Q_obs`. It reproduces
`Q(proton) = +1` (App. H states +1/9 + 4/9 + 4/9 = +1).

---

## 2. Where the schemes agree

- The **electron** `(0,1,2)`: `Q = -1` in **both** schemes, matching the
  identity table. ✓
- **Triality / colour-singlet** classification `I in {0,3}`: scheme-independent
  (depends only on the indices, not on charges). ✓
- **Gluon count** `N_g = 8`, **neutrino count** `N_nu = 3`,
  **cascade length** `N_e = 10`: all scheme-independent counting theorems. ✓
- **Charge interlock** `N_c * <Q Sigma_r>_0 = 2j = 5`: uses charge *differences*
  (`Delta Q = Q_3 - Q_2`), which are offset-independent, so it is exact and
  identical in both schemes. ✓

---

## 3. Where the schemes diverge (open reconciliation items)

The engine computes these exactly; the paper's **identity tables** assign
different charges for the same tuples. These are recorded as open items.

| Particle | Tuple | Q (V.1) | Q (obs.) | Paper id-table | Status |
|---|---|---|---|---|---|
| mu- | (0,2,4) | 0 | 0 | -1 | id-table charge not reproduced by either single-constituent formula |
| tau- | (0,1,5) | 0 | 0 | -1 | same |
| proton | (3,4,5) | +2 | +1 | +1 | obs. scheme matches; V.1 does not |
| neutron | (0,4,5) | +1 | +1 | 0 | neither matches |
| DM1 | (0,1,2,3) | +1/9 | -8/9 | 0 (claimed) | Q=0 not produced by either formula |
| DM2 | (0,1,3,5) | +10/9 | +1/9 | 0 (claimed) | same |
| DM3 | (1,2,4,5) | -2/9 | -2/9 | 0 (claimed) | same |

### Root cause

Charge conjugation in the PH is the Z6 inversion `k -> (6-k) mod 6`. For a
particle/antiparticle pair to be charge-symmetric (`Q + Q_conj = 0`) one needs
`Sum_k Q_k = 0`. But Scheme A has `Sum_k Q_k = 1` (and Scheme B has a non-zero
sum as well). Therefore:

- the inversion does **not** flip the sign of `Q` exactly for every tuple
  (it does for the electron, by coincidence of that tuple's structure), and
- composites the paper labels "neutral" (the DM singlets, several baryons) do
  **not** come out at `Q = 0` from the explicit formula.

A charge formula with `Sum_k Q_k = 0` (a uniform `-1/6` offset on Scheme A)
restores exact conjugation symmetry but then **breaks** the electron value and
the `Sum_k Q_k = 1` corollary of Theorem V.1. No single offset simultaneously
satisfies all of: (i) `Sum_k Q_k = 1` (V.1), (ii) neutral DM, (iii) integer
hadron charges, (iv) `Q(e-) = -1`. This is the precise content of the open
item.

---

## 3a. Correction (post-discovery): proton/neutron tuple mislabelled in this document

An earlier revision of this section identified `proton = (3,4,5)` and
`neutron = (0,4,5)`. Cross-checking against the full `PH_Foundations`
Appendix H ("The Psion Diagram: Complete Calculus for Composite
Classification") shows this was wrong:

```
Appendix H:  LRR (0,4,5) = Proton p   (Q = 1/9+4/9+4/9 = +1)
Appendix H:  LLR (0,1,5) = n / nu_tau (dual-sector, Q = 0)
Appendix H:  RRR (3,4,5) = Q = +2 exotic (BSM) -- NOT the proton
```

Both corrected charges check out exactly under Theorem V.1 alone, no
second scheme needed: proton `(0,4,5)`: `1/9+4/9+4/9 = 1`. Neutron
`(0,1,5)`: `1/9-5/9+4/9 = 0`. The "neither scheme reproduces neutron=0"
tension recorded in an earlier draft of §3 was an artefact of the mislabelled
tuple, not a real V.1/observable-scheme conflict, and is now closed for
these two particles specifically.

## 3b. Impossibility proof: state-wise conjugation vs. Theorem V.1 itself (T1)

This is now stated without reference to any specific particle label, and is
consequently a stronger, more direct result than the version in the previous
draft.

**Setup.** Charge conjugation is the Z6 index map `k -> (6-k) mod 6`, fixing
`0` and `3`. State-wise conjugation (`Q_k = -Q_{conj(k)}` for every `k`, not
just `Sum_k Q_k = 0`) forces:

```
Q_0 = -Q_0  =>  Q_0 = 0
Q_3 = -Q_3  =>  Q_3 = 0
Q_1 = -Q_5
Q_2 = -Q_4
```

**Direct check against Theorem V.1's actual values**
(`Q_0=1/9, Q_1=-5/9, Q_2=-5/9, Q_3=10/9, Q_4=4/9, Q_5=4/9`):

```
Q_0 = 1/9   (required: 0)   -- FAILS
Q_3 = 10/9  (required: 0)   -- FAILS
Q_1 = -5/9, -Q_5 = -4/9     -- FAILS (off by 1/9)
Q_2 = -5/9, -Q_4 = -4/9     -- FAILS (off by 1/9)
```

None of the four state-wise conjugation constraints holds under V.1. This
is visible without any composite at all -- it is a property of the six
single-psion charges themselves. It shows up starkly in the `(3,4,5)`
exotic state: V.1 gives `Q=+2` (`10/9+4/9+4/9`), while any conjugation-
consistent assignment (`Q_3` forced to `0`) would require `Q=+1` for that
same triple -- a full unit of charge apart, not a rounding-level mismatch.

**Status: T1, direct proof, independent of particle labelling.** The
proton/neutron mislabelling in §3a did not cause this result and does not
resolve it: proton and neutron individually happen to come out numerically
correct under raw V.1 (§3a), but V.1 itself is not a conjugation-symmetric
charge assignment, and no relabelling of which triple is which particle
changes that -- it is a statement about the six `Q_k` values, prior to any
composite.

## 3c. Resolution adopted (T1, closed): aggregate conjugation only

The candidate repairs are the same three considered before, now re-examined
against the corrected picture:

1. **Retune Q_k values to satisfy state-wise conjugation exactly**
   (`Q_0=Q_3=0`, `Q_1=-Q_5=x`, `Q_2=-Q_4=y`). This reproduces proton `(0,4,5)
   =-(x+y)` and neutron `(0,1,5)=0` correctly for any `x+y=-1` (fixed by
   `Q(e-)=-1`), and is compatible with the corrected proton/neutron
   labelling -- **but** it forces the `(3,4,5)` exotic state to `Q=+1`
   instead of the `Q=+2` currently reported, i.e. it changes a *published*
   charge value, not just an unresolved item. This is a live option, not
   closed, but it is a physics change to Appendix H, not a bookkeeping fix.
2. **Extend the conjugation map** (§3a of the previous draft; closed --
   see original text preserved in version history): any involution on 3
   proto-colours has an odd number of fixed points, and the one tested
   full involution (colour+chirality swap) trades the lepton-generation
   problem for a neutron-neutrality problem. Still closed.
3. **Aggregate-only conjugation** (adopted in the previous draft): remains
   available and is now the more conservative choice, since it requires no
   change to any published charge value, including the exotic `(3,4,5)=+2`.

**Adopted (unchanged from previous draft): Option 3 / aggregate-only
conjugation.** Option 1 above is flagged as worth considering in a future
revision, since it is now known to be compatible with the corrected
proton/neutron identification -- but changing `(3,4,5)` from `+2` to `+1`
is a decision for the source paper, not this document, and is left open
here.

## 3d. Separate open item surfaced by this correction (not resolved here)

Appendix H labels `(0,1,5)` and `(0,2,4)` as "dual-sector" (neutrino/baryon-
like, generation ordering explicitly marked open), while `PH_Foundations`
§6 identifies the same two index sets as definite charged-lepton/neutrino
doublets (mu-/nu_mu, tau-/nu_tau, "Doublet I/II"), without the
open-status qualifier. These are different epistemic claims about the same
triples from two sections of the same source document and are not
reconciled by anything in this file. Flagged for the source paper, not
resolved here.
## 4. What is and is not affected

**Not affected (robust, scheme-independent):**
all counting theorems (`N_nu`, `N_g`, `N_e`, `N_gen`), the triality / singlet
classification, the charge interlock (uses differences), `eps_psi = 25/169`
(uses `Delta Q`), and therefore `eta_B`. These carry their stated T-levels
unchanged.

**Affected (open reconciliation):**
the *absolute* electric charge assigned to the muon, tau, neutron, and the
three DM generations. The qualitative identifications (which tuple is which
particle, observability, stability) are unaffected; only the absolute-charge
bookkeeping needs a single consistent convention to be fixed in a future
revision of the source.

---

## 5. Recommendation for the source paper

**Update (post §3a-3d):** the proton/neutron tuple mislabelling is corrected
(§3a); the impossibility proof for state-wise conjugation is restated
independently of particle labels and still holds (§3b); the three candidate
repairs are re-examined in §3c. Pending a decision among them:

1. Keep Theorem V.1 as fundamental and adopt aggregate-only conjugation
   (§3c option 3, currently adopted) — no change to any published charge
   value, including the `(3,4,5)=+2` exotic state; or
2. Retune the six `Q_k` values to satisfy state-wise conjugation exactly
   (§3c option 1) — compatible with the corrected proton (+1) and neutron
   (0), but changes the exotic `(3,4,5)` state from `+2` to `+1`, a physics
   change to Appendix H, not a bookkeeping fix; or
3. Extend the conjugation map (§3c option 2) — closed by exhaustive search;
   not recommended.

Separately, §3d flags an unresolved tension between `PH_Foundations` §6
(definite mu/tau charged-lepton identification) and Appendix H ("dual-sector,"
generation ordering open) for the same index triples — orthogonal to the
conjugation question and not addressed by any option above.

Until a choice is made among 1-3, this repository reports **both** charge
schemes side by side, never silently picks one, and flags state-wise
conjugation as unsatisfiable under Theorem V.1 as currently published
(§3b) rather than as an open search.
