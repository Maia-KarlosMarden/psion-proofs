# PMNS programme (open problem P-PMNS) and F3

Goal: compute the PMNS matrix inside the PH, and obtain F3 (the astrophysical
ν_τ/ν_e asymmetry) as an output instead of a quoted number.

## Why F3 needs the PMNS

At Earth, f_α = Σ_i |U_αi|² Σ_β |U_βi|² s_β. For a pion-decay source (1:2:0)
the τ–e asymmetry A_te = (f_τ − f_e)/(f_τ + f_e) is a function of the PMNS
alone. With standard oscillations and NuFIT 6.0 parameters it spans roughly
−10% to +9%; +7% needs δ_CP ≈ π and sin²θ23 ≈ 0.574. With real mixing
(δ ∈ {0, π}), δ = 0 gives a negative A_te for every allowed θ23, so the sign
of F3 already discriminates. A derivation of F3 is therefore a derivation of
(θ23, θ13, δ).

## Stage 0 — flavour basis (exact; `proofs/P_pmns_structure.py`, 16 claims)

1. m_k = k − 5/2 reproduces Table 2.
2. Generation = proto-colour of the single R constituent of the neutral
   triple: ν_e (1,2,3) colour 0, |m_R| = 1/2; ν_μ (0,2,4) colour 1, 3/2;
   ν_τ (0,1,5) colour 2, 5/2. Each is e(0,1,2) with that colour flipped L → R.
3. Z3 colour rotation cycles ν_e → ν_μ → ν_τ.
4. The CC flip k → k+3 conserves colour: PMNS = O_lᵀ O_ν in the colour basis.
5. Charge is invariant under colour 1 ↔ 2 (μ ↔ τ); only SU(2)_meta breaks it.
6. With charged leptons diagonal in the colour basis, a μ–τ symmetric neutrino
   operator gives θ13 = 0 and θ23 = 45° exactly. In the PH, θ13 and θ23 − 45°
   measure the SU(2)_meta breaking.

Tension noted: Table 5 gives the electron |m_J^R| = 0, while the colour-0 R
constituent of ν_e has |m_R| = 1/2.

## Working hypotheses shared by all models

- H1 flavour basis = colour basis, order (e, μ, τ) ↔ (0, 1, 2) [Stage 0].
- H2 operators are real symmetric → δ ∈ {0, π}.
- H3 diagonal entries from the paper's lepton law, level = l0 − A|m|^p
  (A = 13/12, p = 5/6): charged leptons with |m_J^R| = 0, 3/2, 5/2 (Table 5);
  neutrinos with |m_R| = 1/2, 3/2, 5/2 of the neutral triples.
  **UNJUSTIFIED for neutrinos (correction, 16 Oct 2026).** It contradicts
  Table 6: the law gives m3/m2 ≈ 17.4 and Δm²31/Δm²21 ≈ 303, while Table 6
  has m3/m2 ≈ 5.4 (observed ≈ 5.8). The neutrino masses come from a
  different channel (ν-channel, P26; Δm²21 is the second SC input), and the
  law describes the excitation ladder of one triple, (0,1,2), not three
  distinct triples. It was an assumption of this programme, not a statement
  of the paper. Kept for charged leptons only.
- H5 charged-lepton operator diagonal in the colour basis (O_l = 1); its
  hierarchy (Table 5) makes charged-lepton mixing small in any case.

Fixed data and pass criteria (identical for every model): NuFIT 6.0, normal
ordering, arXiv:2410.05380. Δm²21 = 7.49×10⁻⁵ eV², Δm²31 = 2.534×10⁻³ eV²;
3σ: sin²θ12 ∈ [0.275, 0.345], sin²θ13 ∈ [0.02023, 0.02388],
sin²θ23 ∈ [0.430, 0.596].

## Model log

### CDF — Clebsch double flip in level space — FALSIFIED

Explored before this log was opened; recorded as exploratory, not
pre-registered. Level operator L = diag(−A|m_R|^p) − g K, K_cc′ = a_c a_c′
(c ≠ c′), a = three-step Clebsch products (√360, 24, √360), masses
m = Λ e^(−λ/b_e). Result: Δm²31/Δm²21 = 303 at g = 0 and grows with g; no
coupling reaches 33.8, and θ13 overshoots once mixing is large.
Result conditional on H3: the g = 0 failure (303) is the H3 diagonal itself.
Lesson (conditional on H3's level spacings): level-space mixing amplifies the
hierarchy, since masses are exponential in the level.

### H4′ — rank-one exchange through the common Q = −1 state — PRE-REGISTERED

Registered 16 Oct 2026, before any evaluation (this commit).

Motivation (Stage 0, item 2): each ν_c reaches the same Q = −1 state e(0,1,2)
through exactly one flip. A second-order exchange through that common state is
rank one in the colour basis.

Specification (code: `scripts/pmns_models.py h4p`):

    M_ν = s [ diag(r_c) + x â âᵀ ]
    r_c = exp(A(|m_R(c)|^p − |m_R(0)|^p)/b_e),  |m_R| = (1/2, 3/2, 5/2)
    â   = a/|a|,  a = (√360, 24, √360)          (three-step Clebsch flips)

- Free parameters: s (scale), x (exchange strength). Both are fixed by the two
  splittings: x by Δm²31/Δm²21 = 33.83 (all roots in |x| ≤ 10⁶ are
  reported), s by Δm²21.
- Physical masses are |eigenvalues|; U = eigenvectors, O_l = 1.
- Outputs (predictions): sin²θ12, sin²θ13, sin²θ23, F3.
- Pass: some root satisfies all three 3σ ranges with normal ordering.
  Otherwise H4′ is falsified. No change to â, r_c or the criteria after
  evaluation.

**Result (16 Oct 2026, evaluated after the pre-registration commit): FALSIFIED,
conditional on H3** (see the correction below).
Four roots reproduce Δm²31/Δm²21; none passes.

| x | masses (meV) | sin²θ12 | sin²θ13 | sin²θ23 | A_te |
|---|---|---|---|---|---|
| −2080.2 | 0.26, 8.66, 50.3 | 0.105 | 0.310 | 0.700 | −40.8% |
| −112.19 | 1.46, 8.78, 50.4 | 0.522 | 0.0039 | 0.0071 | −95.6% |
| +94.14 | 0.90, 8.70, 50.3 | 0.232 | 0.0043 | 0.0076 | −94.3% |
| +1562.8 | 0.30, 8.66, 50.3 | 0.180 | 0.225 | 0.478 | −19.7% |

Diagnosis: â has |â_e|² = 0.278 = |â_τ|². If the exchange dominates, ν3 ≈ â and
θ13 is far too large; if it does not, U ≈ 1 and θ23 is tiny. There is no
regime in between. The three-step Clebsch amplitudes are symmetric under
m → −m, i.e. colour 0 ↔ 2 (e ↔ τ); the data need the heavy state to have a
small e-component and nearly equal μ and τ components, i.e. the 1 ↔ 2 (μ ↔ τ)
symmetry of the charge (Stage 0, item 5), not the e ↔ τ symmetry of SU(2)_meta
Clebsch products.

Provisional lesson (conditional on H3, not a fair test of the direction): the
exchange vertex that generates ν mixing may need the colour-1 ↔ 2 symmetry of
the charge, with SU(2)_meta entering only as a breaking.

### Trial count

Models evaluated so far: 3 (CDF exploratory, H4′ pre-registered, H6
registered with disclosure). All three share the neutrino diagonal H3, now
marked unjustified, so they count as one refuted premise (H3) seen three
times, not three independent failures. The two exchange directions (Clebsch
â, charge q̂) have not been fairly tested. Any later success must still be
read with the count of evaluations in mind.

### H6 — rank-one exchange along the proto-colour charge vector — FALSIFIED

Registered 16 Oct 2026, after H4′ failed and motivated by its diagnosis.

    M_ν = s [ diag(r_c) + x q̂ q̂ᵀ ],   q̂ = (1, −5, −5)/√51   (9 q_c, §J.6.4)

Same r_c, data, root search and pass criteria as H4′; O_l = 1.

Disclosure: before registration it was noticed that a pure q̂ direction gives
|U_e3|² = 1/51 = 0.0196, just below the 3σ floor 0.02023, and θ23 = 45°
exactly; the diagonal r_c breaks μ–τ and will move both. This prior
knowledge lowers the evidential weight of any pass. A pass would also fix
F3 near the θ23 ≈ 45° values (about +3% for δ = π, −5% for δ = 0), not +7%.

**Result (16 Oct 2026, evaluated after registration in 322a3b7): FALSIFIED,
conditional on H3.**

| x | masses (meV) | sin²θ12 | sin²θ13 | sin²θ23 | A_te |
|---|---|---|---|---|---|
| −1718.4 | 0.06, 8.66, 50.3 | 0.012 | 0.0248 | 0.617 | −6.0% |
| −149.52 | 0.30, 8.66, 50.3 | 0.068 | 0.0010 | 0.028 | −82.1% |
| +162.30 | 0.16, 8.66, 50.3 | 0.020 | 0.0012 | 0.034 | −77.4% |
| +794.51 | 0.09, 8.66, 50.3 | 0.021 | 0.0101 | 0.268 | −13.7% |

Diagnosis: the charge direction gets the reactor and atmospheric structure
roughly right at x ≈ −1718 (sin²θ13 = 0.0248 and sin²θ23 = 0.617, each just
outside 3σ), which is suggestive for the H4′ lesson but conditional on H3. The solar angle fails at every
root (sin²θ12 ≤ 0.07 against 0.275–0.345). Cause: the diagonal ratios
1 : 25 : 439, from the lepton law applied to |m_R| of the neutral triples,
isolate ν1, and a rank-one term cannot mix it with ν2. This is a failure of
the diagonal, not of the exchange direction. The lepton law is calibrated on
charged leptons; its use for neutral triples is an extrapolation, now marked
unjustified (H3 correction).

## Correction (16 Oct 2026): all three verdicts are conditional on H3

H3 for neutrinos contradicts Table 6 and is marked unjustified. Consequences:

- CDF: its failure at zero mixing is the H3 diagonal itself.
- H4′ and H6: what was falsified is the conjunction "H3 diagonal + exchange
  direction", not the exchange direction alone.
- The decision below is restated accordingly.

## Decision after three trials (CDF, H4′, H6 — all falsified under H3)

The texture search is paused. Reason: the neutrino diagonal in the colour
basis is not given by the paper (Table 6 lists eigenvalues, not diagonal
entries), and the only diagonal tried (H3) is refuted. Guessing another
diagonal would add three free parameters and turn the exercise into a fit.

1. **Neutral-sector diagonal (next):** derive the self-energy of the neutral
   triples in the colour basis. It must be consistent with Table 6 and with
   the ν-channel (P26).
2. **Exchange direction:** the charge's colour-1 ↔ 2 symmetry is suggestive
   (H4′, H6) but untested on a valid diagonal.
3. **Vertex normalisation:** x and the scale must come from the composite
   gauge vertex (P25), so that the splittings become predictions.
4. Only after item 1, and with explicit parameter counting: a free-diagonal
   study, reported as a fit.

Status of F3: no derivation exists. None of the evaluated models produces
+7%; every root gives A_te < 0, but this is conditional on H3 and therefore
uninformative. F3 should be carried as conditional on P-PMNS ([T4] at most).

## H7 — first-order J·Σ self-energy of the neutral triples — FALSIFIED

Registered 16 Oct 2026, before any evaluation (this commit). First attempt at
item 1 of the decision above (the neutral-sector self-energy), taken from the
Lagrangian itself rather than from a mass law.

Source: eq. (1), L ⊃ −(ψ̄Jᵃψ)(ψ̄Σᵃψ), with J acting on the left sector and Σ
on the right sector; the relative coefficient is fixed by Z6 invariance (no
free parameter). Every neutral triple has two L constituents and one R
constituent, so the first-order self-energy is a sum over its two (L, R)
pairs of J_L·Σ_R = J_zΣ_z + ½(J₊Σ₋ + J₋Σ₊).

Assumptions (stated before evaluation):
- H7a two-body operator, J on L constituents (k ≤ 2), Σ on R (k ≥ 3),
  isotropic contraction (λ = ½), m_k = k − 5/2 (Stage 0);
- H7b first order, inside the locked neutral sector: only matrix elements
  whose final state is again one of the three neutral triples are kept
  (moves that unlock a constituent, or change Q, are second-order or
  excluded);
- H7c the scalar contact term (ψ̄ψ)² is label-blind, hence ∝ 1 in the colour
  basis;
- H7d the neutrino mass operator is a monotonic function of this self-energy
  (any cascade map), so U = eigenvectors of V, independent of scale and sign;
- H1, H2, H5 as above. H3 is not used.

Zero free parameters for U. The mass ordering depends on whether mass rises
or falls with the eigenvalue; both orderings (A, B) are evaluated and count
as 2 trials. Pass: either ordering inside all three 3σ ranges. Code:
`scripts/pmns_models.py h7`; V is built by enumeration, not typed in.

**Result (16 Oct 2026, evaluated after the pre-registration commit 0070d67): FALSIFIED.**

The enumeration gives, in the colour basis (e, μ, τ),

    V = [[ −1,    √10,   0  ],
         [ √10,  −9/2,   √10],
         [  0,    √10,  −10 ]]

(diagonal: m_R Σ m_L over the two L constituents; off-diagonal: one J₊Σ₋
move each, ν_μ → ν_e via 0→1 with 4→3 and ν_τ → ν_μ via 1→2 with 5→4, both
of amplitude ½√5·√8 = √10; no direct e–τ element).

| ordering | sin²θ12 | sin²θ13 | sin²θ23 | A_te | verdict |
|---|---|---|---|---|---|
| A (mass rises with eigenvalue) | 0.945 | 0.673 | 0.925 | −34.4% | FAIL |
| B (mass falls with eigenvalue) | 0.314 | 0.0181 | 0.208 | −34.4% | FAIL |

Ordering B against NuFIT 6.0: θ12 is +0.6σ from the best fit; θ13 is
−6.7σ (0.0181 vs 0.02195); θ23 is far outside the 3σ range (0.208 vs
0.430–0.596). |U|² first row (B) = (0.673, 0.309, 0.018), against roughly
(0.68, 0.30, 0.022) measured.

Diagnosis: the J_zΣ_z diagonal (−1, −9/2, −10) breaks μ–τ strongly, while
the two off-diagonals are equal; ν3 is then 78% τ instead of roughly half μ,
half τ. The electron row comes out close because it is set by the e–μ block,
which this operator fixes without parameters. Something must bring the μ and
τ diagonal entries closer (gap 11/2 against a coupling √10): second-order
terms through the excluded unlocked or charged states, or a μ–τ symmetric
contribution such as the charge pair energy (which is μ–τ symmetric but only
shifts e). Not tried here: it would be a new registered model.

Post-hoc check (not part of the registered criteria, one fitted parameter,
not counted as evidence): an exponential map m ∝ exp(−κE) with κ = 0.263
reproduces Δm²31/Δm²21 with normal ordering, giving m = (1.77, 8.83, 50.4)
meV, Σm = 61 meV. This m1 contradicts Table 6 (7.5×10⁻⁹ eV).

F3 under H7: A_te = −34% (column order does not affect it), the opposite
sign to the registered +7%.

Trial count after H7: the H3 family (one refuted premise, three models) plus
H7 (two orderings). H7 is the first operator derived from the Lagrangian
rather than chosen.

## H8 — J·Σ plus the locking gap G·P_unlocked, exact diagonalisation — FALSIFIED

Registered 16 Oct 2026, before any evaluation (this commit). Next order of
the H7 derivation: H7 dropped every move that unlocks a constituent. H8 keeps
them and lets the paper's own gap operator price them.

    H = V_JΣ + G · Σ_constituents P_unlocked        (Theorem J.5: G·P_unlocked = G·N_ν)

Assumptions (stated before evaluation):
- H8a V_JΣ exactly as in H7 (two-body, J on L, Σ on R, isotropic), now on
  every state reachable from the three neutral triples by charge-conserving
  moves, including states with an unlocked constituent.
- H8b extended charge per constituent: Q9 = 9 q(c) + 9χ with colour
  c = (m + 5/2) mod 3 and chirality χ (0 = L, 1 = R); it reduces to Q_k on
  the locked states. Moves that change the total charge are excluded.
- H8c the two L constituents carry an antisymmetric internal part (distinct
  labels; repeated-label states vanish); reordering gives a fermionic sign.
- H8d G·P_unlocked costs G per unlocked constituent; G is the only free
  parameter, in units of the J·Σ coupling. It is in principle fixed by P26.
- H8e U = Löwdin-orthonormalised locked-sector projection of the three
  eigenstates with the largest locked weight; mass monotonic in the
  eigenvalue, both orderings A and B evaluated (H7d). O_l = 1.
- Consistency (checked before evaluation, no angles computed): the reachable
  neutral space has 6 states (3 locked triples, 3 with one unlocked
  constituent), and for G → ∞ the locked block equals the H7 matrix.

Scan: G from 0.25 to 10⁴ (400 log-spaced points), both orderings. Pass: some
(G, ordering) inside all three 3σ ranges; the passing G window is reported.
This is a one-parameter fit to three angles (two effective predictions),
and the scan counts as one model with two orderings.

**Result (16 Oct 2026, evaluated after the pre-registration commit d864f96): FALSIFIED.**

| G | sin²θ12 | sin²θ13 | sin²θ23 | A_te | locked weight |
|---|---|---|---|---|---|
| 0.5 | 0.697 | 0.0356 | 0.215 | −28.8% | ≥ 0.48 |
| 2 | 0.486 | 0.0266 | 0.218 | −33.3% | ≥ 0.44 |
| 5 | 0.454 | 0.0240 | 0.210 | −34.8% | ≥ 0.87 |
| 10 | 0.383 | 0.0212 | 0.210 | −34.8% | ≥ 0.97 |
| 30 | 0.337 | 0.0192 | 0.209 | −34.6% | ≥ 0.996 |
| 10⁴ | 0.314 | 0.0181 | 0.208 | −34.4% | 1.000 |

(ordering B; ordering A fails everywhere). Closest point G ≈ 22: sin²θ12 =
0.345 (edge), sin²θ13 = 0.0196 (just below 3σ), sin²θ23 = 0.209. θ12 and θ13
move with G and nearly meet their windows around G ≈ 20; θ23 never moves.

Structural reason (exact for this H): the reachable states are the three
locked triples plus U1 = (−3/2, +1/2; −1/2), U2 = (−1/2, +1/2; −3/2),
U3 = (−1/2, +3/2; −5/2). Only ν_e couples to them, through the zero-mode bond
k = 2 ↔ 3 with amplitude ½·3·3 = 4.5 (the ⟨+½|J₊|−½⟩ = 3 element of §J.6.2).
ν_μ and ν_τ have no charge-conserving J·Σ move into the unlocked sector. The
gap therefore renormalises the electron row only, and the μ–τ block, hence
sin²θ23 ≈ 0.21, is independent of G. Within J·Σ plus the locking gap,
sin²θ23 ≈ 0.21 is a robust prediction, and it is wrong.

Next step suggested by this diagnosis: the scalar contact term of eq. (1),
−G_UV(ψ̄ψ)², not used so far. It flips chirality at fixed m, which can move
ν_μ and ν_τ into the unlocked sector, so it is the only remaining
first-principles term that can act on the μ–τ block. Its normalisation
relative to J·Σ is stated in §2.1 as fixed by Z6 ("relative coefficient −1");
the exact reading (sign, and whether G_UV multiplies both terms) is an author
decision to settle before registering H9.

Trial count: H3 family (one refuted premise, three models); H7 (two
orderings, zero parameters); H8 (one parameter, two orderings).

## H9 — full eq. (1) (scalar + J·Σ, common G_UV) plus the locking gap — FALSIFIED (both signs)

Registered 16 Oct 2026, before any evaluation (this commit). Adds the only
term of eq. (1) not used so far, the scalar contact −G_UV(ψ̄ψ)², which H8's
diagnosis identified as the only first-principles term able to reach ν_μ and
ν_τ.

Reading of eq. (1), chosen by the author on 16 Oct 2026: reading A, one
coupling G_UV multiplies both terms (consistent with §2.1 "no free
parameter", the single-coupling fixed point of §2.2, dimensional analysis,
and the repository's NJL code with G_UV = g²/Λ²). The relative sign is
ambiguous (eq. (1) prints both terms with "−"; the text says "relative
coefficient −1"), so both signs are evaluated, as the author requested:

    S+ (printed):            H = G_UV [ V_S + V_JΣ ] + G·N_unlocked
    S− (relative coeff. −1): H = G_UV [ V_S − V_JΣ ] + G·N_unlocked

in units G_UV = 1 (H = −L_int).

Conventions fixed before evaluation:
- H9a Fock space of three identical psion modes (χ, m), 12 modes, canonical
  ordering index = 6χ + (m + 5/2); all fermionic signs from the
  second-quantised operators.
- H9b V_JΣ as in H7/H8: J on L modes, Σ on R modes, one contraction per
  (L, R) pair.
- H9c V_S = (ψ̄ψ)², ψ̄ψ flipping chirality at fixed m (identity in
  SU(2)_meta). On an (L, R) pair it gives (L m, R n) → (R m, L n) with
  amplitude κ_S = 2 (two contractions of the two bilinears; J·Σ has one).
- H9d charge rule as H8b; moves changing the extended charge are excluded
  (this removes the LL → RR part of (ψ̄ψ)²). Pauli: occupied targets vanish.
- H9e gap G per unlocked constituent (Theorem J.5); U extraction and the two
  mass orderings as in H8.
- Pre-checks (no angles computed): 9 reachable states; with V_S switched off
  the J·Σ component reproduces the H8 spectrum exactly at G = 0.7, 3, 40; V_S
  couples each of the three locked triples to two unlocked states.

Scan: G from 0.25 to 10⁴ (400 points) for each sign and ordering. Trials:
2 signs × 2 orderings, one continuous parameter G. Reading B (independent
J·Σ coefficient) is not evaluated.

**Result (16 Oct 2026, evaluated after the pre-registration commit cf29565): FALSIFIED for both signs.**

Where the locked description holds (locked weight ≥ 0.9):

| sign | ordering | sin²θ12 | sin²θ13 | sin²θ23 |
|---|---|---|---|---|
| S+ | B | 0.314–0.326 | 0.0181–0.0185 | 0.208 |
| S+ | A | 0.945 | 0.66–0.67 | 0.92 |
| S− | A | 0.203–0.314 | 0.0079–0.0181 | 0.192–0.208 |
| S− | B | 0.94–0.96 | 0.67–0.79 | 0.92–0.93 |

Over the full scan, including small G where the three states are less than
half locked, sin²θ23 never enters 0.430–0.596 in a physical ordering (S+ B:
0.200–0.224; S− A: 0.147–0.291). Closest points: S+ B at G ≈ 4
(0.326, 0.0185, 0.208); S− A in the G → ∞ limit (the H7 values). F3 stays
between −19% and −36%.

Structural reason (exact): V_S is the identity in SU(2)_meta, so it couples
each locked triple to its own two unlocked states with the same amplitudes
(±2), and its second-order effect on the locked block is
P V_S Q V_S P = 8·𝟙 — flavour-universal. The scalar term reaches ν_μ and ν_τ,
as anticipated, but shifts all three triples equally, so it cannot move
θ23.

## Conclusion on eq. (1)

Both terms of the Lagrangian, both relative signs, and any locking gap give
sin²θ23 ≈ 0.19–0.21 wherever the locked-triple description is valid. Within
the assumptions shared by H7–H9 (H1 flavour = colour, H5 charged leptons
diagonal, charge rule H8b, first-quantised triples of distinct labels), the
first-order Lagrangian cannot produce the atmospheric angle. This is a
robust negative result, not a tuning failure.

The assumption now most exposed is H5. PMNS = O_lᵀ O_ν, and the neutrino side
robustly gives sin²θ23 ≈ 0.21. A charged-lepton 2–3 rotation of order 20°
would be enough to reach maximal mixing. The charged leptons in the PH are
eigenstates of the leptonic transfer matrix (P8b) on the Q = −1 sector;
deriving O_l needs that matrix in full, and the paper gives only part of it
(t12 = −8, ⟨3|H|1⟩, the diagonals 10.75, 8.75, 6.75).

Trial count: H3 family (one refuted premise, three models); H7 (two
orderings, zero parameters); H8 (one parameter, two orderings); H9 (one
parameter, two signs × two orderings).

## H10 — charged-lepton side from a reconstructed P8b transfer matrix — GATE FAILED, NOT EVALUATED

Registered 16 Oct 2026, before any evaluation (this commit), including the
reconstruction gate. Drops H5 (charged leptons diagonal), the assumption H9
left most exposed.

Reconstruction (App. A.2.5, §L.4.4): the leptonic transfer matrix on the
Q = −1 sector is a real symmetric 3 × 3 with diagonals (10.75, 8.75, 6.75),
t12 = −8 and ⟨3|H|1⟩ = 8 as printed (the paper writes "t12² = 8", which is
arithmetically 64; the printed value 8 is used), and t23 not given. Mass
ratios are eigenvalue ratios λ_i/λ_j (§L.4.4), assigned by |λ| ascending to
e, μ, τ.

- **Gate:** t23 is determined from m_τ/m_e = 3477.23; the reconstruction is
  accepted only if the same t23 also gives m_μ/m_e = 206.768 within 1%
  (two conditions, one unknown; the paper quotes +0.46% and +0.56% for P8b).
  If no t23 passes, H10 is not evaluated and the reconstruction is recorded
  as inconsistent with the printed entries.
- H10a basis |i⟩ of the transfer matrix ↔ proto-colour c = i − 1.
- H10b O_ν from H7 (zero parameters; the G → ∞ limit of H8 and H9, where the
  locked weight tends to 1), both mass orderings.
- H10c the relative signs of the colour-basis states of the two sectors are
  not fixed by the paper; all four choices S = diag(1, ±1, ±1) are evaluated.
- U = O_lᵀ S O_ν. Same data and pass criteria as before; F3 reported.

Trials: (gate-passing t23 roots) × 4 sign choices × 2 orderings, with no
continuous parameter beyond t23, which is fixed by the masses. With 8 or more
combinations, a single pass carries reduced weight.

**Result (16 Oct 2026, run after the pre-registration commit 71bbf96): GATE
FAILED — H10 not evaluated.** No PMNS angle was computed.

Fixing t23 by m_τ/m_e gives four roots (t23 ≈ −7.46, −7.44, −4.48, −4.45);
at those roots m_μ/m_e = 244.3, 244.0, 515.8 and 520.8, i.e. +18% at best
against 206.77. The best compromise over all t23 (t23 ≈ −7.46) misses both
ratios by about 9% (225.5 and 3208).

Diagnostic (masses only, after the gate): with ⟨3|H|1⟩ = 64, the arithmetic
value of t12², no t23 reproduces even m_τ/m_e.

Conclusion: the entries printed in App. A.2.5 do not define, under the
eigenvalue-ratio reading of §L.4.4, a matrix consistent with the paper's own
P8b mass claims (+0.46%, +0.56%). The actual P8b matrix must contain more
than what is printed (the b_e-dependent terms whose cancellation in t13 is
mentioned, the "15 active pairs", t23). It is cited as repository [2]
§I.9.3, which is not in this release. The charged-lepton side, and with it
H5, cannot be tested until that matrix is available. Trial count unchanged
(H10 not evaluated).

## What would promote a surviving model

1. Derive x and the overall scale from the composite gauge vertex (P25), so
   that the two splittings become predictions too.
2. Derive the charged-lepton operator from the full leptonic transfer matrix
   (P8b) and drop H5.
3. Then F3 = A_te(U) is a derived [T2] prediction with a definite sign.
