# PMNS programme (open problem P-PMNS) and F3

Goal: compute the PMNS matrix inside the PH, and obtain F3 (the astrophysical
ν_τ/ν_e asymmetry) as an output instead of a quoted number.

## Why F3 needs the PMNS

At Earth, f_α = Σ_i |U_αi|² Σ_β |U_βi|² s_β. For a pion-decay source (1:2:0)
the τ–e asymmetry A_te = (f_τ − f_e)/(f_τ + f_e) is a function of the PMNS
alone. With standard oscillations and NuFIT 6.0 parameters it spans roughly
−10% to +9%; +7% needs δ_CP ≈ π and sin²θ23 ≈ 0.574. With real mixing
(δ ∈ {0, π}), δ = 0 gives a negative A_te for every allowed θ23, so the sign
of F3 already discriminates. A derivation of F3 is therefore a derivation of
(θ23, θ13, δ).

## Stage 0 — flavour basis (exact; `proofs/P_pmns_structure.py`, 16 claims)

1. m_k = k − 5/2 reproduces Table 2.
2. Generation = proto-colour of the single R constituent of the neutral
   triple: ν_e (1,2,3) colour 0, |m_R| = 1/2; ν_μ (0,2,4) colour 1, 3/2;
   ν_τ (0,1,5) colour 2, 5/2. Each is e(0,1,2) with that colour flipped L → R.
3. Z3 colour rotation cycles ν_e → ν_μ → ν_τ.
4. The CC flip k → k+3 conserves colour: PMNS = O_lᵀ O_ν in the colour basis.
5. Charge is invariant under colour 1 ↔ 2 (μ ↔ τ); only SU(2)_meta breaks it.
6. With charged leptons diagonal in the colour basis, a μ–τ symmetric neutrino
   operator gives θ13 = 0 and θ23 = 45° exactly. In the PH, θ13 and θ23 − 45°
   measure the SU(2)_meta breaking.

Tension noted: Table 5 gives the electron |m_J^R| = 0, while the colour-0 R
constituent of ν_e has |m_R| = 1/2.

## Working hypotheses shared by all models

- H1 flavour basis = colour basis, order (e, μ, τ) ↔ (0, 1, 2) [Stage 0].
- H2 operators are real symmetric → δ ∈ {0, π}.
- H3 diagonal entries from the paper's lepton law, level = l0 − A|m|^p
  (A = 13/12, p = 5/6): charged leptons with |m_J^R| = 0, 3/2, 5/2 (Table 5);
  neutrinos with |m_R| = 1/2, 3/2, 5/2 of the neutral triples.
  **UNJUSTIFIED for neutrinos (correction, 16 Oct 2026).** It contradicts
  Table 6: the law gives m3/m2 ≈ 17.4 and Δm²31/Δm²21 ≈ 303, while Table 6
  has m3/m2 ≈ 5.4 (observed ≈ 5.8). The neutrino masses come from a
  different channel (ν-channel, P26; Δm²21 is the second SC input), and the
  law describes the excitation ladder of one triple, (0,1,2), not three
  distinct triples. It was an assumption of this programme, not a statement
  of the paper. Kept for charged leptons only.
- H5 charged-lepton operator diagonal in the colour basis (O_l = 1); its
  hierarchy (Table 5) makes charged-lepton mixing small in any case.

Fixed data and pass criteria (identical for every model): NuFIT 6.0, normal
ordering, arXiv:2410.05380. Δm²21 = 7.49×10⁻⁵ eV², Δm²31 = 2.534×10⁻³ eV²;
3σ: sin²θ12 ∈ [0.275, 0.345], sin²θ13 ∈ [0.02023, 0.02388],
sin²θ23 ∈ [0.430, 0.596].

## Model log

### CDF — Clebsch double flip in level space — FALSIFIED

Explored before this log was opened; recorded as exploratory, not
pre-registered. Level operator L = diag(−A|m_R|^p) − g K, K_cc′ = a_c a_c′
(c ≠ c′), a = three-step Clebsch products (√360, 24, √360), masses
m = Λ e^(−λ/b_e). Result: Δm²31/Δm²21 = 303 at g = 0 and grows with g; no
coupling reaches 33.8, and θ13 overshoots once mixing is large.
Result conditional on H3: the g = 0 failure (303) is the H3 diagonal itself.
Lesson (conditional on H3's level spacings): level-space mixing amplifies the
hierarchy, since masses are exponential in the level.

### H4′ — rank-one exchange through the common Q = −1 state — PRE-REGISTERED

Registered 16 Oct 2026, before any evaluation (this commit).

Motivation (Stage 0, item 2): each ν_c reaches the same Q = −1 state e(0,1,2)
through exactly one flip. A second-order exchange through that common state is
rank one in the colour basis.

Specification (code: `scripts/pmns_models.py h4p`):

    M_ν = s [ diag(r_c) + x â âᵀ ]
    r_c = exp(A(|m_R(c)|^p − |m_R(0)|^p)/b_e),  |m_R| = (1/2, 3/2, 5/2)
    â   = a/|a|,  a = (√360, 24, √360)          (three-step Clebsch flips)

- Free parameters: s (scale), x (exchange strength). Both are fixed by the two
  splittings: x by Δm²31/Δm²21 = 33.83 (all roots in |x| ≤ 10⁶ are
  reported), s by Δm²21.
- Physical masses are |eigenvalues|; U = eigenvectors, O_l = 1.
- Outputs (predictions): sin²θ12, sin²θ13, sin²θ23, F3.
- Pass: some root satisfies all three 3σ ranges with normal ordering.
  Otherwise H4′ is falsified. No change to â, r_c or the criteria after
  evaluation.

**Result (16 Oct 2026, evaluated after the pre-registration commit): FALSIFIED,
conditional on H3** (see the correction below).
Four roots reproduce Δm²31/Δm²21; none passes.

| x | masses (meV) | sin²θ12 | sin²θ13 | sin²θ23 | A_te |
|---|---|---|---|---|---|
| −2080.2 | 0.26, 8.66, 50.3 | 0.105 | 0.310 | 0.700 | −40.8% |
| −112.19 | 1.46, 8.78, 50.4 | 0.522 | 0.0039 | 0.0071 | −95.6% |
| +94.14 | 0.90, 8.70, 50.3 | 0.232 | 0.0043 | 0.0076 | −94.3% |
| +1562.8 | 0.30, 8.66, 50.3 | 0.180 | 0.225 | 0.478 | −19.7% |

Diagnosis: â has |â_e|² = 0.278 = |â_τ|². If the exchange dominates, ν3 ≈ â and
θ13 is far too large; if it does not, U ≈ 1 and θ23 is tiny. There is no
regime in between. The three-step Clebsch amplitudes are symmetric under
m → −m, i.e. colour 0 ↔ 2 (e ↔ τ); the data need the heavy state to have a
small e-component and nearly equal μ and τ components, i.e. the 1 ↔ 2 (μ ↔ τ)
symmetry of the charge (Stage 0, item 5), not the e ↔ τ symmetry of SU(2)_meta
Clebsch products.

Provisional lesson (conditional on H3, not a fair test of the direction): the
exchange vertex that generates ν mixing may need the colour-1 ↔ 2 symmetry of
the charge, with SU(2)_meta entering only as a breaking.

### Trial count

Models evaluated so far: 3 (CDF exploratory, H4′ pre-registered, H6
registered with disclosure). All three share the neutrino diagonal H3, now
marked unjustified, so they count as one refuted premise (H3) seen three
times, not three independent failures. The two exchange directions (Clebsch
â, charge q̂) have not been fairly tested. Any later success must still be
read with the count of evaluations in mind.

### H6 — rank-one exchange along the proto-colour charge vector — FALSIFIED

Registered 16 Oct 2026, after H4′ failed and motivated by its diagnosis.

    M_ν = s [ diag(r_c) + x q̂ q̂ᵀ ],   q̂ = (1, −5, −5)/√51   (9 q_c, §J.6.4)

Same r_c, data, root search and pass criteria as H4′; O_l = 1.

Disclosure: before registration it was noticed that a pure q̂ direction gives
|U_e3|² = 1/51 = 0.0196, just below the 3σ floor 0.02023, and θ23 = 45°
exactly; the diagonal r_c breaks μ–τ and will move both. This prior
knowledge lowers the evidential weight of any pass. A pass would also fix
F3 near the θ23 ≈ 45° values (about +3% for δ = π, −5% for δ = 0), not +7%.

**Result (16 Oct 2026, evaluated after registration in 322a3b7): FALSIFIED,
conditional on H3.**

| x | masses (meV) | sin²θ12 | sin²θ13 | sin²θ23 | A_te |
|---|---|---|---|---|---|
| −1718.4 | 0.06, 8.66, 50.3 | 0.012 | 0.0248 | 0.617 | −6.0% |
| −149.52 | 0.30, 8.66, 50.3 | 0.068 | 0.0010 | 0.028 | −82.1% |
| +162.30 | 0.16, 8.66, 50.3 | 0.020 | 0.0012 | 0.034 | −77.4% |
| +794.51 | 0.09, 8.66, 50.3 | 0.021 | 0.0101 | 0.268 | −13.7% |

Diagnosis: the charge direction gets the reactor and atmospheric structure
roughly right at x ≈ −1718 (sin²θ13 = 0.0248 and sin²θ23 = 0.617, each just
outside 3σ), which is suggestive for the H4′ lesson but conditional on H3. The solar angle fails at every
root (sin²θ12 ≤ 0.07 against 0.275–0.345). Cause: the diagonal ratios
1 : 25 : 439, from the lepton law applied to |m_R| of the neutral triples,
isolate ν1, and a rank-one term cannot mix it with ν2. This is a failure of
the diagonal, not of the exchange direction. The lepton law is calibrated on
charged leptons; its use for neutral triples is an extrapolation, now marked
unjustified (H3 correction).

## Correction (16 Oct 2026): all three verdicts are conditional on H3

H3 for neutrinos contradicts Table 6 and is marked unjustified. Consequences:

- CDF: its failure at zero mixing is the H3 diagonal itself.
- H4′ and H6: what was falsified is the conjunction "H3 diagonal + exchange
  direction", not the exchange direction alone.
- The decision below is restated accordingly.

## Decision after three trials (CDF, H4′, H6 — all falsified under H3)

The texture search is paused. Reason: the neutrino diagonal in the colour
basis is not given by the paper (Table 6 lists eigenvalues, not diagonal
entries), and the only diagonal tried (H3) is refuted. Guessing another
diagonal would add three free parameters and turn the exercise into a fit.

1. **Neutral-sector diagonal (next):** derive the self-energy of the neutral
   triples in the colour basis. It must be consistent with Table 6 and with
   the ν-channel (P26).
2. **Exchange direction:** the charge's colour-1 ↔ 2 symmetry is suggestive
   (H4′, H6) but untested on a valid diagonal.
3. **Vertex normalisation:** x and the scale must come from the composite
   gauge vertex (P25), so that the splittings become predictions.
4. Only after item 1, and with explicit parameter counting: a free-diagonal
   study, reported as a fit.

Status of F3: no derivation exists. None of the evaluated models produces
+7%; every root gives A_te < 0, but this is conditional on H3 and therefore
uninformative. F3 should be carried as conditional on P-PMNS ([T4] at most).

## H7 — first-order J·Σ self-energy of the neutral triples — PRE-REGISTERED

Registered 16 Oct 2026, before any evaluation (this commit). First attempt at
item 1 of the decision above (the neutral-sector self-energy), taken from the
Lagrangian itself rather than from a mass law.

Source: eq. (1), L ⊃ −(ψ̄Jᵃψ)(ψ̄Σᵃψ), with J acting on the left sector and Σ
on the right sector; the relative coefficient is fixed by Z6 invariance (no
free parameter). Every neutral triple has two L constituents and one R
constituent, so the first-order self-energy is a sum over its two (L, R)
pairs of J_L·Σ_R = J_zΣ_z + ½(J₊Σ₋ + J₋Σ₊).

Assumptions (stated before evaluation):
- H7a two-body operator, J on L constituents (k ≤ 2), Σ on R (k ≥ 3),
  isotropic contraction (λ = ½), m_k = k − 5/2 (Stage 0);
- H7b first order, inside the locked neutral sector: only matrix elements
  whose final state is again one of the three neutral triples are kept
  (moves that unlock a constituent, or change Q, are second-order or
  excluded);
- H7c the scalar contact term (ψ̄ψ)² is label-blind, hence ∝ 1 in the colour
  basis;
- H7d the neutrino mass operator is a monotonic function of this self-energy
  (any cascade map), so U = eigenvectors of V, independent of scale and sign;
- H1, H2, H5 as above. H3 is not used.

Zero free parameters for U. The mass ordering depends on whether mass rises
or falls with the eigenvalue; both orderings (A, B) are evaluated and count
as 2 trials. Pass: either ordering inside all three 3σ ranges. Code:
`scripts/pmns_models.py h7`; V is built by enumeration, not typed in.

**Result:** pending (next commit).

## What would promote a surviving model

1. Derive x and the overall scale from the composite gauge vertex (P25), so
   that the two splittings become predictions too.
2. Derive the charged-lepton operator from the full leptonic transfer matrix
   (P8b) and drop H5.
3. Then F3 = A_te(U) is a derived [T2] prediction with a definite sign.
