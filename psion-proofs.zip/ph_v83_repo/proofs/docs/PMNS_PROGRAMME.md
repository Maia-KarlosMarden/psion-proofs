# PMNS programme (open problem P-PMNS) and F3

Goal: compute the PMNS matrix inside the PH, and obtain F3 (the astrophysical
ν_τ/ν_e asymmetry) as an output instead of a quoted number.

## Why F3 needs the PMNS

At Earth, f_α = Σ_i |U_αi|² Σ_β |U_βi|² s_β. For a pion-decay source (1:2:0)
the τ–e asymmetry A_te = (f_τ − f_e)/(f_τ + f_e) is a function of the PMNS
alone. With standard oscillations and NuFIT 6.0 parameters it spans roughly
−10% to +9%; +7% needs δ_CP ≈ π and sin²θ23 ≈ 0.574. With real mixing
(δ ∈ {0, π}), δ = 0 gives a negative A_te for every allowed θ23, so the sign
of F3 already discriminates. A derivation of F3 is therefore a derivation of
(θ23, θ13, δ).

## Stage 0 — flavour basis (exact; `proofs/P_pmns_structure.py`, 16 claims)

1. m_k = k − 5/2 reproduces Table 2.
2. Generation = proto-colour of the single R constituent of the neutral
   triple: ν_e (1,2,3) colour 0, |m_R| = 1/2; ν_μ (0,2,4) colour 1, 3/2;
   ν_τ (0,1,5) colour 2, 5/2. Each is e(0,1,2) with that colour flipped L → R.
3. Z3 colour rotation cycles ν_e → ν_μ → ν_τ.
4. The CC flip k → k+3 conserves colour: PMNS = O_lᵀ O_ν in the colour basis.
5. Charge is invariant under colour 1 ↔ 2 (μ ↔ τ); only SU(2)_meta breaks it.
6. With charged leptons diagonal in the colour basis, a μ–τ symmetric neutrino
   operator gives θ13 = 0 and θ23 = 45° exactly. In the PH, θ13 and θ23 − 45°
   measure the SU(2)_meta breaking.

Tension noted: Table 5 gives the electron |m_J^R| = 0, while the colour-0 R
constituent of ν_e has |m_R| = 1/2.

## Working hypotheses shared by all models

- H1 flavour basis = colour basis, order (e, μ, τ) ↔ (0, 1, 2) [Stage 0].
- H2 operators are real symmetric → δ ∈ {0, π}.
- H5 charged-lepton operator diagonal in the colour basis (O_l = 1); its
  hierarchy (Table 5) makes charged-lepton mixing small in any case.

Fixed data and pass criteria (identical for every model): NuFIT 6.0, normal
ordering, arXiv:2410.05380. Δm²21 = 7.49×10⁻⁵ eV², Δm²31 = 2.534×10⁻³ eV²;
3σ: sin²θ12 ∈ [0.275, 0.345], sin²θ13 ∈ [0.02023, 0.02388],
sin²θ23 ∈ [0.430, 0.596].

## Model log

### CDF — Clebsch double flip in level space — FALSIFIED

Explored before this log was opened; recorded as exploratory, not
pre-registered. Level operator L = diag(−A|m_R|^p) − g K, K_cc′ = a_c a_c′
(c ≠ c′), a = three-step Clebsch products (√360, 24, √360), masses
m = Λ e^(−λ/b_e). Result: Δm²31/Δm²21 = 303 at g = 0 and grows with g; no
coupling reaches 33.8, and θ13 overshoots once mixing is large.
Lesson: masses are exponential in the level, so level-space mixing amplifies
the hierarchy. Large PMNS angles must come from an operator linear in mass.

### H4′ — rank-one exchange through the common Q = −1 state — PRE-REGISTERED

Registered 16 Oct 2026, before any evaluation (this commit).

Motivation (Stage 0, item 2): each ν_c reaches the same Q = −1 state e(0,1,2)
through exactly one flip. A second-order exchange through that common state is
rank one in the colour basis.

Specification (code: `scripts/pmns_models.py h4p`):

    M_ν = s [ diag(r_c) + x â âᵀ ]
    r_c = exp(A(|m_R(c)|^p − |m_R(0)|^p)/b_e),  |m_R| = (1/2, 3/2, 5/2)
    â   = a/|a|,  a = (√360, 24, √360)          (three-step Clebsch flips)

- Free parameters: s (scale), x (exchange strength). Both are fixed by the two
  splittings: x by Δm²31/Δm²21 = 33.83 (all roots in |x| ≤ 10⁶ are
  reported), s by Δm²21.
- Physical masses are |eigenvalues|; U = eigenvectors, O_l = 1.
- Outputs (predictions): sin²θ12, sin²θ13, sin²θ23, F3.
- Pass: some root satisfies all three 3σ ranges with normal ordering.
  Otherwise H4′ is falsified. No change to â, r_c or the criteria after
  evaluation.

**Result:** pending (filled in by the next commit).

## What would promote a surviving model

1. Derive x and the overall scale from the composite gauge vertex (P25), so
   that the two splittings become predictions too.
2. Derive the charged-lepton operator from the full leptonic transfer matrix
   (P8b) and drop H5.
3. Then F3 = A_te(U) is a derived [T2] prediction with a definite sign.
