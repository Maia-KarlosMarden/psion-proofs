# The Psion Diagram — A Working Textbook

This is the **didactic half** of the repository. It teaches a reader to apply
the Psion Diagram (PD) protocol by hand and with the engine, so that anyone can
re-derive every known particle and **derive new composites** of their own. Read
it top to bottom once; thereafter use it as a reference.

Everything here is reproduced exactly by `psion_diagram/` — every worked example
below has a one-line engine call that confirms it.

---

## 0. The one idea

> **To exist is to be a group invariant.**

A particle is a colour-singlet bound state of psions. The psion carries a
`Z6 = Z3 x Z2` internal label. Build composites by choosing psion indices;
read off their quantum numbers by exact arithmetic; keep the ones that are
colour singlets. That is the whole method.

---

## 1. The six psions

| k | proto-colour (Z3) | chirality (Z2) | mJ = k - 5/2 | Q_k (V.1) |
|---|---|---|---|---|
| 0 | red   | L | -5/2 | +1/9 |
| 1 | green | L | -3/2 | -5/9 |
| 2 | blue  | L | -1/2 | -5/9 |
| 3 | red   | R | +1/2 | +10/9 |
| 4 | green | R | +3/2 | +4/9 |
| 5 | blue  | R | +5/2 | +4/9 |

```python
from psion_diagram import PSIONS
for p in PSIONS:
    print(p.k, p.proto_colour, p.chirality, p.mJ, p.Q)
```

> ⚠️ Two charge schemes circulate in the source (V.1 fundamental and Appendix-H
> observable). They agree on the electron and on all counting/triality results
> but diverge on some absolute hadron/DM charges. See
> [`docs/CHARGE_CONVENTIONS.md`](CHARGE_CONVENTIONS.md). The engine exposes both
> (`p.Q` and `p.Q_obs`); this textbook uses the V.1 scheme unless noted.

---

## 2. The PD protocol (five steps)

For any candidate composite — a tuple of psion indices `(k1, k2, ..., kN)`:

**Step 1 — assign the Z6 triple.** Compute
- body number `N = len(tuple)`
- triality `I = (sum k_i) mod 6`
- charge `Q = sum Q_{k_i}`
- chirality string (L for k<3, R for k>=3)
- `|m^R_J|` = magnitude of the summed `mJ` of the right-handed constituents

**Step 2 — apply conservation at every vertex.** In any reaction,
`Q_in = Q_out` and `I_in = I_out (mod 6)`. The **Sector Isolation Theorem**:
the `I=0` and `I=3` sectors never mix perturbatively.

**Step 3 — classify topology.** Tree (`L=0`): rate `~ g^2_meta`. One loop
(`L=1`): rate `~ g^4_meta`. The CF-CC is the unique inter-composite channel
exchanging a single constituent between a three-body lepton and a three-body
baryon.

**Step 4 — amplitude type.** `O1` (scalar) if `|Delta mJ| > 1`; `O2` (spin) if
`|Delta mJ| = 1`.

**Step 5 — predict observables.** A composite is **observable** iff it is a
colour singlet, `I in {0,3}`. It is **stable** iff it is the lightest state in
its `(I, Q, J)` sector. Masses follow `m ~ Lambda_meta * exp(-N_cascade / b_eff)`.

```python
from psion_diagram import Composite
c = Composite((0, 4, 2))          # the muon configuration
print(c.N, c.I, c.Q, c.chirality, c.mRJ_abs, c.is_singlet)
```

---

## 3. Worked example A — deriving the electron

Tuple `(0,1,2)` (all left-handed, "LLL").

| Step | Quantity | Value |
|---|---|---|
| 1 | `N` | 3 |
| 1 | `I = (0+1+2) mod 6` | 3 |
| 1 | `Q = 1/9 - 5/9 - 5/9` | **-1** |
| 1 | chirality | LLL |
| 1 | `|m^R_J|` (no R constituents) | 0 |
| 5 | singlet? `I=3 in {0,3}` | **yes → observable** |

`|m^R_J| = 0` puts the electron at the bottom rung of the lepton cascade, so it
is the lightest charged lepton — the mass reference.

```python
Composite((0,1,2)).Q          # -> Fraction(-1, 1)
```

---

## 4. Worked example B — deriving dark matter

Try a four-body neutral singlet. Take `(0,1,2,3)`:

| Step | Quantity | Value |
|---|---|---|
| 1 | `N` | 4 |
| 1 | `I = (0+1+2+3) mod 6` | 0 |
| 1 | `J` | 0 (no magnetic moment) |
| 5 | singlet? `I=0` | yes |
| 5 | stable? lightest in `(I,Q,J)` sector | yes — no lighter Z6-allowed decay |

A composite that is a colour singlet, has `Q=0` and `J=0`, and has no lighter
decay product is **dark by group-theoretic necessity** — no electromagnetic and
no spin coupling. That is the dark-matter identification, derived, not
postulated.

> Note the open charge item: the explicit V.1 formula gives `Q = 1/9` for this
> tuple, while the paper asserts `Q = 0`. See `docs/CHARGE_CONVENTIONS.md`. The
> *stability and darkness* arguments (singlet, `J=0`) are unaffected.

---

## 5. Worked example C — deriving an antiparticle

Antiparticles are free: apply the Z6 inversion `k -> (6-k) mod 6` to every
index.

```
e-  = (0,1,2)
e+  = (6-0, 6-1, 6-2) mod 6 = (0, 5, 4) = (0,4,5)
```

```python
Composite((0,1,2)).conjugate.indices    # -> (0, 4, 5)
```

No new postulate is introduced; charge conjugation is modular arithmetic.

> **Open item, unresolved here.** `(0,4,5)` is also the tuple `PH_Foundations`
> Appendix H identifies as the **proton** (`Q=+1`, LRR chirality; see
> `docs/CHARGE_CONVENTIONS.md` §3a). Both identifications are charge-consistent
> (e+ and proton both carry `Q=+1` under Theorem V.1), but nothing in this
> framework currently distinguishes them as *composites* --- there is no
> separate baryon-number or lepton-number label carried alongside the k-tuple,
> and body number `N=3` is identical for both. As written, `(0,4,5)` is used
> for two physically distinct particles (a lepton antiparticle with
> $m\approx 0.511$~MeV and a baryon with $m\approx 938$~MeV) with no stated
> discriminator. This is not resolved by relabelling one of them --- either a
> genuine collision needing a new conserved quantum number (which would be an
> additional postulate, contrary to this section's claim), or a deeper
> structural link between $e^+$ and the proton that would need independent
> justification. Flagged for the source paper; not adjudicated here.

---

## 6. How to derive a NEW composite (your turn)

1. Pick a body number `N` and a tuple of indices.
2. Run:
   ```python
   from psion_diagram import Composite
   c = Composite((your, indices, here))
   print("N        =", c.N)
   print("I         =", c.I, "-> singlet" if c.is_singlet else "-> confined")
   print("Q (V.1)   =", c.Q)
   print("Q (obs.)  =", c.Q_obs)
   print("chirality =", c.chirality)
   print("|m^R_J|   =", c.mRJ_abs)
   print("conjugate =", c.conjugate.indices)
   ```
3. If `is_singlet` is `True`, the composite is observable. Check whether a
   lighter composite shares its `(I, Q, J)` sector; if not, it is stable.
4. Cross-check conservation for any reaction you propose with
   `conserves_charge(...)` and `conserves_triality(...)`.

To scan an entire body-number at once:

```python
from psion_diagram import enumerate_singlets
for c in enumerate_singlets(4):       # all observable 4-body composites
    print(c.indices, c.I, c.Q)
```

---

## 7. The generated reference tables

The `tables/` directory contains machine-generated, exact derivation tables:

| File | Contents |
|---|---|
| `matter_particles.md` | leptons, neutrinos, baryons (both charge schemes) |
| `antimatter_particles.md` | their Z6 inversions, with charge-sum checks |
| `dark_matter.md` | the three four-body DM singlets |
| `two_body_bosons.md` | all 36 bilinears (photon, gluons, proto-colour tower) |
| `spectrum_summary.md` | `C_total` and `C_stable` per body number |

Regenerate them any time with:

```bash
python scripts/generate_tables.py
```

If a future revision changes a rule, regenerate and the tables update — that is
the calculation-memory discipline.
