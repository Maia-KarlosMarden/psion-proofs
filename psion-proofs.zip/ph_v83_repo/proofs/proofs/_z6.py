"""
proofs._z6  --  self-contained Z6 definitions used by the counting and charge modules
====================================================================================

Replaces the external package `psion_diagram`, which is not part of this archive.
Everything here follows the definitions of PH_Foundations v8.7:

  * labels k = 0..5, m_J(k) = k - 5/2, chirality L for k <= 2, R for k >= 3
  * Table 1 label charges  Q_k = q(k mod 3) + floor(k/3),  q = (1/9, -5/9, -5/9)
  * colour singlet (observable) iff I = (sum k) mod 6 in {0, 3}
  * conserved charge of the locked dynamics (section 1, P-Qcons):
        Q = N/6 + sum F_z / 4,  F_z(k) = m_J + sign(m_J)/2
"""

from __future__ import annotations

from fractions import Fraction as F
from itertools import combinations, combinations_with_replacement

NC = 6
J = F(5, 2)
Q3 = (F(1, 9), F(-5, 9), F(-5, 9))


def m_J(k: int) -> F:
    return F(k) - J


def label_charge(k: int) -> F:
    """Table 1 value (a label, not the conserved charge; section 1)."""
    return Q3[k % 3] + (k // 3)


def F_z(k: int) -> F:
    m = m_J(k)
    return m + (F(1, 2) if m > 0 else F(-1, 2))


def conserved_charge(k: int) -> F:
    return F(1, 6) + F_z(k) / 4


def triality(t) -> int:
    return sum(t) % NC


def is_singlet(t) -> bool:
    return triality(t) in (0, 3)


def Q_label(t) -> F:
    return sum((label_charge(k) for k in t), F(0))


def Q_conserved(t) -> F:
    return sum((conserved_charge(k) for k in t), F(0))


def conjugate_index(k: int) -> int:
    return (NC - k) % NC


def casimir() -> F:
    return J * (J + 1)


def distinct_triples():
    return list(combinations(range(NC), 3))


def multisets(N: int):
    return combinations_with_replacement(range(NC), N)


def C_total(N: int) -> int:
    """Number of colour-singlet multisets of N labels (Table 11, column C(N))."""
    return sum(1 for t in multisets(N) if is_singlet(t))


def molien_coefficients(n_max: int) -> list[int]:
    """Coefficients of F(x) = (1/3)[1/(1-x)^6 + 2/(1-x^3)^2] (App. F.1-F.2)."""
    from math import comb
    out = []
    for N in range(n_max + 1):
        a = comb(N + 5, 5)
        b = (N // 3 + 1) if N % 3 == 0 else 0
        out.append((a + 2 * b) // 3)
    return out
