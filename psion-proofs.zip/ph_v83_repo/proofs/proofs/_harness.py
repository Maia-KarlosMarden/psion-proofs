"""
proofs._harness
===============

Tiny shared harness so every proof script reads like a calculation memo:
each registers CLAIMS, each claim prints its exact left/right-hand sides and a
PASS/FAIL verdict, and the script exits non-zero if any claim fails. This makes
the whole proofs/ directory runnable as a regression suite (see scripts/run_all_proofs.sh).
"""

from __future__ import annotations

import sys
from fractions import Fraction as F

_RESULTS: list[tuple[str, bool, str]] = []


def claim(label: str, lhs, rhs, *, exact: bool = True, tol: float = 0.0) -> bool:
    """Register a claim lhs == rhs and print it.

    exact=True  -> require exact equality (use for T1 rational results).
    exact=False -> require |lhs - rhs| <= tol (use for numerical checks).
    """
    if exact:
        ok = (lhs == rhs)
    else:
        ok = abs(float(lhs) - float(rhs)) <= tol
    _RESULTS.append((label, ok, f"{lhs}  vs  {rhs}"))
    mark = "PASS" if ok else "FAIL"
    print(f"  [{mark}] {label}")
    print(f"         lhs = {lhs}")
    print(f"         rhs = {rhs}")
    return ok


def section(title: str) -> None:
    print()
    print("=" * 72)
    print(title)
    print("=" * 72)


def summary_and_exit() -> None:
    total = len(_RESULTS)
    passed = sum(1 for _, ok, _ in _RESULTS if ok)
    print()
    print("-" * 72)
    print(f"SUMMARY: {passed}/{total} claims passed")
    failed = [lbl for lbl, ok, _ in _RESULTS if not ok]
    if failed:
        print("FAILED CLAIMS:")
        for lbl in failed:
            print(f"  - {lbl}")
        sys.exit(1)
    print("ALL CLAIMS VERIFIED.")
    sys.stdout.flush()
    sys.exit(0)
