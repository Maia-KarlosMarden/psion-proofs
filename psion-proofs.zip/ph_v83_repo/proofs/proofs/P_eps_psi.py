#!/usr/bin/env python3
"""
P_eps_psi.py  --  the chirality asymmetry eps_psi = 25/169  (T2+ chain)
=======================================================================

Verifies the exact algebraic chain that fixes eps_psi, plus the four-anchor
table eps_psi(j) and the baryogenesis assembly eta_B.

Status (faithful to PH Foundations): the *algebra* below is T1; the single
open postulate is Lemma I.1' (the deep-gap normalisation tan theta = t/j),
which keeps eps_psi at T2+. This script proves everything that is T1 and
clearly marks the postulate as an assumption.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fractions import Fraction as F  # noqa: E402

from proofs._harness import claim, section, summary_and_exit  # noqa: E402


def eps_from_delta(delta: F) -> F:
    """eps_psi = 4 delta / (1 + delta)^2  (the double-angle form)."""
    return 4 * delta / (1 + delta) ** 2


def main() -> None:
    section("Bond coupling t = epsilon*(j+1/2) = 1/2  (Theorem I.3, T1)")
    j = F(5, 2)
    Nc = 6
    eps_wind = F(1, Nc)               # winding fraction 1/N_c
    t = eps_wind * (j + F(1, 2))
    claim("t = (1/N_c)*(j+1/2)", t, F(1, 2))
    # universality: t = 1/2 for all half-integer j
    for jj in (F(1, 2), F(3, 2), F(5, 2), F(7, 2), F(9, 2)):
        Ncj = int(2 * jj + 1)
        tj = F(1, Ncj) * (jj + F(1, 2))
        claim(f"t(j={jj}) = 1/2", tj, F(1, 2))

    section("delta_chi = 1/(2j)^2 = 1/25  and  eps_psi = 25/169  (T1 algebra)")
    delta = F(1, int((2 * j) ** 2))
    claim("delta_chi = 1/(2j)^2", delta, F(1, 25))
    eps = eps_from_delta(delta)
    claim("eps_psi = 4 delta/(1+delta)^2", eps, F(25, 169))

    section("Trigonometric identity  eps_psi = sin^2(2 theta),  tan theta = 1/5")
    # tan theta = 1/5  ->  sin 2theta = 2t/(1+t^2) with t=1/5  -> 5/13
    tan = F(1, 5)
    sin2 = 2 * tan / (1 + tan ** 2)
    cos2 = (1 - tan ** 2) / (1 + tan ** 2)
    claim("sin 2theta = 5/13", sin2, F(5, 13))
    claim("cos 2theta = 12/13", cos2, F(12, 13))
    claim("eps_psi = sin^2(2theta) = (5/13)^2", sin2 ** 2, F(25, 169))
    claim("Pythagorean: 5^2 + 12^2 = 13^2", 5 ** 2 + 12 ** 2, 13 ** 2)
    claim("sec(2theta) = 13/12 = A (lepton-mass coeff.)", 1 / cos2, F(13, 12))

    section("Four-anchor table  eps_psi(j) = (2j)^2/(1+2N_c)^2  ... check via tan=1/(2j)")
    anchors = {
        F(1, 2): (F(1, 1), None),         # JR point: eps = 1
        F(3, 2): (F(9, 25), (3, 4, 5)),
        F(5, 2): (F(25, 169), (5, 12, 13)),
        F(7, 2): (F(49, 625), (7, 24, 25)),
    }
    for jj, (eps_expected, triple) in anchors.items():
        tanj = F(1, int(2 * jj))
        s2 = 2 * tanj / (1 + tanj ** 2)
        epsj = s2 ** 2
        claim(f"eps_psi(j={jj})", epsj, eps_expected)
        if triple:
            a, b, c = triple
            claim(f"  triple {triple}: a^2+b^2=c^2", a * a + b * b, c * c)

    section("Baryogenesis assembly  eta_B = eps * eps_conf * (n/ngamma) * xi^-3")
    eps_conf = F(4, 9)
    n_over_ng = 0.749          # thermodynamic ratio (numerical input)
    xi = 434                   # supercooling parameter
    eta_B = float(eps) * float(eps_conf) * n_over_ng / xi ** 3
    print(f"         eta_B (computed) = {eta_B:.3e}")
    claim("eta_B ~ 6.0e-10 (within 5%)", eta_B, 6.0e-10,
          exact=False, tol=0.5e-10)

    print()
    print("NOTE: eps_psi = 25/169 is T2+ in the paper. The algebra above is T1;")
    print("the single open postulate (Lemma I.1', tan theta = t/j) is what keeps")
    print("the classification at T2+. See proofs/P_kappa_reduction.py and the")
    print("Axiom I.1 discussion for the conditional-T1 promotion.")

    summary_and_exit()


if __name__ == "__main__":
    main()
