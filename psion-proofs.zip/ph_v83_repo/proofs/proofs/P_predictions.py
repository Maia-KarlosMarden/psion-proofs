#!/usr/bin/env python3
"""
P_predictions.py  --  numerical predictions with zero free parameters
=====================================================================

Reproduces the headline numerical predictions from the registered formulae:
  * CF-CC rate          R_CF = N_Dirac * g^2_meta * (m_e/m_mu)^2 = 6.16e-4
  * X17 mass            m_X17 = Lambda_meta * exp(-9/b_eff) = 17.65 MeV
  * electron cascade    m_e = Lambda_meta * exp(-N_e/b_eff) = 0.508 MeV
  * photon : h_AB       branching 3:5 from SU(2)_meta multiplicities
  * tower cross-checks  level 10 -> m_e (0.00%); level 8 -> ~0.6 GeV
"""

import os
import sys
import math

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fractions import Fraction as F  # noqa: E402

from proofs._harness import claim, section, summary_and_exit  # noqa: E402

# Registered constants
LAMBDA_META = 1.2662e12      # GeV
B_EFF = 325 / 1152
G2_META = 2 * math.pi ** 2 / 3
N_DIRAC = 4
M_E = 0.511e-3               # GeV
M_MU = 105.66e-3             # GeV


def main() -> None:
    section("CF-CC rate  R_CF = N_Dirac * g^2_meta * (m_e/m_mu)^2")
    R_CF = N_DIRAC * G2_META * (M_E / M_MU) ** 2
    print(f"         R_CF = {R_CF:.3e}  (observed 6.0e-4, 2.6%)")
    claim("R_CF ~ 6.16e-4", R_CF, 6.16e-4, exact=False, tol=0.1e-4)

    section("X17 mass  m_X17 = Lambda_meta * exp(-9/b_eff)")
    m_X17 = LAMBDA_META * math.exp(-9 / B_EFF) * 1e3  # GeV -> MeV
    print(f"         m_X17 = {m_X17:.2f} MeV  (observed 17.01 +/- 0.16)")
    claim("m_X17 ~ 17.65 MeV", m_X17, 17.65, exact=False, tol=0.6)

    section("Electron cascade  m_e = Lambda_meta * exp(-N_e/b_eff)")
    N_e = 10
    m_e_pred = LAMBDA_META * math.exp(-N_e / B_EFF) * 1e3  # MeV
    print(f"         m_e(cascade) = {m_e_pred:.3f} MeV  (observed 0.511)")
    claim("m_e(cascade) ~ 0.508 MeV", m_e_pred, 0.508, exact=False, tol=0.02)

    section("Inter-level ratio  exp(1/b_eff) = 34.63")
    ratio = math.exp(1 / B_EFF)
    print(f"         exp(1/b_eff) = {ratio:.2f}")
    claim("exp(1/b_eff) ~ 34.63", ratio, 34.63, exact=False, tol=0.05)

    section("Tower cross-checks  (level 10 -> m_e; level 8 -> ~0.6 GeV)")
    m_lvl10 = LAMBDA_META * math.exp(-10 / B_EFF) * 1e3  # MeV
    m_lvl8 = LAMBDA_META * math.exp(-8 / B_EFF) * 1e3 / 1e3  # GeV
    print(f"         level 10: {m_lvl10:.1f} keV-scale -> {m_lvl10*1000:.1f} keV")
    print(f"         level  8: {m_lvl8:.3f} GeV  (~h_AB scale 0.6 GeV)")
    claim("level 10 ~ 0.511 MeV (= m_e)", m_lvl10, 0.511, exact=False, tol=0.01)
    claim("level 8 ~ 0.6 GeV (order)", m_lvl8, 0.6, exact=False, tol=0.1)

    section("Photon : h_AB branching = 3 : 5  (SU(2)_meta multiplicities, T1)")
    # 5/2 x 5/2 = J in {0..5}; (2J+1) = {1,3,5,7,9,11}; photon J=1, h_AB J=2.
    mult = {J: 2 * J + 1 for J in range(6)}
    claim("sum of multiplicities = 36", sum(mult.values()), 36)
    claim("photon:h_AB = (2*1+1):(2*2+1) = 3:5",
          F(mult[1], mult[2]), F(3, 5))

    summary_and_exit()


if __name__ == "__main__":
    main()
