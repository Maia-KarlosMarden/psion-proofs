#!/usr/bin/env python3
"""
P_kappa_reduction.py  --  the single open scalar of P23  (kappa/G)
==================================================================

The whole P23 -> T1 question reduces to one scalar, the electric stiffness
ratio kappa/G. This script verifies, exactly where possible:

  * kappa/G = sinc^2(pi/N_c) = N_c^2/(4 pi^2) = 9/pi^2  (the best analytic value)
  * the geometric deficit alpha_psi = 1 - 9/pi^2  (the "psionic fine-structure")
  * the FUNDAMENTAL IDENTITY  sinc^2(pi/N_c) * g^2 * g_L * t/(2j+1) = 1
    (every factor independently T1) -- the exact consistency of the Axiom I.1
    postulate kappa = G with the Section 2.3 parameters.

The identity is exact rational once sinc^2 is written as N_c^2/(4 pi^2): the
pi^2 cancels against g^2 = 2 pi^2/3, leaving N_c/6 = 1.
"""

import os
import sys
import math

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fractions import Fraction as F  # noqa: E402

from proofs._harness import claim, section, summary_and_exit  # noqa: E402


def main() -> None:
    Nc = 6
    j = F(5, 2)

    section("kappa/G = sinc^2(pi/N_c) = N_c^2/(4 pi^2) = 9/pi^2")
    sinc = math.sin(math.pi / Nc) / (math.pi / Nc)
    kappa_over_G_num = sinc ** 2
    kappa_over_G_closed = Nc ** 2 / (4 * math.pi ** 2)
    claim("sinc^2(pi/6) == N_c^2/(4 pi^2)", kappa_over_G_num,
          kappa_over_G_closed, exact=False, tol=1e-12)
    claim("N_c^2/(4 pi^2) == 9/pi^2", Nc ** 2 / (4 * math.pi ** 2),
          9 / math.pi ** 2, exact=False, tol=1e-12)
    print(f"         kappa/G = {kappa_over_G_closed:.6f}")

    section("geometric deficit alpha_psi = 1 - 9/pi^2")
    alpha_psi = 1 - 9 / math.pi ** 2
    print(f"         alpha_psi = {alpha_psi:.6f}  (1/alpha_psi = {1/alpha_psi:.4f})")
    claim("alpha_psi ~ 0.0881", alpha_psi, 0.0881, exact=False, tol=1e-3)

    section("FUNDAMENTAL IDENTITY  sinc^2(pi/N_c) * g^2 * g_L * t/(2j+1) = 1")
    # Work with exact rationals: sinc^2 = N_c^2/(4 pi^2); g^2 = 2 pi^2/3.
    # The pi^2 cancels exactly, so the product is rational.
    #   [N_c^2/(4 pi^2)] * [2 pi^2/3] * [g_L] * [t/(2j+1)]
    # = N_c^2/(4) * 2/3 * g_L * t/(2j+1)
    g_L = 2                      # gyromagnetic factor of pure spin-5/2
    t = F(1, 2)                  # bond coupling (Theorem I.3)
    two_j_plus_1 = 2 * j + 1     # = 6 = N_c
    # exact symbolic product with the pi^2 cancellation done by hand:
    product = (F(Nc ** 2, 4) * F(2, 3) * g_L * (t / two_j_plus_1))
    claim("sinc^2 * g^2 * g_L * t/(2j+1) = 1  (exact, pi^2 cancels)",
          product, F(1))
    claim("2j+1 = N_c", two_j_plus_1, F(Nc))

    section("Consequence: E_flip = kappa * (5/2);  kappa = 1 => E_flip = j")
    # Under Axiom I.1 (kappa = G, i.e. kappa = 1 in ladder units):
    kappa = 1
    E_flip = kappa * F(5, 2)
    claim("E_flip = kappa * 5/2 with kappa=1", E_flip, j)
    print()
    print("NOTE: kappa = 1 is the postulate Axiom I.1 (kappa = G). The best")
    print("ANALYTIC value from Section 2.3 is kappa/G = 9/pi^2 ~ 0.912, an 8.8%")
    print("deficit = alpha_psi. P23 stays T2+ unless Axiom I.1 is assumed, under")
    print("which the eps_psi -> eta_B cascade is conditional T1.")

    summary_and_exit()


if __name__ == "__main__":
    main()
