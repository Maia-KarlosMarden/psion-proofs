#!/usr/bin/env python3
"""
P_dark_matter.py  —  Dark matter sector: stable Z6 singlets (T1)
=================================================================

Proves Theorem DM.1 (PH Foundations, §14.1):

  Stable neutral Z6 singlets (Q = 0, triality I in {0,3}, no fragmentation
  channel into a lighter neutral singlet) exist, for 4 <= N <= 48, exactly at
  body numbers N in {9, 12, 15, 18, 21, 27}. Total count: 39 stable dark states.

Stability criterion (fragmentation):
  A neutral singlet t of body number N is UNSTABLE iff some proper, non-empty
  sub-multiset s of t (1 <= |s| <= N-1) is itself a neutral singlet. Then
  t -> s + (t \\ s) is allowed by Z6 charge and triality conservation, and the
  complement t \\ s is automatically a neutral singlet as well.

  Note on the previous version of this file: it removed ONE psion at a time and
  tested whether the remaining (N-1)-body state was neutral. Since no single
  psion is neutral (9*Q_k in {1,-5,-5,10,4,4}, never 0), that test can never
  fire, so every neutral singlet was reported stable (33,797 states at
  N = 3, 6, ..., 48) and the file's own assertion failed. The correct test is
  fragmentation into ANY proper sub-multiset, implemented below.

Two independent algorithms:
  A. Reachability DP over (9Q, I) with a size bitmask (same criterion as
     P_body_number_law.stable).
  B. Direct enumeration of every proper sub-multiset via occupation-number
     vectors (cross-check, run for all N <= 27).

N = 3 is the observable three-body sector (n / nu states, §6), not dark matter;
it is reported but excluded from the dark census. Charge arithmetic: since
9*Q_k == 1 (mod 3), Q = 0 requires N == 0 (mod 3).

Paper reference: §14.1, Appendix G.
"""

import sys
from itertools import combinations_with_replacement, product

Nc = 6
Q9 = (1, -5, -5, 10, 4, 4)            # 9*Q_k, exact integers (Table 1)

EXPECTED_N = (9, 12, 15, 18, 21, 27)
EXPECTED_BY_N = {9: 22, 12: 5, 15: 4, 18: 4, 21: 2, 27: 2}
EXPECTED_TOTAL = 39
N_MIN_DARK = 4
N_MAX = 48
N_MAX_BRUTE = 27


def charge9(t):
    return sum(Q9[k] for k in t)


def triality(t):
    return sum(t) % Nc


def is_neutral_singlet(t):
    return charge9(t) == 0 and triality(t) in (0, 3)


# ── Algorithm A: reachability DP ─────────────────────────────────────────────
def stable_dp(t):
    """True iff no proper non-empty sub-multiset of t is a neutral singlet."""
    n = len(t)
    reach = {(0, 0): 1}                # (9Q, I) -> bitmask of reachable sizes
    for k in t:
        new = dict(reach)
        for (q, tr), mask in reach.items():
            key = (q + Q9[k], (tr + k) % Nc)
            new[key] = new.get(key, 0) | (mask << 1)
        reach = new
    proper = ((1 << n) - 1) & ~1       # sizes 1 .. n-1
    return not any(q == 0 and tr in (0, 3) and (mask & proper)
                   for (q, tr), mask in reach.items())


# ── Algorithm B: explicit sub-multiset enumeration ──────────────────────────
def stable_brute(t):
    counts = [t.count(k) for k in range(Nc)]
    n = len(t)
    for sub in product(*(range(c + 1) for c in counts)):
        size = sum(sub)
        if size == 0 or size == n:
            continue
        q = sum(s * Q9[k] for k, s in enumerate(sub))
        tr = sum(s * k for k, s in enumerate(sub)) % Nc
        if q == 0 and tr in (0, 3):
            return False
    return True


def census(n_max=N_MAX):
    """N -> (list of neutral singlets, list of stable ones), via Algorithm A."""
    out = {}
    for N in range(1, n_max + 1):
        if N % 3:
            continue                   # Q = 0 impossible (charge arithmetic)
        ns = [t for t in combinations_with_replacement(range(Nc), N)
              if is_neutral_singlet(t)]
        out[N] = (ns, [t for t in ns if stable_dp(t)])
    return out


def main():
    print("=" * 65)
    print("Theorem DM.1 — Stable Z6 Dark Singlets (T1)")
    print("=" * 65)

    data = census()
    dark = {N: st for N, (_, st) in data.items() if N >= N_MIN_DARK and st}
    total = sum(len(v) for v in dark.values())

    print("\nAlgorithm A (reachability DP), fragmentation criterion:")
    print(f"  {'N':>3}  {'neutral singlets':>16}  {'stable':>6}")
    for N, (ns, st) in sorted(data.items()):
        print(f"  {N:>3}  {len(ns):>16}  {len(st):>6}")
    print(f"  Dark body numbers (N >= {N_MIN_DARK}): {sorted(dark)}")
    print(f"  Total stable dark states: {total}")

    assert tuple(sorted(dark)) == EXPECTED_N, f"got N = {sorted(dark)}"
    assert {N: len(v) for N, v in dark.items()} == EXPECTED_BY_N
    assert total == EXPECTED_TOTAL, f"got {total}"
    assert not data[6][1], "N = 6 must have no stable neutral singlet"
    print(f"\n  THEOREM DM.1 VERIFIED: N in {list(EXPECTED_N)}, {total} states ✓")
    print(f"  TERMINATION VERIFIED: zero stable singlets for 27 < N <= {N_MAX} ✓")
    print(f"  N = 6: {len(data[6][0])} neutral singlets, all fragment into N = 3 ✓")

    print(f"\nAlgorithm B (sub-multiset enumeration), N <= {N_MAX_BRUTE}:")
    for N, (ns, st) in sorted(data.items()):
        if N > N_MAX_BRUTE:
            break
        st_b = [t for t in ns if stable_brute(t)]
        assert st_b == st, f"algorithms disagree at N = {N}"
    print("  A and B agree on every neutral singlet ✓")

    print("\nBreakdown by body number:")
    print(f"  {'N':>4}  {'I=0':>6}  {'I=3':>6}  {'Total':>6}")
    for N in EXPECTED_N:
        i0 = sum(1 for s in dark[N] if triality(s) == 0)
        i3 = sum(1 for s in dark[N] if triality(s) == 3)
        print(f"  {N:>4}  {i0:>6}  {i3:>6}  {i0 + i3:>6}")
    print(f"  {'Total':>4}  {'':>6}  {'':>6}  {total:>6}")
    return True


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
