#!/usr/bin/env python3
"""
P_kinematic_stability.py  --  Theorem KS: what is proved, and what is suspended
================================================================================

Companion to PH Foundations §8 (Theorem 8.1, Table 3, Corollary 8.2).

SCOPE (read first). This module verifies inequality (11) as an EXACT statement
about the cascade mass function m(l) = Lambda_meta * exp(-l/b_e) over partitions
of the cascade level l. It does NOT establish kinematic stability of physical
composites, and it is not a proof of Corollary 8.2. Reason: physical
fragmentation conserves psion (body) number N, but the mass depends on the
cascade level l, and l is not a function of N (scripts/cascade_level_anchors.py:
h_AB and X17 are both N = 2 yet sit at l = 8 and l = 9). No rule is derived yet
that fixes the levels of the fragments from the level of the parent, so (11)
cannot be transported from levels to body numbers. Section C registers this gap
explicitly so that the suite fails if anyone silently restores the old reading.

Dark-matter stability does not depend on KS. It rests on Theorem DM.1, the
exhaustive Z6 fragmentation census (proofs/P_dark_matter.py), re-checked in
Section D, together with psion-number conservation.

Sections
  A. Inequality (11) on every partition of every level 2 <= l <= 50 (exact).
  B. The minimum over k-part partitions is attained at the balanced partition,
     and Table 3 is reproduced from it.
  C. Scope guard: level is not a function of body number (KS premise gap).
  D. Dark-matter stability delegated to DM.1 (census, N <= 27).

This file replaces a module of the same name cited in earlier releases
("203 tests passing") that is not present in the repository.
"""

from __future__ import annotations

import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from proofs._harness import claim, section, summary_and_exit  # noqa: E402

B_E = 325 / 1152
LAMBDA_META = 1.2609e12      # GeV, §4.1 (only used to print m(l))
L_MAX = 50
BOUND = 2 * math.exp(1 / B_E)  # right-hand side of (11), ~69.3


# ── core functions (importable by tests) ─────────────────────────────────────
def mass(level: int) -> float:
    return LAMBDA_META * math.exp(-level / B_E)


def ratio(level: int, parts: tuple[int, ...]) -> float:
    """sum_i m(l_i) / m(l) = sum_i exp((l - l_i)/b_e); requires sum(parts) == l."""
    assert sum(parts) == level and all(p >= 1 for p in parts)
    return sum(math.exp((level - p) / B_E) for p in parts)


def partitions(n: int, max_part: int | None = None):
    """All partitions of n into positive parts, non-increasing order."""
    if max_part is None:
        max_part = n
    if n == 0:
        yield ()
        return
    for first in range(min(n, max_part), 0, -1):
        for rest in partitions(n - first, first):
            yield (first,) + rest


def balanced(level: int, k: int) -> tuple[int, ...]:
    q, r = divmod(level, k)
    return tuple([q + 1] * r + [q] * (k - r))


def min_ratio(level: int, k: int) -> float:
    return ratio(level, balanced(level, k))


# Cascade anchors (scripts/cascade_level_anchors.py): name -> (body N, level l)
ANCHORS = {"h_AB": (2, 8), "X17": (2, 9), "electron": (3, 10)}

# Table 3 of §8.2 (corrected print): level -> (min k=2 ratio, min k=3 ratio);
# None = no 3-part partition exists.
TABLE3 = {2: (69.3, None), 8: (2.88e6, 1.82e9), 9: (5.12e7, 5.17e9),
          10: (9.96e7, 1.21e11), 12: (3.45e9, 6.20e12), 27: (3.67e21, 1.54e28)}
# k = 3 entries as printed in v8.4, kept as an erratum record. l = 2: the
# printed 3597 is the bound 3*exp(2/b_e), not a ratio of any partition.
ERRATA_V84_K3 = {2: 3597, 8: 5.60e11, 10: 8.05e13}


def main() -> None:
    section("A. Inequality (11) on every partition, 2 <= l <= 50 (exact arithmetic)")
    n_part = 0
    worst = math.inf
    violations = 0
    k_bound_fail = 0
    for level in range(2, L_MAX + 1):
        for parts in partitions(level):
            k = len(parts)
            if k < 2:
                continue
            n_part += 1
            r = ratio(level, parts)
            worst = min(worst, r)
            if r < BOUND:
                violations += 1
            if r < k * math.exp((k - 1) / B_E) * (1 - 1e-12):
                k_bound_fail += 1
    print(f"         partitions checked: {n_part:,}")
    claim("no partition violates sum m(l_i)/m(l) >= 2 exp(1/b_e)", violations, 0)
    claim("intermediate bound k*exp((k-1)/b_e) holds on every partition",
          k_bound_fail, 0)
    claim("global minimum equals 2 exp(1/b_e) (attained at l = 2, parts 1+1)",
          worst, BOUND, exact=False, tol=1e-9)
    print(f"         2 exp(1/b_e) = {BOUND:.4f}")

    section("B. Minimum over k-part partitions is the balanced split; Table 3")
    not_balanced = 0
    for level in range(2, 31):
        for k in range(2, level + 1):
            best = min(ratio(level, p) for p in partitions(level) if len(p) == k)
            if not math.isclose(best, min_ratio(level, k), rel_tol=1e-12):
                not_balanced += 1
    claim("balanced partition is the minimiser for every (l <= 30, k)",
          not_balanced, 0)
    worst = 0.0
    for level, (r2, r3) in TABLE3.items():
        c2 = min_ratio(level, 2)
        c3 = min_ratio(level, 3) if level >= 3 else None
        worst = max(worst, abs(c2 / r2 - 1))
        if (c3 is None) != (r3 is None):
            worst = math.inf
        elif c3 is not None:
            worst = max(worst, abs(c3 / r3 - 1))
        c3s = f"{c3:.3e}" if c3 is not None else "none"
        print(f"         l={level:>2}  m={mass(level):.3e} GeV  "
              f"k=2: {c2:.3e}  k=3: {c3s}")
    claim("Table 3 (corrected) reproduced to printed precision (< 0.5%)",
          worst < 5e-3, True)
    stale = sorted(l for l, v in ERRATA_V84_K3.items()
                   if l < 3 or abs(min_ratio(l, 3) / v - 1) > 5e-3)
    claim("v8.4 erratum: printed k = 3 entries at l = 2, 8, 10 were wrong",
          stale, [2, 8, 10])

    section("C. Scope guard: the KS premise gap (level is not a function of N)")
    by_n: dict[int, set[int]] = {}
    for name, (n_body, level) in ANCHORS.items():
        by_n.setdefault(n_body, set()).add(level)
    claim("two N = 2 anchors sit at different levels (h_AB l=8, X17 l=9)",
          by_n[2], {8, 9})
    lvl_7_plus_n = {name: 7 + n for name, (n, _) in ANCHORS.items()}
    claim("level = 7 + N fails on h_AB without using X17 (predicts 9, is 8)",
          lvl_7_plus_n["h_AB"] != ANCHORS["h_AB"][1], True)
    claim("heavier body number at a lighter level (electron N=3 below N=2 states)",
          ANCHORS["electron"][1] > max(by_n[2]), True)
    print("         STATUS: inequality (11) is proved for partitions of the LEVEL.")
    print("         Physical fragmentation partitions BODY NUMBER. Without a rule")
    print("         for fragment levels, KS's physical application and Corollary")
    print("         8.2 are SUSPENDED. This module makes no claim about them.")

    section("D. Dark-matter stability delegated to Theorem DM.1 (N <= 27)")
    from proofs.P_dark_matter import EXPECTED_BY_N, census
    data = census(n_max=27)
    dark = {n: len(st) for n, (_, st) in data.items() if n >= 4 and st}
    claim("DM.1 census: 39 stable neutral singlets at N in {9,...,27}",
          dark, EXPECTED_BY_N)
    claim("no stable neutral singlet at N = 6 (all fragment into N = 3)",
          len(data[6][1]), 0)
    print("         Termination 27 < N <= 48: proofs/P_dark_matter.py.")

    summary_and_exit()


if __name__ == "__main__":
    main()
