#!/usr/bin/env python3
"""
P_charge_algebra.py  --  Z6 charge algebra (Theorem V.1) and the charge interlock
=================================================================================

Verifies, exactly:
  * Theorem V.1: Q_k = q_(k mod 3) + floor(k/3), q = (1/9,-5/9,-5/9)
  * Unit triality: 9*Q_k = 1 (mod 3) for every k
  * Sum_k Q_k = 1  (the resolved erratum; the integer Z2 shift contributes +3)
  * Z3-sector-only sum = -2
  * Charge conjugation = Z6 inversion k -> (6-k) mod 6, with Q -> -Q on singlets
  * The zero-mode charge interlock  N_c * <Q Sigma_r>_0 = 2j  (= 5)
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fractions import Fraction as F  # noqa: E402

from psion_diagram import PSIONS, Composite, conjugate_index  # noqa: E402
from psion_diagram.core import Q3  # noqa: E402
from proofs._harness import claim, section, summary_and_exit  # noqa: E402


def main() -> None:
    section("Theorem V.1: Q_k = q_(k mod 3) + floor(k/3)")
    for p in PSIONS:
        expected = Q3[p.k % 3] + (p.k // 3)
        claim(f"Q_{p.k}", p.Q, expected)

    section("Unit triality: 9*Q_k = 1 (mod 3) for all k")
    for p in PSIONS:
        val = 9 * p.Q
        # 9*Q_k is an integer; check it is 1 mod 3
        assert val.denominator == 1
        claim(f"9*Q_{p.k} mod 3 == 1", int(val) % 3, 1)

    section("Sum_k Q_k = 1  (V.1 corollary; Z2 shift contributes +3)")
    total = sum((p.Q for p in PSIONS), F(0))
    claim("Sum_k Q_k", total, F(1))
    z3_only = sum(Q3[k % 3] for k in range(6))   # without the floor(k/3) shift
    claim("Z3-sector-only sum (q over all six)", z3_only, F(-2))
    z2_shift = sum(k // 3 for k in range(6))
    claim("Z2 chirality shift contributes +3", z2_shift, 3)

    section("Charge conjugation = Z6 inversion  k -> (6-k) mod 6")
    for k in range(6):
        kc = conjugate_index(k)
        claim(f"conj({k}) = (6-{k}) mod 6", kc, (6 - k) % 6)
    # On the electron triple, Q flips sign.
    e = Composite((0, 1, 2))
    claim("Q(e-) = -Q(e+)", e.Q, -e.conjugate.Q)

    section("Zero-mode charge interlock  N_c * <Q Sigma_r>_0 = 2j")
    # Zero mode |0> = (|k=2,L> - |k=3,R>)/sqrt(2); <Q Sigma_r>_0 = (Q3 - Q2)/2.
    Q2 = PSIONS[2].Q
    Q3_ = PSIONS[3].Q
    dQ = Q3_ - Q2
    expval = dQ / 2
    Nc = 6
    interlock = Nc * expval
    claim("Delta Q = Q3 - Q2", dQ, F(5, 3))
    claim("<Q Sigma_r>_0 = Delta Q / 2", expval, F(5, 6))
    claim("N_c * <Q Sigma_r>_0 = 2j = 5", interlock, F(5))

    summary_and_exit()


if __name__ == "__main__":
    main()
