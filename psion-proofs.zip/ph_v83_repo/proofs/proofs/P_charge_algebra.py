#!/usr/bin/env python3
"""
P_charge_algebra.py  --  Table 1 labels, the conserved charge and the interlock
================================================================================

Self-contained (definitions in proofs/_z6.py). Verifies, exactly:
  * Theorem V.1 for the Table 1 labels: Q_k = q(k mod 3) + floor(k/3)
  * unit triality 9 Q_k = 1 (mod 3); sum_k Q_k = 1 (Z3 part -2, Z2 shift +3)
  * conjugation index k -> (6-k) mod 6; Q(e+) = -Q(e-) for the electron triple
  * the J.6.4 interlock N_c <Q Sigma>_0 = 2j = 5 holds for the labels, and gives
    3/2 with the conserved charge (section 1, P-Qcons)
  * label charge = conserved charge + delta(k mod 3), delta = (25, -8, -17)/36,
    which sums to zero over the three proto-colours
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fractions import Fraction as F  # noqa: E402

from proofs._harness import claim, section, summary_and_exit  # noqa: E402
from proofs._z6 import (Q3, Q_label, conjugate_index, conserved_charge,  # noqa: E402
                        label_charge)


def main() -> None:
    section("Theorem V.1 (Table 1 labels)")
    table1 = [F(1, 9), F(-5, 9), F(-5, 9), F(10, 9), F(4, 9), F(4, 9)]
    for k in range(6):
        claim(f"Q_{k}", label_charge(k), table1[k])
        claim(f"9 Q_{k} mod 3 = 1", int(9 * label_charge(k)) % 3, 1)
    claim("sum_k Q_k", sum(table1, F(0)), F(1))
    claim("Z3 part of the sum", sum((Q3[k % 3] for k in range(6)), F(0)), F(-2))

    section("Conjugation index")
    for k in range(6):
        claim(f"conj({k})", conjugate_index(k), (6 - k) % 6)
    e = (0, 1, 2)
    claim("Q(e+) = -Q(e-)", Q_label(tuple(conjugate_index(k) for k in e)), -Q_label(e))

    section("Interlock of App. J.6.4")
    dQ_label = label_charge(3) - label_charge(2)
    claim("labels: N_c * dQ/2 = 2j", 6 * dQ_label / 2, F(5))
    dQ_cons = conserved_charge(3) - conserved_charge(2)
    claim("conserved charge: dQ(2->3)", dQ_cons, F(1, 2))
    claim("conserved charge: N_c * dQ/2", 6 * dQ_cons / 2, F(3, 2))

    section("Label charge = conserved charge + delta(proto-colour)")
    delta = [label_charge(k) - conserved_charge(k) for k in range(6)]
    claim("delta depends only on k mod 3", delta[:3], delta[3:])
    claim("delta", delta[:3], [F(25, 36), F(-8, 36), F(-17, 36)])
    claim("delta sums to zero over proto-colours", sum(delta[:3], F(0)), F(0))
    claim("sum of conserved charges", sum((conserved_charge(k) for k in range(6)), F(0)), F(1))

    summary_and_exit()


if __name__ == "__main__":
    main()
