#!/usr/bin/env python3
"""
*** RETRACTED (dark-matter mass) -- kept for the audit record. ***
The law level = 7 + N_body assumed by this script is refuted by
scripts/cascade_level_anchors.py: h_AB and X17 are both 2-body states but sit at
cascade levels 8 and 9, so the cascade level is not a function of body number
(the law gives h_AB level 9, not 8, even without the X17 anchor). The derived
m_DM ~ 14.3 GeV and the "not super-heavy" conclusion below are therefore
withdrawn. The canonical dark-matter mass is the Landau-pole value of §14.2,
m_DM = 2*Lambda_meta/35 ~ 7.2e10 GeV (scripts/dm_prova_real.py).
Still valid here: the stability test stable() (fragmentation criterion) and
the 39-state dark census it reproduces. Steps E.3-E.5 now report the retracted
numbers as information only and register no claims on them.

P_body_number_law.py  --  the body-number mass law, anchored by the X17 state
=============================================================================

STEP E of the roadmap. The binding-level law was calibrated only on the three
leptons (all 3-body), leaving the body-number dependence unknown (the T3 gate).
The X17 anomaly provides the missing non-lepton anchor: it is a 2-BODY state
(N=2) at binding level 9 with a KNOWN mass (~17 MeV).

ANCHORS (|m^R_J| = 0 states):
  electron: N=3, level 10.000 (calibration point), mass 0.511 MeV
  X17:      N=2, level  9.011, mass 17.0 MeV

DERIVED LAW (X17-anchored):
  level(N, |m^R_J|) = (7 + N) - A |m^R_J|^p,   A = 13/12, p = 5/6
  mass = Lambda_meta * exp(-level / b),         b = 325/1152

This reproduces the lepton law (N=3 -> level = 10 - A|m^R_J|^p, i.e. N_e = 10
is just 7 + 3) AND the X17 (N=2 -> level ~9). N_e = 10 is therefore NOT
fundamental; it is 7 + N_body. The T3 gate is closed.

KEY PHYSICAL CONSEQUENCE (overturns the earlier picture):
  Larger N => larger level => DEEPER binding => SMALLER mass. So heavier-body
  dark composites are LIGHTER, not heavier. The dominant (heaviest) dark matter
  state is at N=9, |m^R_J|=25/2, mass ~ 14.3 GeV -- a WIMP-window mass, NOT the
  super-heavy ~1e10 GeV of the earlier (mass-blocked) guess. The super-heavy
  picture is RETRACTED.

UNCERTAINTY AUDIT (added in review — the law is approximate, not exact):
  (1) The X17 sits at level 9.011, not exactly 9. The two |m^R_J|=0 anchors thus
      give c0 = 7.000 (electron) vs 7.011 (X17): the slope d(level)/dN = 0.989,
      not exactly 1. "7+N" is an ~1%-level approximation, not an identity.
  (2) That ~1% level error is AMPLIFIED ~6x for the N=9 dominant state (6 lever-
      arms from the N=3 anchor): slope 0.989 instead of 1 shifts m_DM from 14.3
      to ~18 GeV (+26%). So m_DM = 14.3 GeV holds only if the slope is exactly 1.
  (3) m_DM is steeply sensitive to the |m^R_J| coefficients: +1% in A -> +37%,
      +1% in p -> +95% in m_DM, because the spectrum is very steep (|m^R_J|=25/2
      gives 14.3 GeV but 23/2 gives 1.7 GeV). A and p carry the lepton fit's
      ~5-9% muon/tau error, so m_DM inherits a substantial uncertainty.
  Net: m_DM ~ 14.3 GeV is the central value, but its honest uncertainty is large
  (tens of percent). This is the dominant lever on Omega_DM/Omega_b (see
  docs/REVIEW_AUDIT.md).

CAVEAT: muon/tau still carry the lepton law's ~5-9% error (unchanged; the
body-number law is identical to the lepton law for N=3). The law is leading-
order; sub-leading corrections remain open.
"""

import os
import sys
import math

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fractions import Fraction as F
from itertools import combinations_with_replacement

from proofs._harness import claim, section, summary_and_exit

LAM = 1.2662e12
B = 325/1152
A = F(13, 12)
P = F(5, 6)
Q9 = [1, -5, -5, 10, 4, 4]


def Q9s(t): return sum(Q9[k] for k in t)
def Itr(t): return sum(t) % 6
def mRJ(t): return abs(sum(F(2*k-5, 2) for k in t if k >= 3))
def level(N, mr): return (7 + N) - float(A)*float(mr)**float(P)
def mass_GeV(t): return LAM*math.exp(-level(len(t), mRJ(t))/B)
def stable(t):
    n = len(t); reach = {(0, 0): 1}
    for k in t:
        new = dict(reach)
        for (q, tr), mask in reach.items():
            key = (q + Q9[k], (tr + k) % 6)
            new[key] = new.get(key, 0) | (mask << 1)
        reach = new
    mid = ((1 << n) - 1) & ~1
    return not any(q == 0 and tr in (0, 3) and (mask & mid)
                   for (q, tr), mask in reach.items())


def main():
    section("Step E.1: the X17 non-lepton anchor fixes the body-number term")
    # |m^R_J| = 0 anchors: electron (N=3, level 10.000), X17 (N=2, level 9.011)
    claim("electron level = 7 + N_body = 10 (calibration point)", 7 + 3, 10)
    # X17 observed level from its mass (NOT exactly 9 — it is 9.011)
    x17_level = -B*math.log(17.0e-3/LAM)
    claim("X17 observed level ~ 9.0 (actually 9.011, gives slope 0.989 not 1)",
          x17_level, 9.0, exact=False, tol=0.05)
    print(f"         X17 level (from mass 17 MeV) = {x17_level:.4f}; "
          f"slope d(level)/dN = {(10-x17_level)/(3-2):.4f} (not exactly 1)")
    # masses from the law (with the slope-1 idealization)
    m_e = LAM*math.exp(-level(3, F(0))/B)*1e3   # MeV
    m_X17 = LAM*math.exp(-level(2, F(0))/B)*1e3  # MeV
    claim("electron mass from law ~ 0.511 MeV", m_e, 0.511, exact=False, tol=0.02)
    claim("X17 mass from idealized (slope-1) law ~ 17.7 MeV (obs 17.0, ~4% high)",
          m_X17, 17.7, exact=False, tol=0.8)

    section("Step E.2: law reduces to the lepton law for N=3 (N_e = 7+3 = 10)")
    # identical to lepton law level = 10 - A|m^R_J|^p
    for nm, t in [("electron", (0, 1, 2)), ("muon", (0, 2, 4)), ("tau", (0, 1, 5))]:
        lvl_body = level(3, mRJ(t))
        lvl_lepton = 10 - float(A)*float(mRJ(t))**float(P)
        claim(f"{nm}: body-number law == lepton law (N=3)",
              abs(lvl_body - lvl_lepton) < 1e-9, True)

    section("Step E.3: T3 gate closed — dark matter masses are now computable")
    spectrum = []
    for Nn in (9, 12, 15, 18, 21, 27):
        for t in combinations_with_replacement(range(6), Nn):
            if Q9s(t) == 0 and Itr(t) in (0, 3) and stable(t):
                spectrum.append((mass_GeV(t), len(t), mRJ(t), t))
    spectrum.sort(reverse=True)
    claim("all 39 dark states (valid N {9,12,15,18,21,27}) now computable",
          len(spectrum), 39)
    m_dom, N_dom, mr_dom, t_dom = spectrum[0]
    print(f"         [RETRACTED, info only] the body-number law would give "
          f"m = {m_dom:.3f} GeV at N={N_dom}, |m^R_J|={mr_dom}")
    print("         The law level = 7 + N is refuted (scripts/cascade_level_anchors.py);")
    print("         canonical m_DM = 2*Lambda_meta/35 ~ 7.2e10 GeV (Sec. 14.2).")

    # Steps E.4-E.5 below depend on the retracted m_DM ~ 14.3 GeV. They are
    # kept for the audit record only and are NOT executed.
    summary_and_exit()

    section("Step E.4: consequence for Omega_DM/Omega_b (the goal)")
    mp = 0.938
    eta_B = 6.02e-10
    Yb = eta_B/7.04
    target = 5.4*mp*Yb
    Y_DM_needed = target/m_dom
    print(f"         target m_DM*Y_DM = 5.4*m_b*Y_b = {target:.3e} GeV")
    print(f"         with m_DM = {m_dom:.2f} GeV -> Y_DM/Y_b = {Y_DM_needed/Yb:.3f}")
    claim("required dark yield Y_DM/Y_b is order unity (0.1-1), not extreme",
          0.05 < Y_DM_needed/Yb < 2.0, True)
    print("         => with m_DM fixed, the goal reduces to deriving Y_DM/Y_b")
    print("            (the dark comoving yield) ~ 0.35 Y_b. Step D, now sharp.")

    section("Step E.5: uncertainty audit (review) — m_DM is a central value")
    # slope sensitivity: m_DM under slope 1.000 vs the actual 2-anchor 0.989
    def m_slope(slope):
        c0 = 10 - slope*3           # fix to electron
        lvl = c0 + slope*9 - float(A)*float(F(25, 2))**float(P)
        return LAM*math.exp(-lvl/B)
    m_unit = m_slope(1.000)
    m_real = m_slope(0.989)
    claim("m_DM(slope=1) ~ 14.3 GeV", m_unit, 14.3, exact=False, tol=0.3)
    claim("slope 0.989 (actual 2-anchor) shifts m_DM by >20% (to ~18 GeV)",
          abs(m_real - m_unit)/m_unit > 0.20, True)
    print(f"         m_DM: slope 1.000 -> {m_unit:.1f} GeV; "
          f"slope 0.989 -> {m_real:.1f} GeV ({(m_real/m_unit-1)*100:+.0f}%)")
    # A,p sensitivity
    def m_Ap(Af, pf):
        lvl = (7+9) - (float(A)*Af)*float(F(25, 2))**(float(P)*pf)
        return LAM*math.exp(-lvl/B)
    claim("m_DM steeply sensitive to A (+1% A -> >30% in m_DM)",
          abs(m_Ap(1.01, 1.0) - m_unit)/m_unit > 0.30, True)
    print(f"         +1% in A -> {(m_Ap(1.01,1.0)/m_unit-1)*100:+.0f}% in m_DM; "
          f"+1% in p -> {(m_Ap(1.0,1.01)/m_unit-1)*100:+.0f}% in m_DM")
    print("         => m_DM = 14.3 GeV is the CENTRAL value; honest uncertainty")
    print("            is tens of percent (slope + A,p, inheriting the lepton")
    print("            fit's ~5-9% muon/tau error). Dominant lever on the ratio.")

    summary_and_exit()


if __name__ == "__main__":
    main()
