#!/usr/bin/env python3
"""
P_counting_theorems.py  --  counting results of section 6 (self-contained)
==========================================================================

Verifies, by exact enumeration with the definitions of PH_Foundations v8.7:
  * Theorem 6.1: of the C(6,3) = 20 distinct-label triples, 8 are colour
    singlets and exactly 3 of these are neutral (identified with the neutrinos)
  * Theorem 6.2: exactly one colour-singlet triple has Q = -1, (0, 1, 2)
  * Theorem 6.3: Q = n_R - 1 on every colour-singlet triple
  * N_gen = 3: a fourth generation would need J_R = 7/2 > j = 5/2
  * Charges of the eight triples are the same with the Table 1 labels and with
    the conserved charge Q = N/6 + sum F_z/4 (section 1)

Not claimed here: N_g = 8 and N_e = 10. They are conditional on the emergence of
SU(3) colour (P-Ng); the counting |Z3|^2 - 1 is not a Z6 theorem (section 6).
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fractions import Fraction as F  # noqa: E402

from proofs._harness import claim, section, summary_and_exit  # noqa: E402
from proofs._z6 import (J, Q_conserved, Q_label, distinct_triples,  # noqa: E402
                        is_singlet)


def main() -> None:
    triples = distinct_triples()
    singlets = [t for t in triples if is_singlet(t)]

    section("Theorem 6.1: neutral colour-singlet triples")
    claim("distinct-label triples", len(triples), 20)
    claim("colour singlets among them", len(singlets), 8)
    neutral = [t for t in singlets if Q_label(t) == 0]
    claim("neutral colour-singlet triples", neutral, [(0, 1, 5), (0, 2, 4), (1, 2, 3)])

    section("Theorem 6.2: unique Q = -1 triple")
    claim("Q = -1 colour-singlet triples", [t for t in singlets if Q_label(t) == -1], [(0, 1, 2)])

    section("Theorem 6.3: Q = n_R - 1 on colour-singlet triples")
    for t in singlets:
        n_R = sum(1 for k in t if k >= 3)
        claim(f"Q{t} = n_R - 1", Q_label(t), F(n_R - 1))

    section("Label charge = conserved charge on the eight triples (section 1)")
    for t in singlets:
        claim(f"Q_label{t} = Q_conserved{t}", Q_label(t), Q_conserved(t))

    section("N_gen = 3 (kinematic bound)")
    claim("J_R of a fourth generation exceeds j", F(7, 2) > J, True)

    summary_and_exit()


if __name__ == "__main__":
    main()
