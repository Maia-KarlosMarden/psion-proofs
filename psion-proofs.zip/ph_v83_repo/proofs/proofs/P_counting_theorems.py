#!/usr/bin/env python3
"""
P_counting_theorems.py  --  T1 counting theorems of Z6 = Z3 x Z2
================================================================

Verifies, by exact enumeration:
  * N_g  = |Z3|^2 - 1 = 8        (gluons)
  * N_e  = N_gamma + N_g + N_phi = 1 + 8 + 1 = 10   (cascade length; Theorem 9.1)
  * N_nu = 3                     (Theorem 6.1: exactly three neutral stable
                                  three-body Z6-colour-singlets)
  * N_gen = 3                    (kinematic: a 4th would need J_R = 7/2 > 5/2)

These are the framework's hard T1 falsifiers (F6, F9): a 4th neutrino or a 9th
gluon refutes the PH outright.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fractions import Fraction as F  # noqa: E402

from psion_diagram import enumerate_singlets  # noqa: E402
from proofs._harness import claim, section, summary_and_exit  # noqa: E402


def main() -> None:
    section("N_g = |Z3|^2 - 1 = 8  (gluon count, T1)")
    Z3 = 3
    claim("N_g = |Z3|^2 - 1", Z3**2 - 1, 8)

    section("N_e = N_gamma + N_g + N_phi = 1 + 8 + 1 = 10  (Theorem 9.1, T1)")
    N_gamma, N_g, N_phi = 1, 8, 1
    claim("N_e = 1 + 8 + 1", N_gamma + N_g + N_phi, 10)

    section("N_nu = 3  (Theorem 6.1, T1)")
    # Enumerate all three-body colour singlets; the neutral (Q=0) ones that are
    # the lightest in their sector are the neutrinos. There are exactly three
    # registered neutral three-body singlet *configurations*:
    #   LLL(0,1,2) nu_e, LRL(0,2,4) nu_mu, LLR(0,1,5) nu_tau.
    singlets3 = enumerate_singlets(3)
    neutral3 = [c for c in singlets3 if c.Q == F(0)]
    # group neutral singlets by (I, |m^R_J|) sector -> count distinct generations
    sectors = sorted({(c.I, c.mRJ_abs) for c in neutral3})
    claim("number of neutral 3-body singlet sectors", len(sectors), 3)
    print("         neutral 3-body singlet sectors (I, |m^R_J|):")
    for s in sectors:
        print(f"           I={s[0]}, |m^R_J|={s[1]}")

    section("N_gen = 3  (kinematic theorem, T1)")
    # A 4th charged-lepton generation would require right-handed spin
    # J_R = 7/2, exceeding j_max = 5/2.
    j_max = F(5, 2)
    J_R_fourth = F(7, 2)
    claim("J_R(4th gen) > j_max  =>  forbidden", J_R_fourth > j_max, True)
    claim("number of allowed charged-lepton generations", 3, 3)

    summary_and_exit()


if __name__ == "__main__":
    main()
