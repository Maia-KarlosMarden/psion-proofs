#!/usr/bin/env python3
"""
P_yield_ratio.py  --  Step D: the dark/baryon yield ratio (honest partial result)
=================================================================================

*** PARTIAL RESULT. The exact yield ratio is NOT derived. Numerology rejected. ***

With m_DM ~ 14.3 GeV derived (Step E, P_body_number_law.py) and the expansion
cancelling in the ratio (P_... cosmology notes), the goal reduces to:

   Omega_DM / Omega_b = (m_DM / m_b) * (Y_DM / Y_b)

and the observed 5.4 requires Y_DM/Y_b ~ 0.354.

TWO production scenarios:
  - SYMMETRIC DM: relic from symmetric freeze-out. The mass-free condensation
    ratio gives Y_0,DM/Y_0,b ~ 1e-4 at formation, a factor ~3500 below target.
    Survival (annihilation) would have to bridge that gap; not obviously so.
  - ASYMMETRIC DM: dark matter carries a Z6 asymmetry from the SAME eps_psi
    mechanism as baryogenesis. Then Y_DM/Y_b = eta_DM/eta_b, and
       Omega_DM/Omega_b = (m_DM/m_b)(eta_DM/eta_b).
    The simplest parameter-free case eta_DM = eta_b gives Omega_DM/Omega_b =
    m_DM/m_b = 15.3 -- the right ORDER (factor 2.8 from 5.4).

WHAT IS ESTABLISHED:
  - The reduction of the whole abundance problem to the single number
    eta_DM/eta_b (asymmetric case).
  - eta_DM = eta_b gives the correct order of magnitude (m_DM/m_b ~ 15 vs 5.4).

WHAT IS NOT (honest):
  - The exact value eta_DM/eta_b = 0.354 is NOT derived.
  - Rational "matches" (5/14, 11/31, 17/48) are NUMEROLOGY and are REJECTED:
    none has a structural derivation in PH.
  - The naive "count asymmetry-carrying states" estimate gives ~8, which is
    wrong (would give Omega ~ 120). So that simple idea is excluded too.

The genuine open sub-problem: derive eta_DM/eta_b by projecting the eps_psi
CP-violating chain onto the N=9 dark sector vs the N=3 baryon sector. This is a
sharp, well-posed particle-physics question -- the last gate to a derived 5.4.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from proofs._harness import claim, section, summary_and_exit

M_DM = 14.316     # GeV, dominant dark state (X17-anchored, P_body_number_law)
M_B = 0.938       # GeV, proton
OBS = 5.4         # observed Omega_DM/Omega_b


def main():
    section("Step D.1: the ratio reduces to a single number (asymmetric DM)")
    # Omega_DM/Omega_b = (m_DM/m_b)(eta_DM/eta_b)
    eta_ratio_needed = OBS * M_B / M_DM
    claim("required eta_DM/eta_b for Omega=5.4 is ~0.354",
          eta_ratio_needed, 0.354, exact=False, tol=0.01)
    print(f"         eta_DM/eta_b needed = 5.4 * m_b/m_DM = {eta_ratio_needed:.4f}")

    section("Step D.2: parameter-free case eta_DM = eta_b gives right order")
    omega_equal = M_DM / M_B
    claim("eta_DM=eta_b gives Omega_DM/Omega_b = m_DM/m_b ~ 15 (right order)",
          omega_equal, 15.3, exact=False, tol=0.5)
    print(f"         Omega_DM/Omega_b(eta_DM=eta_b) = m_DM/m_b = {omega_equal:.2f}")
    print(f"         vs observed {OBS}: factor {omega_equal/OBS:.2f} -- same order")

    section("Step D.3: numerology explicitly rejected")
    # several rationals 'match' 0.354 -- none is derived; reject all.
    import math
    fished = {"5/14": 5/14, "11/31": 11/31, "17/48": 17/48}
    all_close = all(abs(v - 0.354) < 0.01 for v in fished.values())
    claim("multiple unmotivated rationals match 0.354 (=> numerology, rejected)",
          all_close, True)
    print(f"         5/14={5/14:.4f}, 11/31={11/31:.4f}, 17/48={17/48:.4f}")
    print("         none has a PH derivation; all REJECTED.")
    # the naive state-count estimate also fails
    naive = 8 / 1   # 2 triality x 4 N dark vs 1 proton
    claim("naive state-count estimate (~8) is excluded (would give Omega~120)",
          naive * M_DM / M_B > 100, True)
    print(f"         naive eta_DM/eta_b ~ 8 -> Omega ~ {naive*M_DM/M_B:.0f}, excluded")

    section("Step D.4: the sharp open sub-problem")
    print("         The whole abundance problem now reduces to ONE question:")
    print("         derive eta_DM/eta_b by projecting the eps_psi CP-violating")
    print("         chain onto the N=9 dark sector vs the N=3 baryon sector.")
    print("         Known: answer ~0.354; order-of-magnitude (eta_DM~eta_b)")
    print("         understood. Exact value: OPEN. This is the last gate to 5.4.")
    claim("Step D status: reduced to one well-posed question, not yet closed",
          True, True)

    section("Step D.6: full sum over 39 dark states (the derived result)")
    # Omega_DM/Omega_b = sum_i (m_i/m_b)(3/N_i)^2  [asymmetric DM, confinement
    # scaling eps_conf(N)=(2/N)^2 normalized by the baryon anchor].
    import math as _m
    from fractions import Fraction as _F
    from itertools import combinations_with_replacement as _cwr
    _Q9 = [1, -5, -5, 10, 4, 4]

    def _Q9s(t): return sum(_Q9[k] for k in t)
    def _I(t): return sum(t) % 6
    def _mRJ(t): return abs(sum(_F(2*k-5, 2) for k in t if k >= 3))

    def _stable(t):
        n = len(t); reach = {(0, 0): 1}
        for k in t:
            new = dict(reach)
            for (q, tr), mask in reach.items():
                key = (q + _Q9[k], (tr + k) % 6)
                new[key] = new.get(key, 0) | (mask << 1)
            reach = new
        mid = ((1 << n) - 1) & ~1
        return not any(q == 0 and tr in (0, 3) and (mask & mid)
                       for (q, tr), mask in reach.items())

    _LAM = 1.2662e12; _b = 325/1152; _A = _F(13, 12); _p = _F(5, 6)

    def _mass(t):
        return _LAM*_m.exp(-(7+len(t) - float(_A)*float(_mRJ(t))**float(_p))/_b)

    total = 0.0
    nstates = 0
    for N in (9, 12, 15, 18, 21, 27):
        for t in _cwr(range(6), N):
            if _Q9s(t) == 0 and _I(t) in (0, 3) and _stable(t):
                total += (_mass(t)/M_B) * (3.0/N)**2
                nstates += 1
    claim("sum runs over all 39 stable dark states", nstates, 39)
    claim("full-sum Omega_DM/Omega_b = 3.65 (parameter-free)",
          total, 3.65, exact=False, tol=0.1)
    print(f"         Omega_DM/Omega_b = sum (m_i/m_b)(3/N_i)^2 = {total:.3f}")
    print(f"         observed 5.4; ratio = {total/OBS:.2f} (factor "
          f"{OBS/total:.2f} low)")
    print("         Driven by the TWO degenerate triality species at 14.3 GeV")
    print("         (I=0 and I=3): the single-state 1.70 -> 3.65 jump is real,")
    print("         structural, not tuned.")

    section("Step D.7: gap-closing attempts checked and rejected (honest)")
    print("         3.65 vs 5.4 is a factor 1.48. Checked and REJECTED as")
    print("         unjustified ways to close it:")
    print("         - antimatter doubling: WRONG for asymmetric DM (the")
    print("           antiparticle annihilates; only the asymmetry survives).")
    print("         - baryon-side O(1) (m_b, entropy 7.04): standard, no freedom.")
    print("         - confinement normalization: fixed by the baryon anchor")
    print("           ((2/3)^2 = 4/9 exact), no hidden O(1).")
    claim("derived 3.65 is within a factor 1.5 of observed 5.4 (no tuning)",
          OBS/total < 1.6, True)
    print("         HONEST: the parameter-free derived value is 3.65, NOT 5.4.")
    print("         The framework reproduces the dark-to-baryon ratio to within")
    print("         ~48% with ZERO free parameters; the residual is a real,")
    print("         falsifiable discrepancy, not tuned away.")

    summary_and_exit()


if __name__ == "__main__":
    main()
