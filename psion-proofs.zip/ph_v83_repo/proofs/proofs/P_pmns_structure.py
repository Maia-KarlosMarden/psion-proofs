#!/usr/bin/env python3
"""
P_pmns_structure.py  --  Stage 0 of the PMNS programme: the PH flavour basis
============================================================================

Exact statements obtained by enumeration over the Z6 three-body sector. They
fix the basis in which any PH computation of the PMNS matrix must be done.
Mixing itself is NOT derived here (open problem P-PMNS); see
docs/PMNS_PROGRAMME.md and scripts/pmns_models.py.

Claims
  S1  m_k = k - 5/2 reproduces every Sum mJ of Table 2 (SU(2)_meta labels).
  S2  Exactly three neutral observable triples; each has exactly one R
      constituent, and the R constituents carry the three proto-colours
      0, 1, 2 once each, with |m_R| = 1/2, 3/2, 5/2.
  S3  Each neutral triple is the electron (0,1,2) with exactly one constituent
      flipped k -> k+3; the flipped colour labels the generation (bijection).
  S4  Z3 colour rotation c -> c+1 permutes the neutral triples cyclically and
      fixes the electron.
  S5  The charged-current flip k -> k+3 conserves proto-colour and raises Q by
      exactly 1 for every k: the CC vertex is diagonal in the colour basis, so
      PMNS = O_l^T O_nu in that basis.
  S6  Electric charge is invariant under the colour swap 1 <-> 2 (mu <-> tau)
      but not under Z3.
  S7  The swap 1 <-> 2 is not an SU(2)_meta symmetry (it exchanges m values),
      so mu-tau symmetry is broken only by the SU(2)_meta structure.
  S8  (linear algebra, numerical check) With the charged-lepton operator
      diagonal in the colour basis, any real symmetric neutrino operator
      invariant under 1 <-> 2 gives theta13 = 0 and theta23 = 45 deg exactly.
      Hence, in the PH, theta13 and (theta23 - 45 deg) measure the SU(2)_meta
      breaking of mu-tau symmetry.

Paper reference: §6 (Table 2), §J.6, Appendix H, open problem P-PMNS.
"""

from __future__ import annotations

import os
import sys
from fractions import Fraction as F
from itertools import combinations

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from proofs._harness import claim, section, summary_and_exit  # noqa: E402

Q9 = (1, -5, -5, 10, 4, 4)
M = {k: F(2 * k - 5, 2) for k in range(6)}
COLOUR = {k: k % 3 for k in range(6)}
IS_R = {k: k >= 3 for k in range(6)}

TABLE2_SUM_MJ = {(0, 1, 2): F(-9, 2), (0, 1, 5): F(-3, 2), (0, 2, 4): F(-3, 2),
                 (0, 4, 5): F(3, 2), (1, 2, 3): F(-3, 2), (1, 3, 5): F(3, 2),
                 (2, 3, 4): F(3, 2), (3, 4, 5): F(9, 2)}
ELECTRON = (0, 1, 2)
SWAP_12 = {1: 2, 2: 1, 4: 5, 5: 4}


def charge(t) -> F:
    return F(sum(Q9[k] for k in t), 9)


def triality(t) -> int:
    return sum(t) % 6


def neutral_triples():
    return [t for t in combinations(range(6), 3)
            if charge(t) == 0 and triality(t) in (0, 3)]


def r_constituent(t) -> int:
    rs = [k for k in t if IS_R[k]]
    assert len(rs) == 1
    return rs[0]


def generation_colour(t) -> int:
    """PH flavour label of a neutral triple: proto-colour of its R constituent."""
    return COLOUR[r_constituent(t)]


def rotate(t):
    return tuple(sorted((COLOUR[k] + 1) % 3 + 3 * IS_R[k] for k in t))


def swap12(t):
    return tuple(sorted(SWAP_12.get(k, k) for k in t))


def mixing_angles(U):
    s13 = abs(U[0, 2]) ** 2
    s12 = abs(U[0, 1]) ** 2 / (1 - s13)
    s23 = abs(U[1, 2]) ** 2 / (1 - s13)
    return s12, s13, s23


def mu_tau_check(n_samples: int = 2000, seed: int = 7) -> tuple[float, float]:
    """Charged leptons diagonal in the colour basis (O_l = 1) and a random real
    symmetric neutrino operator invariant under 1 <-> 2. Returns the largest
    sin^2 theta13 and |sin^2 theta23 - 1/2| found, with nu3 taken as the
    antisymmetric eigenvector (0, 1, -1)/sqrt2."""
    rng = np.random.default_rng(seed)
    P = np.array([[1, 0, 0], [0, 0, 1], [0, 1, 0]], float)
    anti = np.array([0, 1, -1]) / np.sqrt(2)
    worst13 = worst23 = 0.0
    for _ in range(n_samples):
        X = rng.normal(size=(3, 3))
        X = X + X.T
        X = (X + P @ X @ P) / 2                      # project onto mu-tau symmetric
        _, O = np.linalg.eigh(X)
        i3 = int(np.argmax(np.abs(anti @ O)))
        U = O[:, [i for i in range(3) if i != i3] + [i3]]
        _, s13, s23 = mixing_angles(U)
        worst13 = max(worst13, s13)
        worst23 = max(worst23, abs(s23 - 0.5))
    return worst13, worst23


def main() -> None:
    section("S1. SU(2)_meta labels: m_k = k - 5/2")
    ok = all(sum(M[k] for k in t) == v for t, v in TABLE2_SUM_MJ.items())
    claim("m_k = k - 5/2 reproduces all eight Sum mJ entries of Table 2", ok, True)

    section("S2-S3. Generation = proto-colour of the R constituent")
    nus = neutral_triples()
    claim("exactly three neutral observable triples", len(nus), 3)
    claim("each neutral triple has exactly one R constituent",
          all(sum(IS_R[k] for k in t) == 1 for t in nus), True)
    claim("R colours of the three neutral triples are {0,1,2}",
          sorted(generation_colour(t) for t in nus), [0, 1, 2])
    claim("|m_R| by colour is (1/2, 3/2, 5/2)",
          [abs(M[r_constituent(t)]) for t in sorted(nus, key=generation_colour)],
          [F(1, 2), F(3, 2), F(5, 2)])
    flips = {c: tuple(sorted(k + 3 if k == c else k for k in ELECTRON)) for c in range(3)}
    claim("flipping colour c of e(0,1,2) gives the neutral triple of colour c",
          all(generation_colour(flips[c]) == c and flips[c] in nus for c in range(3)), True)
    for t in sorted(nus, key=generation_colour):
        print(f"         colour {generation_colour(t)}: {t}  "
              f"(R k={r_constituent(t)}, m_R={M[r_constituent(t)]})")

    section("S4. Z3 colour rotation")
    images = {t: rotate(t) for t in nus}
    claim("Z3 rotation permutes the neutral triples (bijection)",
          sorted(images.values()) == sorted(nus), True)
    claim("Z3 rotation shifts the generation colour by +1",
          all(generation_colour(images[t]) == (generation_colour(t) + 1) % 3 for t in nus), True)
    claim("Z3 rotation fixes the electron", rotate(ELECTRON), ELECTRON)

    section("S5. Charged-current flip is colour-diagonal")
    claim("flip k -> k+3 conserves proto-colour",
          all(COLOUR[k] == COLOUR[(k + 3) % 6] for k in range(6)), True)
    claim("flip k -> k+3 raises Q by exactly 1 for k = 0, 1, 2",
          [F(Q9[k + 3] - Q9[k], 9) for k in range(3)], [1, 1, 1])

    section("S6-S7. Residual mu-tau symmetry and its breaking")
    trip = list(combinations(range(6), 3))
    claim("Q invariant under colour swap 1 <-> 2 (all 20 triples)",
          all(charge(t) == charge(swap12(t)) for t in trip), True)
    claim("Q not invariant under Z3 rotation",
          all(charge(t) == charge(rotate(t)) for t in trip), False)
    claim("swap 1 <-> 2 changes SU(2)_meta labels (not an SU(2) symmetry)",
          any(M[k] != M[SWAP_12[k]] for k in SWAP_12), True)

    section("S8. mu-tau symmetric operators give theta13 = 0, theta23 = 45 deg")
    w13, w23 = mu_tau_check()
    claim("max sin^2 theta13 over 2000 random mu-tau symmetric operators < 1e-12", w13 < 1e-12, True)
    claim("max |sin^2 theta23 - 1/2| over 2000 random mu-tau symmetric operators < 1e-12",
          w23 < 1e-12, True)

    summary_and_exit()


if __name__ == "__main__":
    main()
