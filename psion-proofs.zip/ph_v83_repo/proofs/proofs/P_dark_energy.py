#!/usr/bin/env python3
"""
P_dark_energy.py  --  the dark-energy coefficient C = N_c/(27 pi^4) and friends
===============================================================================

Verifies:
  * the exact factor decomposition C = N_c * |Z3|^-3 * mu_4D, mu_4D = 1/pi^4
  * the GY determinant ratio 1/48 (y-units) / 1/12 (unit-gap)
  * the domain-wall identity sigma_dw / N0 = 1 (exact, symbolic in f_pi)
  * the master invariant rho_Lambda * G_N^2 prediction vs observed (numerical)
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import sympy as sp  # noqa: E402
from fractions import Fraction as F  # noqa: E402

from proofs._harness import claim, section, summary_and_exit  # noqa: E402


def main() -> None:
    section("Dark-energy coefficient  C = N_c/(27 pi^4) = 2/(9 pi^4)")
    Nc = 6
    pi = sp.pi
    C = sp.Rational(Nc, 27) / pi ** 4
    C_alt = sp.Rational(2, 9) / pi ** 4
    claim("C = N_c/(27 pi^4) == 2/(9 pi^4)", sp.simplify(C - C_alt), 0)
    # factor decomposition
    mu_4D = 1 / pi ** 4
    decomp = Nc * sp.Rational(1, 27) * mu_4D
    claim("C = N_c * (1/27) * (1/pi^4)", sp.simplify(C - decomp), 0)
    claim("|Z3|^3 = 27", 3 ** 3, 27)

    section("GY determinant ratio (Step 3)  det'/det = 1/48 (y-units)")
    # [prod_{j=1}^{n-1} (n-j)/(n+j)] / (2n)^2  at n=2
    n = 2
    prod = sp.prod([sp.Rational(n - jj, n + jj) for jj in range(1, n)])
    ratio = prod / (2 * n) ** 2
    claim("det'/det = (1/3)*(1/16) = 1/48", ratio, sp.Rational(1, 48))
    claim("unit-gap value = 1/12", sp.Rational(1, 48) * 4, sp.Rational(1, 12))

    section("Domain-wall identity  sigma_dw / N0 = 1  (exact, symbolic)")
    f_pi, mZ6 = sp.symbols("f_pi m_Z6", positive=True)
    sigma_dw = 4 * f_pi ** 3
    N0 = sp.Rational(2, 3) * mZ6 * f_pi ** 2
    # with mZ6 = 6 f_pi
    ratio_dw = (sigma_dw / N0).subs(mZ6, 6 * f_pi)
    claim("sigma_dw/N0 with mZ6=6 f_pi", sp.simplify(ratio_dw), 1)

    section("Master invariant  rho_Lambda * G_N^2  (numerical, 0.099%)")
    pred = 1.1214e-123
    obs = 1.1203e-123
    rel = abs(pred - obs) / obs * 100
    print(f"         predicted = {pred:.4e}")
    print(f"         observed  = {obs:.4e}")
    print(f"         rel error = {rel:.3f}%")
    claim("rho_Lambda G_N^2 within 0.15%", rel, 0.0, exact=False, tol=0.15)

    summary_and_exit()


if __name__ == "__main__":
    main()
