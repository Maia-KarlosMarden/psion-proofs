# psion-proofs — Mudanças v84 → v85

## Resumo

Uma auditoria (não um novo resultado físico), disparada pelo confronto da PH
com o evento de LZ (setembro de 2026) e com os resultados de sabor do IceCube.
Nenhuma predição numérica central das Classes A ou B foi alterada. O registro
completo está no Apêndice L.5 do paper (`PH_Foundations_v85.tex`).

## Matéria escura

- **Prova do censo DM.1 corrigida** (`proofs/P_dark_matter.py`). O teste
  antigo removia um psion por vez; como nenhum psion é neutro, o teste nunca
  disparava e o script falhava a própria asserção (33.797 "estados"). Agora
  usa o critério de fragmentação, com dois algoritmos independentes. O
  Teorema DM.1 se mantém: 39 estados em N ∈ {9, 12, 15, 18, 21, 27}; N = 6 é
  totalmente instável.
- **Massa canônica: polo de Landau** (§14.2, m_DM = 2Λ/35 ≈ 7,2×10¹⁰ GeV).
  Nível de cascata ≠ número de corpos (h_AB e X17 têm N = 2, níveis 8 e 9).
  O resultado de 14,3 GeV (`P_body_number_law.py`) está **retratado**; a
  Tabela 3 foi rerrotulada por nível de cascata (§8.1).

## Teorema KS

- A desigualdade (11) vale como aritmética sobre a função de massa, mas a
  fragmentação física particiona número de corpos, não nível. A aplicação
  física e o Corolário 8.2 estão **suspensos** (nota de status, §8.2).
- `proofs/P_kinematic_stability.py`, citado com "203 testes" mas ausente, foi
  reescrito com escopo honesto (11 afirmações, 33 testes).
- **Errata na Tabela 3**, coluna k = 3: ℓ = 2 (não existe partição em 3
  partes), ℓ = 8 (1,82×10⁹, não 5,60×10¹¹) e ℓ = 10 (1,21×10¹¹, não
  8,05×10¹³).

## Registro de falseabilidade

- **F5 dividido.** O limite 10⁻⁵⁰ cm² não tinha derivação e foi aposentado.
  F5a [T2], E2: nenhum estado de matéria escura fora dos 39 singletos em
  m_DM. F5b [T4], E1: σ ~ 10⁻⁵⁴ cm², condicional a acoplamento proto-cor nulo.
  **Critério de morte registrado ex ante** (§9.1); o evento de LZ (2,6σ)
  fica abaixo dele.
- **F3 rebaixado para [T4], condicional ao P-PMNS** (§17.3). A assimetria
  ν_τ/ν_e é função só do PMNS, que a PH não deriva; não há derivação do 7%
  nesta versão.
- Legenda da Tabela 4: 18 linhas (F5a/F5b). Censo E: E1 × 10, E2 × 4, E3 × 3,
  E4 × 1.

## Programa do PMNS (novo)

- `proofs/P_pmns_structure.py` (16 afirmações, exatas): a geração de um
  tripleto neutro é a proto-cor do seu constituinte R; a corrente carregada é
  diagonal em cor; a carga tem simetria residual μ ↔ τ quebrada só pelo
  SU(2)_meta.
- `scripts/pmns_models.py` e `docs/PMNS_PROGRAMME.md`: modelos
  pré-registrados (commits de pré-registro antes de cada avaliação). Com
  léptons carregados diagonais, a eq. (1) com o gap de travamento dá
  sin²θ₁₂ perto do medido, mas sin²θ₂₃ ≈ 0,21. O lado dos léptons carregados
  está bloqueado: as entradas impressas no App. A.2.5 não reproduzem as
  razões de massa do P8b. É preciso a matriz completa do P8b.

## Arquivos

- `paper/PH_Foundations_v85.tex` / `.pdf` (47 páginas): nova versão.
- `paper/PH_Foundations_v84.tex` / `.pdf`: restaurados exatamente como
  publicados no v84, para referência.
- Suíte de testes: 215 passando (`tests/test_engine.py` continua sem
  importar `psion_diagram`, como já ocorria no v84).
