# PH Foundations: v8.7 changes (relative to v8.6, the file on Zenodo record 24446464)

This log is for the repository. The paper itself carries no version or errata language.

## A. Errors shown by calculation

1. **The N = 9 "ground configuration" is not stable.** (0,0,1,1,2,2,3,4,5) splits into
   (0,1,5) + (0,2,4) + (1,2,3), which the repository's own criterion (`P_dark_matter.py`) rejects.
   The count of 39 is correct, but this state is not among them. Removed from Table 8,
   App. H.3 and Example 3. Consequences:
   - none of the 39 states is a pure s-wave state (each has a label occupied 3 or more times);
   - the ground-state spin and the pair (2, 2pi/3) are not derived: F-fork reopened;
   - the prefactor 4pi/3 and the direct route to Omega_DM/Omega_b go to [T4].
2. **Stability covered only neutral-singlet splittings.** 17 of the 39 (all with N >= 12) split into
   two oppositely charged integer-charge singlets. Only the 22 at N = 9 are closed to those.
   All 39 can split into fractionally charged colour singlets: 12 of the 22 can emit a single
   psion (k = 0 or 3), and 8 can emit (1,4,4), the ANITA carrier of section 17.1. Rule 2 of
   App. H.1 (fractional charges confined) is a postulate without mechanism and covers only
   thirds, not the ninths these fragments carry. Stability of the whole dark sector is now
   stated as OPEN, and the ANITA identification is declared incompatible with stability by
   confinement. "Absolute stability" removed.
3. **Corollary 8.2** was still stated as [T1] although the physical use of Theorem KS is suspended. Marked suspended.
4. **Theorem 6.1**: of the 20 distinct-label triples, 8 (not 20) are colour singlets.
5. **F11**: (1+16+25)/81 x 3 is 14/9, not 47/27. The proton triple (0,4,5) gives 11/27.
   Value now "not fixed".
6. **Table 11**: the stable total 534 is incompatible with the table's own saturation rule
   (which allows at most 532). Stable and unstable totals removed.
7. **Delta m^2_31** error: 11.4% (was 11.5%).

## B. Status brought in line with the paper's own text

- rho_Lambda and the master invariant: [T2+] -> [T2] (App. D, "Scope").
- eta_B: xi* is obtained from eta_B itself, so the 1.7% is not a test.
- N_g in the accountability table: "theorem" -> conditional on P-Ng.
- F8, F13: [T2] -> [T4], with a note (F8 not derived and above 2 m_DM and Lambda_meta;
  F13 needs a dark anti-state and is bounded by unitarity to < 1e-11 events).
- R_FG = 4.17e42: xi_cond is not defined and alpha_em is observed; not a prediction.
- App. A.4: state-wise charge conjugation claim removed (it contradicted L.4.2).
- Abstract and conclusions: "derives" -> "seeks to derive"; conditional results said to be conditional.

## C. Reproducibility and references

- App. G URL -> github.com/Maia-KarlosMarden/psion-proofs.
- "All tests passing" removed: `psion_diagram` is imported by modules and tests but is not in the archive.
- `enumerate_z6.py` and `gen_composite_tables.py` were cited but are not in the archive: citations removed.
- Section 14.5: the galaxy comparison also needs the Moster et al. (2013) stellar-to-halo mass relation (new ref. [21]).
- Ref. [20]: unpublished; code not publicly archived.
- Removed pointers to a non-existent section (G.5.2) and a non-existent four-body mass formula.

## E. Added: dark-sector rescue conjecture and a charge-conservation problem

- **C-DC (section 14.1, now [T4]).** Conserved proto-colour counts would give dark charges
  D1 = c1 - c0, D2 = c2 - c0 (zero on all SM states, non-zero on all 39 census states). Tested in a
  two-psion model of the locked phase (`amp.py`): colour counts change at second order,
  amplitude ~ 2 mu lambda / G, steps Delta D = +-(3,0), +-(2,4), which generate every change allowed
  by the exact symmetries (`exact.py`). Exactly conserved: N and F_z. The only charge built from them
  that fits e, n, p is Q = N/6 + sum F_z / 4; none of the 39 census states is neutral under it
  (`steps.py`). Neutral N = 9 singlets under that charge: 30; colour steps needed to decay into SM
  states: 0 (10 states), 1 (15), 2 (4), 3 (1). Lifetime > 1e30 s needs 2 mu lambda / G < ~1e-11.
  G is not determined in the paper.
- **P-Qcons (open problem).** If J+- act on the six k states, Table 1 charges do not commute with the
  coupling (Schur's lemma; `cond2.py`: ||[Q1+Q2, J1.J2]|| = 32.2). The only one-body charge
  conserved by J1.J2 is linear in k; Q = (k-2)/3 reproduces all eight three-body charges, but it
  changes the per-psion charges and the interlock of J.6.4.
- **Charge reading adopted (section 1, P-Qcons).** Literal non-conservation of electric charge was
  rejected (Maxwell/U(1); Borexino e -> nu gamma, tau > 6.6e28 yr). Instead, Table 1 values are
  treated as labels and the electric charge as the conserved current; working candidate
  Q = N/6 + sum F_z / 4 = (-7/12, -1/3, -1/12, 5/12, 2/3, 11/12) per psion, identical to Table 1 on
  all eight three-body states. Testable differences listed in section 1: ANITA carrier +1 (not +1/3),
  flip step 1/2 (not 5/3; removes the J.6.4 interlock behind eps_psi), census states fractionally
  charged, proto-quark charges. Kill criteria: free long-lived fractional charges; wall charge
  released as free fractional charges at wall annihilation. Photon coupling not derived.

## F. Consequences of the charge reading (photon.py)

- Conserved one-body charges of the locked dynamics: exactly N and F_z (dimension 2).
- Table 1 = conserved charge + delta(k mod 3), delta = (25, -8, -17)/36, summing to zero over
  proto-colours: the agreement on the eight triples is structural, not independent evidence.
- Fierz vector-channel kernel of J.Sigma on the diagonal currents: diagonal, |m|/2. No bound state
  couples to a conserved current, so eq. (1) alone does not yield a photon; a gauge principle or a
  compositeness condition is needed. The orthogonal conserved current must not carry a massless vector
  (fifth-force / equivalence-principle test). Written in section 1.
- J.6.4: under the conserved charge the interlock fails (3/2 instead of 5). Charge form of Lemma I.1'
  gives tan theta = 3/50, eps_psi = 0.0143, refit xi* = 199, direct Omega_DM/Omega_b ~ 4e6.
  The spectral form tan theta = t/j = 1/5 is unaffected; the equivalence of the two forms no longer holds.
- Best-protected neutral N = 9 state: (1,1,1,1,1,1,4,4,4), D = (9,0), three colour steps.

## G. Form of Lemma I.1' adopted

- Spectral form tan theta = t/j = 1/5 adopted (J.6.6, [T2], was [T2+]). Reasons: uses only t = 1/2 (T1)
  and j; keeps the Jackiw-Rebbi anchor (eps = 1 at j = 1/2) and the internal Z4 target 9/25; the charge
  form needed the J.6.4 interlock, which holds for Table 1 labels only, and the zero mode is not an
  eigenstate of the conserved charge. eps_psi = 25/169 kept; eta_B still not a prediction; the BBN
  tension of N_eff is kept.
- Charge form recorded as eliminated route C-I8.9 (App. L.1).
- J.6.4 and V.4 identities: stated as exact for Table 1 labels, not for the electric charge.
- P23 rows, A.8, J.3: [T2+] -> [T2].
- Abstract and section 19 aligned: charge-as-label reading, dark-sector stability open (no neutral
  census state under the conserved charge; proto-colour protection broken at second order), new
  conclusions bullet on electric charge.

## D. NOT verified

- The pytest suite and the repository scripts were not executed.
- C_stable values of Table 11, and therefore F14 (classification code absent). A simple count of
  distinct (I,Q) pairs does not reproduce them from N = 4 on.
- Section 14.5 numbers (SPARC, X-COP, CLASH, weak lensing): the phdm/ code was not available.
- "33 tests" and "11 claims" for the kinematic-stability module.
- External experimental values and references (MEG II, PADME, LZ, BBN bounds and others),
  including the bibliographic details of new ref. [21], written from memory.
- Appendices J, K and L: read, with only selected numbers recomputed.

If `psion_diagram`, `enumerate_z6.py` and `gen_composite_tables.py` are added to the repository,
the items that depend on them can be revisited.
