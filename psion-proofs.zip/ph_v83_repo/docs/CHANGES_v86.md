# psion-proofs — Mudanças v85 → v86

## Resumo

Segunda versão publicada do paper (`paper/PH_Foundations_v86.tex`). Resulta de
uma auditoria externa de v84/v85 (22 de novembro de 2026) que recalculou todos
os números verificáveis a partir dos inputs declarados (70 checagens). A
aritmética central (Λ_meta, m_e, ρ_Λ, invariante mestre, ε_ψ, m_DM, as duas
rotas de Ω_DM/Ω_b) se reproduz a ≤ 0,1%. As mudanças são de lógica,
contabilidade e comparadores. O paper v86 é escrito sem linguagem de errata;
este arquivo é o registro das mudanças.

## Placar de sucessos

- "G_N recuperado a 0,83%" usa o m_e observado e é o dobro do resíduo de m_e:
  eq. (7) com eq. (6) é uma identidade. Com G_N como âncora, o setor
  massa–gravidade–cosmologia tem **dois resíduos independentes**: m_e (0,42%)
  e o invariante ρ_Λ G_N² (0,93%).

## Bariogênese

- A forma C_core da antiga eq. (14) foi retirada (não reproduz 6,02×10⁻¹⁰;
  C_core não decorre da fórmula de esfaléron citada; g_S mal definido). A
  eq. (14) agora é a cadeia η_B = ε_ψ · ε_conf · (n/n_γ) · ξ*⁻³.
- ξ* = 434,09 é obtido a partir do η_B previsto. Até P14-ξ* fechar, η_B e a
  rota direta de Ω_DM/Ω_b formam **uma relação de consistência**, não duas
  predições.

## Contagem de glúons (P-Ng)

- 8 = 3² − 1 é a adjunta de SU(3). O Z3 abeliano dá 3 bilineares de cor
  neutros e 6 carregados; SU(6) também tem centro Z6. N_g = 8 e o falseador
  F9 ("nono glúon") passam a ser **condicionais a P-Ng**.
- N_e = 1 + 8 + 1 herda a condição: S, m_e, ρ_Λ e o invariante mudam de
  status de derivação, não de valor.

## Neutrinos

- ΔN_eff usava metade do coeficiente padrão por sabor: corrigido para
  ΔN_eff = 0,020, **N_eff = 3,064**.
- μ_ν/T = 0,123 está em tensão com BBN (T-BBN); F12 desfavorecido salvo se o
  mapa δL → μ_ν/T reduzir ξ abaixo de ~0,05.
- Comparador de Δm²₃₁ = Δm²₃₂ + Δm²₂₁ (erro 11,5%, não 8,7%);
  Δm²₂₁/m_e² com m_e observado (2,884×10⁻¹⁶).

## Consistência interna

- Energia de vácuo CEC vs ρ_Λ registrada como problema PC3; Prop. J.3 e [G2]
  condicionais a PC3.
- Reação da ANITA (antiga eq. 18) retirada: não conserva carga. A
  identificação ν_S = (1,4,4) segue em quarentena E4; reação de produção em
  aberto. Equações seguintes renumeradas.
- Exemplo 3 trocado pelo singleto fundamental N = 9; Tabela 12 refeita (36
  bilineares, não 39); três (não seis) proto-W com Q = +1; o coeficiente C é
  carregado por μ_4D = 1/π⁴; σ_dw/N₀ = 1 é a identidade virial genérica do kink.
- Aritmética: Molien C(7) = 264, C(8) = 429; decomposição da eq. (26);
  cociclo consistente com eq. (26); tripla pitagórica (4j, 4j²−1, 4j²+1);
  integrando √(2V) da tensão do kink; referência Kirsten–McKane adicionada.

## Registro de falseabilidade

- **18 predições falseáveis** (F1–F17 com F5 dividido em F5a/F5b), contadas
  como 18 no resumo e na Tabela 4.

## Matéria escura em halos e RGD

- Nova §14.5: a matéria escura da PH é fria e sem colisões em todas as escalas
  astrofísicas; o kernel RGD foi falsificado por controles de mock.
- O companheiro "Dark Matter: Existence Without Necessity" deixou de ser
  citado (contradiz a §14.5); referências renumeradas.

## Autor

- O bloco de autor traz apenas o nome.

## O que não mudou

Nenhum número central. Mudaram: N_eff (3,054 → 3,064), erro de Δm²₃₁
(8,7% → 11,5%), Δm²₂₁/m_e² (2,908 → 2,884×10⁻¹⁶).
