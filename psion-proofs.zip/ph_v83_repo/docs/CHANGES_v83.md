# psion-proofs — Mudanças v82 → v83

## Resumo

Uma mudança de paradigma epistêmico, dois arquivos novos, uma linha alterada.

## O que mudou conceitualmente

No v82, m_e era tratado como "SC output" (0.508 MeV vs 0.511 MeV observado).
No v83, o repositório declara explicitamente:

> **m_e é o único input empírico do framework.**
> Λ_meta = m_e · exp(+N_e/b_e) é a definição operacional de Λ_meta.

Esta mudança não altera nenhum número. Altera a estrutura lógica de apresentação
e elimina a vulnerabilidade metodológica.

## Arquivos novos

- `scripts/cascade_anchor.py` — declaração canônica do único SC input
- `tests/test_cascade_anchor.py` — suite pytest com 13 testes novos

## Problema novo registrado

P2/P12: derivação autônoma de Λ_meta via Φ(Λ) = Λ sem input observacional.
Condição de fechamento: SC inputs 1 → 0; m_e torna-se previsão.

## O que NÃO muda

Todos os números são idênticos ao v82. 12 testes existentes continuam passando.
Total: 25 testes, todos passando.
