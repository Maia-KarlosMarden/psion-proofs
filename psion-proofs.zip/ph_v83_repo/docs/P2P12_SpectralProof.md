# P2/P12 — Prova Espectral da Massa do Elétron

**Status:** Condicional — Teorema T1 com gargalo identificado  
**Data:** 26 Jun 2026 | **Versão:** PH v83  
**Companion:** P2P12_Reduction.md, P2P12A_Calculation.md

---

## 1. Objetivo

Derivar a massa do elétron como autovalor do kernel de Bethe–Salpeter
no canal eletrônico, sem parâmetros livres:

$$\boxed{m_e = \Lambda_{\rm meta}\, e^{-N_e/b_e}}$$

com $b_e = 325/1152$, $N_e = 10$, $\Lambda_{\rm meta} \approx 1.2662\times10^{12}\ \mathrm{GeV}$.

**Nota numérica (v83):** na formulação atual, $\Lambda_{\rm meta} \equiv m_e\cdot e^{+N_e/b_e}$ é a *definição operacional* da escala do condensado (SC input). A fórmula acima é portanto uma identidade por construção na v83. O objetivo de P2/P12 é inverter essa seta: derivar $\Lambda_{\rm meta}$ — e portanto $m_e$ — da dinâmica 2PI sem input observacional.

---

## 2. Canal Eletrônico e Kernel

O canal eletrônico é

$$e^- = (0,1,2), \qquad \mathcal{O}_e = \psi_0\,\psi_1\,\psi_2$$

invariante sob $\mathbb{Z}_6$. O kernel de Bethe–Salpeter 2PI é

$$\mathcal{K}_e = K_1 K_2 \cdots K_{N_e}$$

com autovalor $\lambda_e$. A massa física: $m_e = \Lambda_{\rm meta}\,\lambda_e$.

---

## 3. Três Lemas

### Lema 1 — Dimensão Anômala (P2/P12-A)

$$\boxed{\Lambda\frac{d}{d\Lambda}\ln\lambda(\Lambda) = \gamma_{\mathcal{O}_e},
\qquad \gamma_{\mathcal{O}_e} = \frac{1}{b_e} = \frac{1152}{325}}$$

**Status: hipótese** — a equação de Callan–Symanzik está correta se
$\gamma = 1/b_e$. Esse é o ponto crítico (P2/P12-A).

Cinco mecanismos foram tentados e eliminados para derivar $Z_{\rm NP} = 32/25$
(e portanto $b_e$) do kernel 2PI. Ver `P2P12A_Calculation.md`.

### Lema 2 — Cascata de Passos Logarítmicos (P2/P12-B)

$$\boxed{\ln\frac{\Lambda_i}{\Lambda_{i+1}} = 1 \quad (i=1,\ldots,10),
\qquad N_e = 10}$$

**Status: estrutural** — a decomposição do canal eletrônico em
representações de $\mathbb{Z}_6$:

$$(0,1,2) \longleftrightarrow \mathbf{1} \oplus \mathbf{8} \oplus \mathbf{1},
\qquad \dim = 1+8+1 = 10$$

é consistente com o Teorema G.1 ($N_e = N_\gamma + N_g + N_\phi = 10$, T1).
Mas a demonstração de que cada bloco corresponde a um passo RG
**independente** requer um teorema de fatoração espectral ainda não provado.

Esta é uma formulação de P2/P12-B potencialmente mais forte do que o
"counting" do Teorema G.1: via representações de $\mathbb{Z}_6$, pode
permitir um "teorema de índice para o operador de Dirac acoplado a um
bundle $\mathbb{Z}_6$-graduado".

### Lema 3 — Condição de Contorno Crítica

$$\boxed{\lambda(\Lambda_{\rm meta}) = 1}$$

**Status: T1** — é a condição de criticidade padrão NJL:
$1 - G(\Lambda)\Pi(\Lambda) = 0$, com $\lambda = G\Pi$.
Bem fundamentado, resultado padrão da teoria NJL. Corresponde à
Proposição I da `P2P12_Reduction.md`.

---

## 4. Teorema Condicional

Integrando o Lema 1 entre $\Lambda_{\rm meta}$ e
$\Lambda_e = \Lambda_{\rm meta} e^{-N_e}$ (usando o Lema 2),
com condição de contorno do Lema 3:

$$\ln\lambda_e = -\gamma_{\mathcal{O}_e}\,N_e = -\frac{N_e}{b_e}$$

$$\boxed{
\left(\gamma_{\mathcal{O}_e} = \frac{1}{b_e}\right)
\;\wedge\; (N_e = 10)
\;\wedge\; (\lambda(\Lambda_{\rm meta}) = 1)
\;\Longrightarrow\;
m_e = \Lambda_{\rm meta}\,e^{-N_e/b_e}
\quad [\text{T1 condicional}]
}$$

A cadeia dedutiva está algebricamente correta sem lacunas.

---

## 5. Gargalo: Inversão Anômala

O coração do programa é derivar

$$\boxed{\gamma_{\mathcal{O}_e} = \frac{1}{b_e}
= \frac{Z_{\rm NP}\,N_c}{b_0}
= \frac{(32/25)\cdot 6}{13/6} = \frac{1152}{325}}$$

**Tentativas registradas e eliminadas:**

| Mecanismo | Resultado |
|---|---|
| Sunset no propagador livre | → 0 no UV |
| Wavefunction renorm. livre | → 0 no UV |
| Sunset no kink (x-space) | Cancela no UV |
| Equação de gap 2PI simples | Dá 19/4 ≠ 32/25 |
| Equação quadrática figura-8 | Dá $(3+2\sqrt{2})/4 \approx 1.457$ ≠ 32/25 |
| Identidades de Slavnov–Taylor | Não resolvidas explicitamente |

**Ponto positivo identificado:** $Z_{\rm NP} = 2^{2j}/(2j)^2 = 32/25$
é uma identidade algébrica exata em $j=5/2$. Todo o sistema de
parâmetros PH é fechado em $j$ (ver `P2P12A_Calculation.md`).

---

## 6. Formulação Rigorosa do Estado da Arte

$$\boxed{
\text{Teorema T1 (condicional):}\quad
\left(\gamma_{\mathcal{O}_e} = \tfrac{1}{b_e},\; N_e=10\right)
\Longrightarrow
m_e = \Lambda_{\rm meta}\,e^{-N_e/b_e}
}$$

$$\boxed{
\text{Hipótese P2/P12-C:}\quad
\Lambda_{\rm meta} = F(\Lambda_{Z_6}),\quad
\Lambda_{Z_6} = \text{escala IR do setor }\mathbb{Z}_6
}$$

**Prova zero-input seria completa se e somente se:**

1. $\gamma_{\mathcal{O}_e} = 1/b_e$ derivado do kernel 2PI **(P2/P12-A)**
2. $N_e = 10$ provado como multiplicidade espectral **(P2/P12-B)**
3. $\Lambda_{Z_6}$ calculado da equação de gap do glúon meta sem $m_e$ **(P2/P12-C)**

**Nenhuma das três condições foi satisfeita até o momento.**

---

## 7. Circularidade em P2/P12-C e Como Evitá-la

O documento original nota que $\Lambda_{Z_6} \approx 0.5\ \mathrm{MeV}$
reintroduz circularidade (pois $m_e = 0.511\ \mathrm{MeV}$).

**Saída proposta:** calcular $\Lambda_{Z_6}$ via equação de
Schwinger–Dyson do **glúon meta** na aproximação de 1-loop,
com $N_f = 0$ ou com férmions pesados que não sejam o elétron.
Isso é P2/P12-C na forma mais concreta:

$$\text{Input: } \mathcal{L}(\mathbb{Z}_6,\; g^2,\; j)\;
\text{com}\; N_f = 0 \quad[\text{sem }m_e]
\longrightarrow
\Lambda_{Z_6}
\longrightarrow
\Lambda_{\rm meta} = F(\Lambda_{Z_6})
$$

---

## 8. Mapa de Dependências

```
Lema 3: λ(Λ_meta) = 1          [T1 — NJL padrão]
Lema 2: N_e = 10 passos RG     [T1 counting; T3 fatoração espectral → P2/P12-B]
Lema 1: γ = 1/b_e               [T3 → P2/P12-A]
    └── Z_NP = 32/25             [T3 → P2/P12-A-i, 5 mecanismos eliminados]
P2/P12-C: Λ_Z6 sem m_e          [T3, SD glúon meta]
    └── evitar circularidade via N_f=0

Se Lema 1 + Lema 2 + P2/P12-C fecharem:
    m_e = F(Λ_Z6) · exp(-10/(325/1152))  →  previsão T1
```

---

## 9. Próximos Passos Concretos

1. **P2/P12-A:** calcular a função de dois pontos de $\mathcal{O}_e$ no
   formalismo 2PI com cargas $q_i$ derivadas da tabela v83 (equação
   diofantina). Extrair $\gamma_{\mathcal{O}_e}$ e verificar se é $1152/325$.

2. **P2/P12-B:** explorar a decomposição $(0,1,2) \leftrightarrow
   \mathbf{1}\oplus\mathbf{8}\oplus\mathbf{1}$ via teorema de índice
   para o operador de Dirac em bundle $\mathbb{Z}_6$-graduado.

3. **P2/P12-C:** resolver a equação de SD do glúon meta com $N_f=0$
   para obter $\Lambda_{Z_6}$ e verificar se $F(\Lambda_{Z_6}) = \Lambda_{\rm meta}$.

---

## 10. Nota sobre a Discrepância 0.519 MeV vs 0.511 MeV

O documento de referência menciona $m_e \approx 0.519\ \mathrm{MeV}$ (1.5% de desvio).
O desvio do leading order do PH é 0.508 MeV (−0.6%). O valor 0.519 MeV
pode vir de uma escolha ligeiramente diferente de $b_e$ ou de subleading corrections.
Em todo caso, na formulação v83, $\Lambda_{\rm meta} \equiv m_e \cdot e^{+N_e/b_e}$
por definição, portanto a fórmula $m_e = \Lambda_{\rm meta}\cdot e^{-N_e/b_e}$
é exata por construção — sem desvio. O desvio aparece apenas quando se
tenta *prever* $m_e$ a partir de uma $\Lambda_{\rm meta}$ derivada
independentemente, que é exatamente o objetivo de P2/P12.

---

*Registrado: 26 Jun 2026 | PH v83 | psion-proofs-v83*
