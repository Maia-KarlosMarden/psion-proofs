# psion-proofs — Mudanças v83 → v84

## Resumo

Uma auditoria dirigida (não um novo resultado físico): reclassificação da
âncora SC, correção de identificação de compostos, prova de escopo sobre
conjugação de carga, e reconciliação de contagens no registro de
falseabilidade. Nenhum valor numérico de predição central foi alterado.

## O que mudou conceitualmente

No v83, m_e era declarado como o único input empírico. No v84, o paper
completo (`PH_Foundations_v84.tex`) trata **G_N** como a âncora SC — m_e
volta a ser output da cascata (0.5089 MeV, 0.42%) — e um **segundo** input
empírico, Δm²₂₁ (escala do setor de neutrinos, §11), é reconhecido
explicitamente pela primeira vez. O framework tem **2 inputs SC**, não 1:

> P2/P12 fecha G_N (2→1). P26-C (T4, não promovido) é o candidato de
> fechamento de Δm²₂₁ (1→0).

## Correções de identificação de compostos (`CHARGE_CONVENTIONS.md`)

- Próton = LRR (0,4,5), Q=+1; Nêutron = LLR (0,1,5), Q=0; (3,4,5) é um
  exótico Q=+2 separado — nunca foi o próton. Ambas as cargas corretas
  batem exatamente sob o Teorema V.1 isolado.
- Prova (T1, independente de rótulo): conjugação de carga estado-a-estado
  não vale sob os seis valores Q_k do Teorema V.1. Duas correções candidatas
  fechadas por busca exaustiva; adotada conjugação como identidade agregada
  apenas. η_B não é afetado (nunca usa conjugação estado-a-estado).
- μ⁻/τ⁻ não são tuplas N=3 (Teorema 6.2 exclui isso) — mecanismo real é a
  Matriz de Transferência Leptônica (P8b, App. A.2.5), com o passo formal
  (Passo A.3) ainda [T2]. Nenhuma das 17 predições falseáveis depende disso.

## Correções de contabilidade no paper

- Tabela 4: legenda dizia "16 predições falseáveis"; corrigido para 17
  (batendo com as linhas reais e com o resumo/abstract).
- Tabela 18.3: contagem de inputs livres corrigida de 1 para 2.
- Tabela 5 (§12): nota adicionada distinguindo as duas linhas de G_N
  (input SC vs. output T2 da cascata reversa).

## Arquivos novos/alterados

- `proofs/docs/CHARGE_CONVENTIONS.md` — reescrito (§3a–3d/§3a–3c conforme
  a versão), com a prova de impossibilidade e a resolução adotada
- `proofs/docs/SECTION_12_NOTE.md` — nota complementar sobre a leitura de
  C/CP usada na Seção 13 do paper
- `proofs/docs/QFT_PIPELINE.md` — tuplas próton/nêutron corrigidas (rótulo
  apenas; g_p=g_n=12 não muda)
- `proofs/docs/PSION_DIAGRAM_TEXTBOOK.md` — item aberto sinalizado: e⁺
  deriva para (0,4,5), a mesma tupla do próton; não resolvido aqui
- `proofs/docs/PROGRESS_AND_ROADMAP.md` — nota de escopo sobre P2/P12 não
  zerar os inputs SC sozinho (Δm²₂₁ permanece)
- `paper/PH_Foundations_v84.tex` / `.pdf` — versão completa (43 páginas),
  substitui o stub v83 anterior no repositório
- `README.md` — reescrito para v8.4

## Problema novo registrado (não resolvido)

Colisão de tupla e⁺/próton em (0,4,5): ambos carregam Q=+1 sob o mesmo
mapeamento Z6, sem nenhum número quântico bariônico/leptônico separado no
framework para distingui-los. Ver `PSION_DIAGRAM_TEXTBOOK.md`.

## O que NÃO muda

Todos os valores numéricos das predições centrais (ρ_Λ, G_N, η_B, Ω_DM/Ω_b,
N_eff, N_ν=3, N_g=8, os 39 estados de matéria escura) são idênticos ao v83.
