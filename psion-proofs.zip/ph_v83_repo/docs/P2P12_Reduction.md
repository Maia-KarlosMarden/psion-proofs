# P2/P12 Reduction Theorem
## Epistemic Closure of the Electron Mass Program

**Date:** June 2026  
**Version:** PH v83  
**Status:** T2 (target precisely specified; lemma unproved)  
**Author:** Karlos Marden Maia

---

## Summary

P2/P12 has been **reduced to a single necessary and sufficient lemma**.

The original objective was to derive the electron mass law

$$m_e = \Lambda_{\rm meta} \exp(-N_e/b_e)$$

from the 2PI-NJL kernel of the PH without observational input.

This document shows that the entire program is mathematically equivalent to
proving one spectral identity of the composite kernel: the **Anomalous
Inversion Lemma** (P2/P12-A).

This transforms P2/P12 from a broad dynamical program into a **precisely
defined calculational target**.

---

## The Conditional Electron Mass Theorem

### Propositions

**Proposition I — Critical Kernel** *(closed, T1)*

The dominant eigenvalue of the Bethe-Salpeter kernel satisfies

$$\lambda(\Lambda_{\rm meta}) = 1.$$

This is the standard criticality condition of the NJL condensate.
Already established within the PH framework.

---

**Proposition II — Structural Cascade** *(closed, T1)*

The electronic channel $e^- = (0,1,2)$ contains $N_e = 10$ independent
RG cascade sectors.

Established by Theorem G.1 (counting theorem of $\mathbb{Z}_6$, T1).

---

**Proposition III — Anomalous Inversion Lemma** *(open, T2)*

The anomalous dimension of the composite electronic operator satisfies

$$\gamma_{\mathcal{O}_e} = \frac{1}{b_e}.$$

This is **P2/P12-A** — the unique unresolved condition.  
See §Audit Note below for the independence requirement.

---

### Theorem

*Under Propositions I–III:*

$$\boxed{m_e = \Lambda_{\rm meta}\, e^{-N_e/b_e}.}$$

**Proof.**  
The Callan–Symanzik equation gives

$$\Lambda \frac{d\ln\lambda}{d\Lambda} = \gamma_{\mathcal{O}_e}.$$

Integrating from $\Lambda_{\rm meta}$ to the infrared electronic scale:

$$\ln\lambda_e = -\gamma_{\mathcal{O}_e}\ln\!\left(\frac{\Lambda_{\rm meta}}{\Lambda_e}\right).$$

Using $\gamma_{\mathcal{O}_e} = 1/b_e$ (Proposition III) and
$\ln(\Lambda_{\rm meta}/\Lambda_e) = N_e$ (Proposition II):

$$\lambda_e = e^{-N_e/b_e}.$$

Since $m_e = \Lambda_{\rm meta}\lambda_e$ (Proposition I), the
exponential mass law follows. $\square$

---

## Epistemic Consequence

The derivation shows that P2/P12 is mathematically equivalent to
proving a single lemma. No additional assumptions are required beyond
the three propositions.

Therefore:

$$\text{P2/P12} \;\Longleftrightarrow\; \boxed{\gamma_{\mathcal{O}_e} = \frac{1}{b_e}}$$

This lemma is both **necessary** and **sufficient** for the unconditional
derivation of the electron mass formula from the PH Lagrangian.

---

## Status Classification

| Item | Status |
|---|---|
| Critical NJL condition $\lambda(\Lambda_{\rm meta})=1$ | **Closed** T1 |
| Structural cascade $N_e = 10$ | **Closed** T1 |
| Conditional derivation $m_e = \Lambda e^{-N_e/b_e}$ | **Closed** (given P2/P12-A) |
| **P2/P12-A: Anomalous Inversion Lemma** $\gamma_{\mathcal{O}_e} = 1/b_e$ | **Open** T2 |

---

## Remaining Open Problem

$$\boxed{\text{P2/P12-A:}\quad \gamma_{\mathcal{O}_e} = \frac{1}{b_e}}$$

**Specification:**

- **Input:** $\mathcal{L}(\mathbb{Z}_6,\; g^2 = 2\pi^2/3,\; b_e = 325/1152,\; N_e = 10,\; N_c = 6)$
- **Target:** First-principles spectral calculation of the anomalous dimension
  of the composite operator $\mathcal{O}_e = \psi_{(0)}\psi_{(1)}\psi_{(2)}$
  in the 2PI kernel, **independently of the observed value of $m_e$**
- **Closure condition:** $\gamma_{\mathcal{O}_e} = 1/b_e$ derived without
  using the exponential mass law as input
- **If proved:** $m_e = \Lambda_{\rm meta} e^{-N_e/b_e}$ becomes an
  **unconditional theorem** of the PH; SC inputs reduce from 1 to 0
- **If disproved:** The exponential cascade law requires modification

---

## Audit Note: Independence Requirement

The scientific value of this reduction depends critically on P2/P12-A
being calculable **independently** of the law it proves.

The lemma $\gamma_{\mathcal{O}_e} = 1/b_e$ connects two objects of
distinct origin:

- $\gamma_{\mathcal{O}_e}$: anomalous dimension of the composite
  electronic operator — from the OPE of the 2PI kernel in the
  electronic sector $(k=0,1,2)$
- $1/b_e$: inverse of the cascade parameter $b_e = b_0/(Z_{\rm NP} \cdot N_c)
  = 325/1152$ — from the vacuum NJL renormalisation

For the reduction to be non-circular, the calculation of
$\gamma_{\mathcal{O}_e}$ from the 2PI kernel must proceed without
assuming $m_e = \Lambda_{\rm meta} e^{-N_e/b_e}$.

The equality $\gamma_{\mathcal{O}_e} = 1/b_e$, if it holds, would then
constitute a non-trivial structural identity of the $\mathbb{Z}_6$
condensate — connecting the spectral properties of the composite channel
to the vacuum renormalisation flow. This is the physical content of
the lemma.

---

## What This Result Is and Is Not

| | |
|---|---|
| **Is:** | Reduction of P2/P12 to a single precisely-specified calculational target |
| **Is:** | Proof that Propositions I and II are already closed (T1) |
| **Is:** | Identification of the unique bottleneck of the mass-generation program |
| **Is not:** | Proof of the Anomalous Inversion Lemma |
| **Is not:** | Closure of P2/P12 |
| **Is not:** | Change in T-level (remains T2) |

---

## Scientific Significance

Reducing a broad dynamical program to a single necessary-and-sufficient
lemma is a methodological result of independent value:

1. It establishes that the electron mass law has a **complete proof
   structure** — only one step is missing
2. It provides a **falsifiable target**: if $\gamma_{\mathcal{O}_e} \neq 1/b_e$,
   the cascade law must be modified
3. It converts P2/P12 from an ill-defined program into a
   **well-posed spectral problem** tractable by standard 2PI techniques

The Anomalous Inversion Lemma is now the **unique bottleneck** of the
PH mass-generation program.

---

## Cross-References

- P8b: sub-leading correction to $A = 13/12$, $p = 5/6$ (lepton sector)
- Theorem G.1: $N_e = 10$ counting theorem (T1)
- Appendix J: anomalous dimension in the chiral sector
- `tests/test_cascade_anchor.py`: verifies the cascade numerically (13 tests)
- `scripts/cascade_anchor.py`: canonical SC input declaration

---

*Registered: June 2026 | PH v83 | psion-proofs-v83*
